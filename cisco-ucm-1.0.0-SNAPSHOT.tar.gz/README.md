# ansible-ucm

_Ansible Galaxy Collection for Cisco Unified Communications Manager (CUCM)_

A collection of modules and roles for interacting with the UCM APIs including AXL, RisPort and
Performance Monitoring.
