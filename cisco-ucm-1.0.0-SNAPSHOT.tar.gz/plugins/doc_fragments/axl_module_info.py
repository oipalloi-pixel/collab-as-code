#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.


class ModuleDocFragment(object):

    # Standard files documentation fragment
    DOCUMENTATION = r"""
options:
    version:
        description:
          - The Unified Communications Platform version to target.
        type: str
        required: true
        choices:
          - "11.0"
          - "11.5"
          - "12.0"
          - "12.5"
          - "14.0"
          - "15.0"
extends_documentation_fragment:
  - cisco.ucm.module_info
"""
