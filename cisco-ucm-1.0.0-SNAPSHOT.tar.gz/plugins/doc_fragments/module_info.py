#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.


class ModuleDocFragment(object):

    # Standard files documentation fragment
    DOCUMENTATION = r"""
options:
    hostname:
        description:
          - The Unified Communications Platform hostname.
        type: str
        required: true
    username:
        description:
          - The Unified Communications Platform GUI username to authenticate.
        type: str
        required: true
    password:
        description:
          - The Unified Communications Platform GUI password to authenticate.
        type: str
        required: true
    verify:
        description:
          - Flag to enable or disable SSL certificate verification.
        type: bool
        default: true
notes:
    - "Supports C(check_mode)"
    - "The plugin runs on the control node and does not use any ansible connection plugins"
"""
