#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils.ascode.mappers.data_model import (
    from_axl_model,
)

display = Display()


class FilterModule(object):
    """Ansible filter plugin for ascode data model mappings."""

    def filters(self):
        return {
            "ascode_from_axl_model": lambda data: from_axl_model(data, warn=display.warning),
        }
