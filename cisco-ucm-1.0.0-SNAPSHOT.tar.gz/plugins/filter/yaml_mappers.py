#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, division, print_function

__metaclass__ = type

import io

import yaml
from ansible.parsing.yaml.dumper import AnsibleDumper as _ansible_dumper_factory

# AnsibleDumper is a compatibility factory function, not a class, so it cannot
# be subclassed directly.  Instantiate it with a dummy stream and take the type
# to get the real class via the public API — no private module imports needed.
_AnsibleDumperBase = type(_ansible_dumper_factory(io.StringIO()))


class _AnsibleDumper(yaml.Dumper):
    """yaml.Dumper with Ansible proxy-type support and optional sequence indentation.

    Why yaml.Dumper and not AnsibleDumper?
    When libyaml is installed, AnsibleDumper inherits from CEmitter — a C
    extension that handles indentation entirely in C.  That means Python
    overrides of increase_indent are silently ignored.  yaml.Dumper always
    uses the pure-Python emitter, so our override is guaranteed to take effect.

    Ansible's multi-representers (AnsibleTaggedObject, Mapping, Collection,
    vault-encrypted strings, Tripwire, etc.) are copied from _AnsibleDumperBase
    so that Ansible proxy types are serialized correctly without a JSON round-
    trip.

    Set _indent_sequences = False on a subclass to use standard PyYAML indentation.
    """

    _indent_sequences = True

    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(
            flow=flow,
            indentless=False if self._indent_sequences else indentless,
        )


# Copy everything Ansible-specific from _AnsibleDumperBase onto _AnsibleDumper:
# instance methods (get_node_from_ciphertext, etc.) that the multi-representers
# call on `self`.  Skipping dunders avoids trampling Python internals.  Anything
# already in yaml.Dumper is also skipped so we never override PyYAML's own
# methods.  If Ansible adds new helper methods in a future release they will be
# picked up automatically.
#
# yaml_multi_representers and yaml_representers are excluded from the copy
# because they are PyYAML dispatch dicts that must be populated via
# add_multi_representer / add_representer (done explicitly below).
# yaml_representers is intentionally not copied: as of the supported Ansible
# versions, AnsibleDumper registers everything in yaml_multi_representers only
# (using abstract base types such as collections.abc.Mapping).  If a future
# Ansible release adds single-type representers in yaml_representers, the tests
# will catch the gap.
_yaml_dumper_names = set(vars(yaml.Dumper)) | {"yaml_multi_representers", "yaml_representers"}
for _name, _val in vars(_AnsibleDumperBase).items():
    if not _name.startswith("__") and _name not in _yaml_dumper_names:
        setattr(_AnsibleDumper, _name, _val)

# Register multi-representers so that Ansible proxy types (AnsibleMapping,
# AnsibleSequence, vault-encrypted strings, Tripwire, etc.) are serialized
# correctly without a JSON round-trip.
for _type, _representer in _AnsibleDumperBase.yaml_multi_representers.items():
    _AnsibleDumper.add_multi_representer(_type, _representer)


class _AnsibleDumperFlat(_AnsibleDumper):
    """_AnsibleDumper with standard (non-indented) sequence rendering."""

    _indent_sequences = False


def to_yaml(data, indent=2, width=80, indent_sequences=True):
    """Serialize *data* to YAML with optional sequence indentation.

    Args:
        data:              The value to serialize.
        indent:            Indentation width (default 2).
        width:             Soft line-wrap target in characters (default 80).
                           PyYAML will not break unbreakable scalars (e.g. long
                           strings with no spaces) even if they exceed this.
        indent_sequences:  When True (default), sequence items are indented
                           under their parent key for IDE folding support.
                           When False, the standard AnsibleDumper behaviour is
                           used.

    Returns:
        A YAML string.
    """
    dumper = _AnsibleDumper if indent_sequences else _AnsibleDumperFlat
    return yaml.dump(
        data,
        Dumper=dumper,
        default_flow_style=False,
        allow_unicode=True,
        indent=indent,
        width=width,
        sort_keys=False,
    )


class FilterModule(object):
    """Ansible filter plugin for YAML formatting utilities."""

    def filters(self):
        # Intentionally shadows Ansible's built-in `to_yaml` / `to_nice_yaml`
        # filters to provide indented-sequence output by default.
        return {
            "to_yaml": to_yaml,
        }
