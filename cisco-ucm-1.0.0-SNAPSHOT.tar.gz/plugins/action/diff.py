# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type

from dataclasses import asdict

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.ascode.diff import diff

display = Display()


class ActionModule(LocalActionModule):
    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            self.initialize(
                argument_spec={
                    "current": {"type": "dict", "required": True},
                    "intended": {"type": "dict", "required": True},
                    "actions": {
                        "type": "list",
                        "elements": "str",
                        "required": False,
                        "default": ["create", "update"],
                        "choices": ["create", "update", "delete"],
                    },
                },
                tmp=tmp,
                task_vars=task_vars,
            )
            display.vvvv("Module initialized with parameters: %s" % self.params)

            operations = diff(
                current=self.params["current"],
                intended=self.params["intended"],
                actions=self.params["actions"],
                print_status=display.v,
            )

            return self.exit_json(
                changed=False,
                operations=[asdict(op) for op in operations],
            )

        except Exception as err:
            self.fail_json(msg=f"Error generating CUCM diff plan: {err}", error=str(err))
