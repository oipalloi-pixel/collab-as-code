# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from typing import Dict, List

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils import argument_specs
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.templates import axl_template

try:
    from ansible_collections.cisco.ucm.plugins.plugin_utils.sdk.template import sql_prepare
    from zeep.exceptions import Error, Fault
except ImportError:
    ZEEP_IS_INSTALLED = False
else:
    ZEEP_IS_INSTALLED = True

display = Display()


class ActionModule(LocalActionModule):
    def _additional_error_context(self) -> dict:
        params = getattr(self, "params", None)
        if not isinstance(params, dict):
            return {}

        statements = params.get("statements")
        if isinstance(statements, list):
            return {"statement_count": len(statements)}
        return {}

    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            self.initialize(
                argument_spec={
                    **argument_specs.host_credentials_verify(),
                    **argument_specs.axl_version(),
                    "statements": {
                        "type": "list",
                        "elements": "dict",
                        "required": True,
                        "options": {
                            "sql": {"type": "str", "required": True},
                            "args": {
                                "type": "list",
                                "elements": "raw",
                                "required": False,
                                "default": [],
                            },
                        },
                    },
                    "batch_size": {"type": "int", "required": False, "default": 500},
                },
                tmp=tmp,
                task_vars=task_vars,
            )

            if not ZEEP_IS_INSTALLED:
                self.fail_json(msg="zeep is required for this module.")

            statements: List[Dict] = self.params["statements"]
            batch_size: int = self.params["batch_size"]

            if any(s["sql"].strip().lower().startswith("select") for s in statements):
                self.fail_json(msg="SELECT SQL statements are not supported.")

            prepared_statements = [sql_prepare(s["sql"], *s.get("args", [])) for s in statements]
            batches = [
                ";\n".join(prepared_statements[i : i + batch_size])
                for i in range(0, len(prepared_statements), batch_size)
            ]

            response = []
            if len(prepared_statements) == 0:
                # Empty statements, fall through to exit with empty response
                pass

            elif self.check_mode:
                display.vvvv("Entering check_mode")
                return self.exit_json(
                    changed=True,
                    msg=f"Would have executed {len(statements)} statement(s) in {len(batches)}"
                    " batch(es) if not in check mode",
                )

            else:
                axl = axl_template(self.params)
                for batch in batches:
                    result = axl.sql(batch)
                    response.append(result)

            return self.exit_json(changed=True, response=response)

        except Fault as err:
            self.fail_json(
                msg=f"{err.message}",
                **{"fault": err.detail if hasattr(err, "detail") else str(err)},
            )

        except Error as err:
            self.fail_json(msg=f"Error executing SQL query: {err}", error=str(err))
