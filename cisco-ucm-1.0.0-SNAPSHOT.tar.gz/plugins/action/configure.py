# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type


from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils import argument_specs
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.ascode.configure import configure
from ansible_collections.cisco.ucm.plugins.plugin_utils.ascode.operation import Operation
from ansible_collections.cisco.ucm.plugins.plugin_utils.templates import axl_template

try:
    from zeep.exceptions import Error, Fault
except ImportError:
    ZEEP_IS_INSTALLED = False
else:
    ZEEP_IS_INSTALLED = True

display = Display()


class ActionModule(LocalActionModule):
    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            if not ZEEP_IS_INSTALLED:
                return self.fail_json(msg="zeep is required for this module.")

            self.initialize(
                argument_spec={
                    **argument_specs.host_credentials_verify(),
                    **argument_specs.axl_version(),
                    "operations": {
                        "type": "list",
                        "elements": "dict",
                        "required": True,
                        "options": {
                            "action": {
                                "type": "str",
                                "required": True,
                                "choices": ["create", "update", "delete"],
                            },
                            "type": {"type": "str", "required": True},
                            "data": {"type": "dict", "required": True},
                        },
                    },
                },
                tmp=tmp,
                task_vars=task_vars,
            )
            display.vvvv("Module initialized with parameters: %s" % self.params)

            operations = [Operation.from_dict(op) for op in self.params["operations"]]
            messages = []

            def print_status(message: str):
                messages.append(message)
                display.v(message)

            axl = axl_template(self.params)
            configure(
                axl=axl,
                operations=operations,
                print_status=print_status,
                check_mode=self.check_mode,
            )

            return self.exit_json(
                changed=not self.check_mode and len(operations) > 0,
                messages=messages,
            )

        except Fault as err:
            self.fail_json(
                msg=f"{err.message}",
                **{"fault": err.detail if hasattr(err, "detail") else str(err)},
            )

        except Error as err:
            self.fail_json(msg=f"Error executing AXL operation: {err}", error=str(err))

        except Exception as err:
            self.fail_json(msg=f"Error applying CUCM operations: {err}", error=str(err))
