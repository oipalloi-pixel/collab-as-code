# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils import argument_specs
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.templates import axl_template

try:
    from zeep.exceptions import Error, Fault
except ImportError:
    ZEEP_IS_INSTALLED = False
else:
    ZEEP_IS_INSTALLED = True

display = Display()


class ActionModule(LocalActionModule):
    def _additional_error_context(self) -> dict:
        params = getattr(self, "params", None)
        if isinstance(params, dict) and "sql" in params:
            return {"sql_provided": True}
        return {}

    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            self.initialize(
                argument_spec={
                    **argument_specs.host_credentials_verify(),
                    **argument_specs.axl_version(),
                    "sql": {"type": "str", "required": True},
                    "args": {"type": "list", "elements": "raw", "required": False, "default": []},
                },
                tmp=tmp,
                task_vars=task_vars,
            )

            if not ZEEP_IS_INSTALLED:
                self.fail_json(msg="zeep is required for this module.")

            sql = self.params["sql"]
            args = self.params["args"]

            display.vvvv(f"Executing SQL query: {sql} with args: {args}")
            axl = axl_template(self.params)
            response = list(axl.sql_select(sql, *args))
            display.vvvv(f"SQL query result: {response}")

            return self.exit_json(changed=False, response=response)

        except Fault as err:
            self.fail_json(
                msg=f"{err.message}",
                **{"fault": err.detail if hasattr(err, "detail") else str(err)},
            )

        except (Error, ValueError) as err:
            self.fail_json(msg=f"Error executing SQL query: {err}", error=str(err))
