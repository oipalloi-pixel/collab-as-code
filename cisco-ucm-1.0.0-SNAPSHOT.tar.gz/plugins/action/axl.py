# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils import argument_specs
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.templates import axl_template

try:
    from zeep.exceptions import Error, Fault
except ImportError:
    ZEEP_IS_INSTALLED = False
else:
    ZEEP_IS_INSTALLED = True

display = Display()


def is_change_operation(operation: str) -> bool:
    read_only_operations = ["list", "get"]
    return not any(operation.lower().startswith(op) for op in read_only_operations)


class ActionModule(LocalActionModule):
    def _additional_error_context(self) -> dict:
        params = getattr(self, "params", None)
        if isinstance(params, dict) and "operation" in params:
            return {"operation": params["operation"]}
        return {}

    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            self.initialize(
                argument_spec={
                    **argument_specs.host_credentials_verify(),
                    **argument_specs.axl_version(),
                    "operation": {"type": "str", "required": True},
                    "iterate": {"type": "bool", "required": False, "default": False},
                    "args": {"type": "dict", "required": False, "default": {}},
                },
                tmp=tmp,
                task_vars=task_vars,
            )
            display.vvvv("Module initialized with parameters: %s" % self.params)

            if not ZEEP_IS_INSTALLED:
                self.fail_json(msg="zeep is required for this module.")

            operation = self.params["operation"]
            args = self.params["args"]
            iterate = self.params["iterate"]

            axl = axl_template(self.params)
            if axl.has_operation(operation) is False:
                self.fail_json(msg=f"AXL operation '{operation}' is not supported")

            changed = is_change_operation(operation)

            if changed and self.check_mode:
                display.vvvv("Entering check_mode")
                return self.exit_json(
                    changed=changed,
                    msg=f"Would have executed {operation} with {args} if not in check mode",
                )

            elif iterate and "list" in operation.lower():
                display.vvvv("Running list operation with iteration")
                response = list(axl.iterate_entity(operation, **args))

            else:
                display.vvvv(f"Running AXL operation '{operation}' with args: {args}")
                response = axl.call(operation, **args)

            display.vvvv(
                f"AXL operation '{operation}' executed successfully with response: {response}"
            )

            return self.exit_json(changed=changed, response=response)

        except Fault as err:
            self.fail_json(
                msg=f"{err.message}",
                **{"fault": err.detail if hasattr(err, "detail") else str(err)},
            )

        except Error as err:
            self.fail_json(msg=f"Error executing AXL operation: {err}", error=str(err))
