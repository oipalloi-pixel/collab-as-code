# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.utils.display import Display
from ansible_collections.cisco.ucm.plugins.plugin_utils import argument_specs
from ansible_collections.cisco.ucm.plugins.plugin_utils.action_module import (
    ActionModule as LocalActionModule,
)
from ansible_collections.cisco.ucm.plugins.plugin_utils.templates import risport_template

try:
    from zeep.exceptions import Error
except ImportError:
    ZEEP_IS_INSTALLED = False
else:
    ZEEP_IS_INSTALLED = True

display = Display()


class ActionModule(LocalActionModule):
    def _additional_error_context(self) -> dict:
        params = getattr(self, "params", None)
        if isinstance(params, dict) and "operation" in params:
            return {"operation": params["operation"]}
        return {}

    def run(self, tmp=None, task_vars=None):
        try:
            display.vvvv("Warning: maximum verbosity may leak sensitive data")

            self.initialize(
                argument_spec={
                    **argument_specs.host_credentials_verify(),
                    "operation": {"type": "str", "required": True},
                    "args": {"type": "dict", "required": False, "default": {}},
                },
                tmp=tmp,
                task_vars=task_vars,
            )

            if not ZEEP_IS_INSTALLED:
                self.fail_json(msg="zeep is required for this module.")

            operation = self.params["operation"]
            args = self.params["args"]

            display.vvvv(f"Calling RISPort operation: {operation} with args: {args}")
            risport = risport_template(self.params)
            if not risport.has_operation(operation):
                self.fail_json(msg=f"RISPort operation '{operation}' is not supported")

            response = risport.call(operation, **args)
            display.vvvv(f"RISPort operation result: {response}")

            return self.exit_json(changed=False, response=response)

        except Error as err:
            self.fail_json(msg=f"{err.args[0]}", kwargs=err.args[1:])
