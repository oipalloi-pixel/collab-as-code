#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: axl_sql_select
short_description: Execute SQL SELECT queries via AXL API
description:
  - Used to execute SQL SELECT queries against the CUCM database using the AXL API.
  - Supports parameterized queries with placeholders.
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.axl_module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  sql:
    description:
      - SQL SELECT query to execute
      - Use ? as placeholder for parameters
    type: str
    required: true
  args:
    description:
      - List of arguments to substitute for placeholders in the SQL query
      - Arguments will be substituted in order for each ? placeholder
      - Can be any data type (string, integer, boolean, etc.)
    type: list
    elements: raw
    required: false
    default: []
requirements:
  - python >= 3.11
  - cisco_collab_ucm_sdk
notes:
  - Uses AxlTemplate
  - Only SELECT queries are supported
"""

EXAMPLES = r"""
- name: Execute SQL Query with parameters
  cisco.ucm.axl_sql_select:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    sql: "SELECT name, model, pattern FROM device WHERE name=? ORDER BY 1"
    args:
      - "SEP123456789ABC"
  register: device_result

- name: Execute SQL Query without parameters
  cisco.ucm.axl_sql_select:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    sql: "SELECT name, description FROM devicepool"
  register: devicepool_result

- name: Query multiple conditions
  cisco.ucm.axl_sql_select:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    sql: >
      SELECT name, dnorpattern
      FROM numplan
      WHERE dnorpattern=? AND routepartitionname=?
      ORDER BY 1
    args:
      - "1001"
      - "Internal_PT"
  register: numplan_result
"""

RETURN = r"""
response:
  description: The response from the SQL query execution
  returned: always
  type: list
  sample:
    - name: "SEP123456789ABC"
      model: "Cisco 8845"
      pattern: "1001"
    - name: "SEP987654321DEF"
      model: "Cisco 8865"
      pattern: "1002"
changed:
  description: Always false for SELECT queries
  returned: always
  type: bool
  sample: false
"""
