#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: axl
short_description: Execute AXL API operations
description:
  - Used to make SOAP requests to the AXL API.
  - For operations like add, update, delete, get, and list.
  - This module allows calling any AXL operation by specifying the operation name and arguments.
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.axl_module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  operation:
    description:
      - Name of AXL operation to execute.
      - "Examples: `addPhone`, `updatePhone`, `deletePhone`, `getPhone`, `listPhone`."
      - Consult the AXL API documentation for valid operation names and their arguments.
    type: str
    required: true
  iterate:
    description:
      - Whether to iterate over results for list operations.
      - "If `true`, then all pages of results will be retrieved automatically."
      - "`skip` and `first` will be used to retrieve all pages of results."
      - "`searchCriteria` and `returnedTags` can be omitted."
      - The result will be a flat combined list of all items.
    type: bool
    required: false
    default: false
  args:
    description:
      - Arguments to pass to the AXL operation as a dictionary
    type: dict
    required: false
    default: {}
requirements:
  - python >= 3.11
  - cisco_collab_ucm_sdk
notes:
  - Uses AxlTemplate from cisco.collab.ucm.sdk
"""

EXAMPLES = r"""
- name: Add a phone with line
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "addPhone"
    args:
      phone:
        name: "SEP123456789ABC"
        product: "Cisco 8845"
        model: "Cisco 8845"
        class: "Phone"
        protocol: "SIP"
        protocolSide: "User"
        callingSearchSpaceName: ""
        devicePoolName: "Default"
        lines:
          line:
            dirn:
              pattern: "1001"
              routePartition: "Internal_PT"
            index: 1
  register: uc_axl_response

- name: List phones
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "listPhone"
    args:
      searchCriteria:
        name: "%"
      returnedTags:
        name: ""
        product: ""
        model: ""
        class: ""
        protocol: ""
        protocolSide: ""
        callingSearchSpaceName: ""
        devicePoolName: ""
      skip: 0
      first: 10
  register: uc_axl_response

- name: List phones with iteration
  cisco.ucm.axl:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    verify: "{{ uc_verify | default(true) }}"
    version: "12.5"
    operation: "listPhone"
    iterate: true
  register: uc_axl_response

- name: Get all phone details
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "getPhone"
    args:
      name: "SEP123456789ABC"
  register: uc_axl_response

- name: Update phone
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "updatePhone"
    args:
      name: "SEP123456789ABC"
      description: "Updated description"
  register: uc_axl_response

- name: Delete phone
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "deletePhone"
    args:
      name: "SEP123456789ABC"
  register: uc_axl_response

- name: Get CUCM Version
  cisco.ucm.axl:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    operation: "getCCMVersion"
  register: uc_axl_response
"""

RETURN = r"""
response:
  description: The response from the AXL operation
  returned: always
  type: dict
  sample:
    return: "{12345678-1234-1234-1234-123456789abc}"
changed:
  description: Whether the operation made changes
  returned: always
  type: bool
  sample: true
"""
