#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: configure
short_description: Apply a plan of operations to a CUCM server
description:
  - Applies an ordered list of operations to a CUCM server via the AXL API.
  - Wraps the C(configure()) function from C(module_utils.ascode.configure).
  - Supports Ansible check mode — no changes are made to the server when
    running in check mode.
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.axl_module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  operations:
    description:
      - Ordered list of operations to apply, as produced by M(cisco.ucm.diff).
      - Each item must have C(action), C(type), and C(data) keys.
    type: list
    elements: dict
    required: true
    suboptions:
      action:
        description: The operation action (C(create), C(update), or C(delete)).
        type: str
        required: true
        choices:
          - create
          - update
          - delete
      type:
        description: The AXL object type (e.g. C(RoutePartition), C(DevicePool)).
        type: str
        required: true
      data:
        description: The object data to pass to the AXL operation.
        type: dict
        required: true
"""

EXAMPLES = r"""
- name: Apply diff plan to CUCM
  cisco.ucm.configure:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    operations: "{{ diff_operations }}"
  delegate_to: localhost
  register: configure_result
"""

RETURN = r"""
messages:
  description: Status messages emitted during operation application, useful for debugging.
  returned: always
  type: list
  elements: str
  sample:
    - "Commencing operation application"
    - "create RoutePartition"
"""
