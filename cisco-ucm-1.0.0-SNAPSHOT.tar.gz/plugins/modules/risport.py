#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: risport
short_description: Real-time Information Server (RIS) Module
description:
  - Used to return the real-time data from the RIS Database
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  operation:
    description:
      - Name of risport operation to execute.
      - "Example: `selectCmDeviceExt`"
      - Consult the RISPort API documentation for valid operation names and their arguments.
    type: str
    required: true
  args:
    description:
      - Arguments to pass to the risport operation as a dictionary
    type: dict
    required: false
    default: {}
requirements:
  - python >= 3.11
"""

EXAMPLES = r"""
- name: Get RIS Davice Status
  cisco.ucm.risport:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_username }}"
    password: "{{ uc_password }}"
    verify: "{{ uc_verify }}"
    operation: "selectCmDeviceExt"
    args:
      StateInfo: ""
      CmSelectionCriteria:
        MaxReturnedDevices: 1000
        DeviceClass: "{{ device_type }}"
        Model: 255
        Status: Any
        SelectBy: Name
        SelectItems:
          - item:
              Item: "{{ device_name }}"
        Protocol: Any
        DownloadStatus: Any
  register: result
"""

RETURN = r"""
response:
  description: The last HTTP response (the POST)
  returned: always
  type: dict
  sample:
    SelectCmDeviceResult:
      CmNodes:
        item:
          Name: cucm-pub.example.com
          CmDevices:
            item:
              Name: SEP0123456789AB
              Status: Registered
              ActiveLoadID: sip88xx.14-1-1-1
              InactiveLoadID: sip88xx.14-0-1-1
              IPAddress:
                item:
                  IP: 10.10.10.101
"""
