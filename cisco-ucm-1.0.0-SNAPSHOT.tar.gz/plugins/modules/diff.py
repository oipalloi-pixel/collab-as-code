#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: diff
short_description: Generate a plan of operations to reconcile two CUCM state dicts
description:
  - Compares a current and intended CUCM configuration state and produces
    an ordered list of operations required to reconcile them.
  - Wraps the C(diff()) function from C(module_utils.ascode.diff).
version_added: '1.0.0'
author: "CX Software Orchestration (@software-orchestration)"
options:
  current:
    description:
      - Dictionary representing the current CUCM configuration state.
    type: dict
    required: true
  intended:
    description:
      - Dictionary representing the intended CUCM configuration state.
    type: dict
    required: true
  actions:
    description:
      - List of operation types to include in the plan.
    type: list
    elements: str
    required: false
    default: [create, update]
    choices:
      - create
      - update
      - delete
"""

EXAMPLES = r"""
- name: Generate diff plan between current and intended CUCM state
  cisco.ucm.diff:
    current: "{{ collect_result.result }}"
    intended: "{{ intended_state }}"
    actions:
      - create
      - update
  delegate_to: localhost
  register: diff_result
"""

RETURN = r"""
operations:
  description: Ordered list of operations required to reconcile current state to intended state.
  returned: always
  type: list
  elements: dict
  sample:
    - action: create
      type: RoutePartition
      data:
        name: "NewPartition"
"""
