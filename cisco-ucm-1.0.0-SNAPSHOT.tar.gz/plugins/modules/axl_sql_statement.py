#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

# ruff: noqa: E402

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: axl_sql_statement
short_description: Execute SQL statements via AXL API
description:
  - Used to execute any non-select SQL statements against the CUCM database using the AXL API.
  - Supports parameterized queries with placeholders.
  - Can execute multiple SQL statements in a single task.
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.axl_module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  batch_size:
    description:
      - Number of SQL statements to include in each batch execution
      - Multiple statements will be combined into a single SQL execution call
    type: int
    required: false
    default: 500
  statements:
    description:
      - List of SQL statements to execute
      - Each statement is a dictionary containing 'sql' and optionally 'args'
    type: list
    elements: dict
    required: true
    suboptions:
      sql:
        description:
          - SQL DELETE, INSERT, or UPDATE statements
          - Use ? as placeholder for parameters
        type: str
        required: true
      args:
        description:
          - List of arguments to substitute for placeholders in the SQL query
          - Arguments will be substituted in order for each ? placeholder
          - Can be any data type (string, integer, boolean, etc.)
        type: list
        elements: raw
        required: false
        default: []
requirements:
  - python >= 3.11
  - cisco_collab_ucm_sdk
notes:
  - Uses AxlTemplate
  - Only non-select SQL statements are supported
"""

EXAMPLES = r"""
- name: Execute SQL statements
  cisco.ucm.axl_sql_statement:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    verify: "{{ axl_verify | default(true) }}"
    version: "{{ axl_version }}"
    statements:
      - sql: INSERT into device values (?, ?)
        args:
          - "SEP123456789ABC"
          - 2
      - sql: INSERT into numplan values (?, '')
        args:
          - "1001%"
      - sql: UPDATE table1 set description = 'Updated'
      - sql: UPDATE table2 set description = 'Updated'
      - sql: UPDATE table3 set description = 'Updated'
      - sql: UPDATE table4 set description = 'Updated'
      - sql: UPDATE table5 set description = 'Updated'
      - sql: UPDATE table6 set description = 'Updated'
      - sql: DELETE FROM table7
      - sql: DELETE FROM table8
    batch_size: 4
  register: devicepool_result
"""

RETURN = r"""
response:
  description:
    - List of responses from each batch execution, in the order they were executed
    - Note that each batch will only return a summary of rows affected for the first statement
      in the batch
  returned: always
  type: list
  elements: dict
  sample:
    - rowsUpdated: 22
changed:
  description: Always true as INSERT, UPDATE, and DELETE statements modify database state
  returned: always
  type: bool
  sample: true
"""
