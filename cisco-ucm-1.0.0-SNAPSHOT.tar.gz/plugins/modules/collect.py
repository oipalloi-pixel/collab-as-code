#!/usr/bin/python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: collect
short_description: Collect CUCM AXL objects
description:
  - Collects CUCM configuration objects via the AXL API.
  - Wraps the C(collect()) function from C(module_utils.ascode.collect).
version_added: '1.0.0'
extends_documentation_fragment:
  - cisco.ucm.axl_module_info
author: "CX Software Orchestration (@software-orchestration)"
options:
  object_names:
    description:
      - List of AXL objects to collect.
      - Each item must specify a C(name) and a C(method).
      - C(method) must be either C(get) or C(list).
    type: list
    elements: dict
    required: true
    suboptions:
      name:
        description: The AXL object name (e.g. C(Phone), C(Line), C(DevicePool)).
        type: str
        required: true
      method:
        description: The retrieval method to use.
        type: str
        required: true
        choices:
          - get
          - list
"""

EXAMPLES = r"""
- name: Collect default CUCM objects
  cisco.ucm.collect:
    hostname: "{{ axl_hostname }}"
    username: "{{ axl_user }}"
    password: "{{ axl_password }}"
    version: "{{ axl_version }}"
    object_names:
      - name: DevicePool
        method: get
      - name: RoutePartition
        method: list
  delegate_to: localhost
  register: collect_result
"""

RETURN = r"""
result:
  description: Collected CUCM objects keyed by object name.
  returned: always
  type: dict
  sample:
    DevicePool:
      - uuid: "{12345678-1234-1234-1234-123456789abc}"
        name: "Default"
"""
