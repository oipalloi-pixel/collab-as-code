# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Infrastructure-as-code utilities for Cisco UCM configuration management.

Provides the core functions for collecting, diffing, and applying configuration
changes to a Cisco Unified Communications Manager (UCM) server via the AXL API.
"""

from .collect import collect
from .configure import configure
from .diff import diff
from .operation import Operation

__all__ = ["configure", "collect", "diff", "Operation"]
