# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Module for generating a plan of operations to reconcile current and intended UCM states."""

from logging import getLogger
from typing import Any, Callable

try:
    from urllib3 import disable_warnings as urllib3_disable_warnings
except ImportError:
    urllib3_disable_warnings = None

from .mappers import axl_model
from .operation import Operation
from .sort import sort_changes, split_cyclic_creates

__all__ = ["diff"]


root_logger = getLogger()
logger = getLogger(__name__)
if urllib3_disable_warnings is not None:
    urllib3_disable_warnings()


def object_name(obj: dict[str, Any]) -> str | None:
    """Get the name of an AXL object for identification.

    Args:
        obj: The AXL object dictionary.

    Returns:
        The name of the object, or an empty string if not found.
    """
    if isinstance(obj, dict) and len(obj) == 1:
        nested = next(iter(obj.values()))
        if isinstance(nested, dict) and "name" in nested:
            return nested["name"]

    elif "name" in obj:
        return obj["name"]

    return None


def diff_dict(obj1: dict[str, Any], obj2: dict[str, Any], path: str = "") -> list[str]:
    """Recursively compare two dictionaries and return a list of differences.

    Args:
        obj1: The first dictionary to compare.
    Args:
        obj1: The first dictionary to compare.
        obj2: The second dictionary to compare.

    Returns:
        A list of differences between the two dictionaries.
    """
    deltas: list[str] = []

    for key in obj1.keys() | obj2.keys():
        new_path = f"{path}.{key}" if path else key
        if key not in obj1:
            deltas.append(f"Key '{new_path}' missing in first object")
        elif key not in obj2:
            deltas.append(f"Key '{new_path}' missing in second object")
        else:
            val1, val2 = obj1[key], obj2[key]
            if isinstance(val1, dict) and isinstance(val2, dict):
                deltas.extend(diff_dict(val1, val2, new_path))
            elif val1 != val2:
                deltas.append(f"Value mismatch at '{new_path}': {val1} != {val2}")

    return deltas


def compare_objects(
    intended: dict[str, Any],
    current: dict[str, Any],
) -> list[Operation]:
    """
    Compare AXL objects between current and intended and generates a list of required operations to
    make current match intended.

    Each top level key in the current and intended dictionaries represents an AXL object type
    (e.g., 'phone', 'user'). The function compares the objects of each type and identifies
    additions, deletions, and modifications needed.

    If a top level key exists in intended but not in current, all objects under that key are
    considered additions. However, if a key exists in current but not in intended, no objects are
    changed. For deletions to occur the intended key must exist with an empty list.

    The resulting list items are Operation objects with the following structure:
    {
        "action": "create" | "delete" | "update",
        "type": str,
        "data": Dict[str, Any]  # Full object data for add/update, identifier for delete
    }
    """
    operations: list[Operation] = []

    # Get all object types from intended
    for object_type, intended_objects in intended.items():
        if not isinstance(intended_objects, list):
            continue

        # Get destination objects of the same type, default to empty list if not present
        current_objects = current.get(object_type, [])
        if not isinstance(current_objects, list):
            current_objects = []

        # Create lookup dictionaries by name for efficient comparison
        current_map = {object_name(obj): obj for obj in current_objects if object_name(obj)}
        intended_map = {object_name(obj): obj for obj in intended_objects if object_name(obj)}

        # Check for additions and updates
        for name, obj in intended_map.items():
            if name not in current_map:
                # Object exists in intended but not in current - add it
                operations.append(Operation(action="create", type=object_type, data=obj))

            else:
                # Object exists in both - check if it needs updating
                current_obj = current_map[name]
                if obj != current_obj:
                    if isinstance(obj, dict) and len(obj) == 1:
                        # Unwrap single-key dictionary
                        obj = next(iter(obj.values()))
                    operations.append(Operation(action="update", type=object_type, data=obj))

        # Check for deletions (only if object_type exists in intended)
        for name in current_map:
            if name not in intended_map:
                # Object exists in current but not in intended - delete it
                operations.append(Operation(action="delete", type=object_type, data={"name": name}))

    return operations


def diff(
    current: dict[str, Any],
    intended: dict[str, Any],
    actions: list[str] | None = None,
    print_status: Callable[[str], None] = lambda msg: None,
    progress_handler: Callable[[float], None] = lambda progress: None,
) -> list[Operation]:
    """Generate a plan of operations to reconcile current and intended states.

    Compares current and intended state data models, calculates differences,
    and derives the necessary operations (add/update/delete) to transform
    the current state to match the intended state.

    Args:
        current: Current state data model
        intended: Intended state data model
        actions: Optional list of action types to include (e.g. ``["create", "update"]``).
            Operations whose action is not in this list are silently dropped.
            When ``None`` all actions are included.
        print_status: Callback for status messages
        progress_handler: Callback for progress updates (0.0 to 1.0)

    Returns:
        List of operations needed to reconcile states
    """
    print_status("Denormalizing current data for comparison")
    current = axl_model.from_data_model(current)
    progress_handler(0.2)

    print_status("Denormalizing intended data for comparison")
    intended = axl_model.from_data_model(intended)
    progress_handler(0.5)

    print_status("Comparing and generating plan of operations")
    operations = compare_objects(intended=intended, current=current)
    progress_handler(0.8)

    print_status("Sorting plan of operations")
    operations = split_cyclic_creates(operations)
    operations = sort_changes(operations)

    if actions is not None:
        skipped = [op for op in operations if op.action not in actions]
        operations = [op for op in operations if op.action in actions]
        if skipped:
            logger.info(
                "Skipping %s operation(s) not in requested actions %s", len(skipped), actions
            )

    progress_handler(1.0)
    return operations
