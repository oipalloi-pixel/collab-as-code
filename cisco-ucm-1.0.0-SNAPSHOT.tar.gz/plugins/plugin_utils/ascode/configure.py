# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Module to apply operations to a Cisco UCM server."""

from logging import getLogger
from typing import Callable

try:
    from ..sdk.template import AxlTemplate
    from ..sdk.template.axl.api import AxlApi, Method, Verb
    from ..sdk.template.meta.schema import NodeType
except ImportError:
    pass
from .operation import Operation

__all__ = ["configure"]

logger = getLogger(__name__)


def filter_data(data: dict, method: "Method", api: "AxlApi") -> dict:
    """Filter a dictionary include only the keys allowable by the type.

    Args:
        data: The original dictionary to filter.
        axl_method: The Method instance containing the allowed keys.

    Returns:
        A new dictionary containing only the allowed keys from the type.
    """
    if method.verb == Verb.UPDATE:
        allowed_keys = {field.name for field in method.payload_type.fields}
        return {key: value for key, value in data.items() if key in allowed_keys}

    elif method.verb == Verb.ADD:
        container_type = method.payload_type

        for field in container_type.fields:
            if field.node_type == NodeType.ELEMENT:
                member_type = field
                break

        subtype = api.type(member_type.type_name)
        allowed_keys = {field.name for field in subtype.fields}
        return {
            member_type.name: {
                key: value for key, value in data[member_type.name].items() if key in allowed_keys
            }
        }

    elif method.verb == Verb.REMOVE:
        return data

    raise ValueError(f"Unknown verb: {method.verb} for method: {method.operation}")


def configure(
    axl: "AxlTemplate",
    operations: list[Operation],
    print_status: Callable[[str], None] = lambda msg: None,
    progress_handler: Callable[[float], None] = lambda progress: None,
    check_mode: bool = False,
) -> None:
    """Apply a list of AXL operations to a UCM server.

    Iterates over each :class:`~.operation.Operation` and executes the
    corresponding AXL call.  When *check_mode* is ``True`` no actual changes
    are made; the intended call is logged via *print_status* instead.

    Args:
        axl: An :class:`AxlTemplate` instance connected to the target UCM server.
        operations: Ordered list of operations to apply.
        print_status: Optional callback that receives human-readable status
            messages. Defaults to a no-op.
        progress_handler: Optional callback that receives a float in ``[0, 1]``
            indicating application progress. Defaults to a no-op.
        check_mode: When ``True``, simulate the operations without making any
            changes to the UCM server. Defaults to ``False``.

    Raises:
        ValueError: If an operation's action is unknown for its object type.
        Exception: Re-raises any exception raised by the underlying AXL call.
    """
    print_status("Commencing operation application")
    progress_handler(0)

    axl_api = AxlApi.from_wsdl(axl.client.wsdl)

    for index, operation in enumerate(operations):
        print_status(f"{operation.action} {operation.type}")
        object_api = axl_api.object(operation.type)
        method = object_api.method(operation.action)

        if method is None:
            logger.error("Unknown method: %s for type: %s", operation.action, operation.type)
            print_status(f"Warning: Unknown method: {operation.action} for type: {operation.type}")

        else:
            try:
                axl_operation = axl.operation(method.operation)
                data = filter_data(operation.data, method, axl_api)
                if check_mode:
                    print_status(f"Check mode: {method.operation}({data})")
                else:
                    axl_operation(**data)
                    print_status(f"Applied: {method.operation}({data})")

            except Exception as e:
                logger.error(
                    "Failed: %s(%s) with error: %s", method.operation, data, e, exc_info=True
                )
                raise

        progress_handler((index + 1.0) / len(operations))
