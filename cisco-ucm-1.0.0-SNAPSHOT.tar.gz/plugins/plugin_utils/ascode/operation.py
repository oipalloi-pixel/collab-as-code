# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from dataclasses import dataclass
from typing import Any

__all__ = ["Operation"]


@dataclass
class Operation:
    """Represents a single AXL configuration operation to apply to a UCM server.

    Attributes:
        action: The operation action to perform (e.g., ``"create"``, ``"update"``, ``"delete"``).
        type: The AXL object type to operate on (e.g., ``"Phone"``, ``"SipTrunk"``).
        data: The data payload for the operation. For create/update this is the full object
            dict; for delete this is an identifier dict (e.g., ``{"name": "..."}``).
    """

    action: str
    type: str
    data: dict[str, Any]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Operation":
        """Construct an Operation from a plain dictionary.

        Args:
            data: Dictionary with ``"action"``, ``"type"``, and ``"data"`` keys.

        Returns:
            A new :class:`Operation` instance populated from *data*.
        """
        return cls(
            action=data["action"],
            type=data["type"],
            data=data["data"],
        )
