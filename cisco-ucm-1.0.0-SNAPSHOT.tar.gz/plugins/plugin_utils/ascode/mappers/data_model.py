# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Mapper for converting AXL model to data model format.

This module provides functionality to convert from CUCM AXL SOAP API format
to a more human-friendly, infrastructure-as-code data model format.

The data model format is characterized by:
- snake_case naming conventions
- Normalized boolean values (True/False instead of "true"/"false")
- Flattened XFK (External Foreign Key) structures
- Removed UUID and ID fields
- Simplified nested structures
"""

from typing import Any, Callable

from .objects import registry

__all__ = [
    "from_axl_model",
]

_DISPATCHERS: dict[str, tuple[str, Any]] = {
    mod.AXL_TYPE: (mod.DATA_MODEL_KEY, mod.to_data_model) for mod in registry.OBJECTS.values()
}


def from_axl_model(data: Any, warn: Callable[[str], None] = lambda msg: None) -> Any:
    """Convert from AXL model format to data model format.

    Transforms CUCM AXL SOAP API responses into a simplified data model suitable
    for infrastructure-as-code workflows and human editing.

    Transformations applied:
    - Unwraps nested AXL structures (e.g., {"callManagerGroup": {...}} -> {...})
    - Converts camelCase to snake_case
    - Normalizes XFK structures (e.g., {"_value_1": "name", "uuid": "..."} -> "name")
    - Removes uuid and id fields
    - Converts boolean strings to actual booleans

    Args:
        data: Dictionary containing AXL-formatted CUCM data with resource type keys
              (e.g., {"CallManagerGroup": [...], "Css": [...], ...})

    Returns:
        Dictionary with 'ucm' root key containing data model formatted data.

    Example:
        >>> axl_data = {
        ...     "CallManagerGroup": [{
        ...         "callManagerGroup": {
        ...             "name": "Default",
        ...             "tftpDefault": "false",
        ...         }
        ...     }]
        ... }
        >>> result = from_axl_model(axl_data)
        >>> result["ucm"]["call_manager_groups"][0]["name"]
        'Default'
        >>> result["ucm"]["call_manager_groups"][0]["tftp_default"]
        False
    """
    model = {}
    for axl_type, (output_key, mapper) in _DISPATCHERS.items():
        if axl_type in data:
            model[output_key] = [mapper(item) for item in data[axl_type]]

    for key in data:
        if key not in _DISPATCHERS:
            warn(f"Warning: Ignoring unsupported AXL type '{key}' found in input data.")

    return {"ucm": model}
