# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "SipTrunk"
DATA_MODEL_KEY = "sip_trunks"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    trunk: dict = item["sipTrunk"]
    trunk.pop("versionStamp", None)
    trunk.pop("ctiid", None)
    return common.normalize(trunk)


def to_axl(item: dict) -> dict:
    prepared = common.prepare(item)
    for field in ("loadInformation", "sigDigits"):
        if isinstance(prepared.get(field), dict):
            prepared[field] = common.denormalize_text_attr(prepared[field])
    if isinstance(prepared.get("externalPresentationInfo"), dict):
        prepared["externalPresentationInfo"] = common.denormalize_external_presentation_info(
            prepared["externalPresentationInfo"]
        )
    return {"sipTrunk": prepared}
