# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Auto-discovers and loads all per-object mapper modules from this package.

At import time, every *.py file in this directory (except __init__ and
registry itself) is loaded as a module.  Each module must expose:

    AXL_TYPE       str  - CUCM SOAP resource type (e.g. "CallManagerGroup")
    DATA_MODEL_KEY str  - snake_case collection key (e.g. "call_manager_groups")
    COLLECT_METHOD str  - "get" or "list"
    DELETABLE      bool - whether the object type supports delete

    to_data_model(item: dict) -> dict
    to_axl(item: dict) -> dict

OBJECTS is the authoritative registry: a dict keyed by AXL_TYPE.
"""

import importlib
from pathlib import Path
from types import ModuleType

_REQUIRED = ("AXL_TYPE", "DATA_MODEL_KEY", "COLLECT_METHOD", "DELETABLE", "to_data_model", "to_axl")


def _validate(mod: ModuleType) -> None:
    missing = [attr for attr in _REQUIRED if not hasattr(mod, attr)]
    if missing:
        raise AttributeError(f"{mod.__name__} is missing required attributes: {missing}")


def _load_module(stem: str) -> ModuleType:
    module = importlib.import_module(f".{stem}", package=__package__)
    _validate(module)
    return module


def _load() -> dict[str, ModuleType]:
    modules = [
        _load_module(s)
        for s in sorted(
            path.stem
            for path in Path(__file__).parent.glob("*.py")
            if not path.stem.startswith("_")
        )
    ]
    return {module.AXL_TYPE: module for module in modules}


OBJECTS: dict[str, ModuleType] = _load()
