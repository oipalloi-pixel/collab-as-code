# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "Location"
DATA_MODEL_KEY = "locations"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    location = item["location"]
    if location.get("relatedLocations"):
        location = {**location, "relatedLocations": location["relatedLocations"]["relatedLocation"]}
    if location.get("betweenLocations"):
        location = {**location, "betweenLocations": location["betweenLocations"]["betweenLocation"]}
    if location.get("id", 0) < 1:
        location = {
            k: v for k, v in location.items() if k not in ("relatedLocations", "betweenLocations")
        }
    else:
        related = location.get("relatedLocations", [])
        if len(related) == 1 and related[0]["locationName"]["_value_1"] == location["name"]:
            location = {k: v for k, v in location.items() if k != "relatedLocations"}
    return common.normalize(location)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if "relatedLocations" in item:
        item = {**item, "relatedLocations": {"relatedLocation": item["relatedLocations"]}}
    if "betweenLocations" in item:
        item = {**item, "betweenLocations": {"betweenLocation": item["betweenLocations"]}}
    try:
        if len(item["betweenLocations"]["betweenLocation"]) == 0:
            raise Exception("No betweenLocations found; adding default Hub_None location.")
    except Exception:
        item["betweenLocations"] = {"betweenLocation": [{"locationName": "Hub_None"}]}
    return {"location": item}
