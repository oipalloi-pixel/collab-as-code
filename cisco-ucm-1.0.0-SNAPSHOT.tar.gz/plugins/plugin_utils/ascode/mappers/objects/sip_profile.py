# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "SipProfile"
DATA_MODEL_KEY = "sip_profiles"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    return common.normalize(item["sipProfile"])


def to_axl(item: dict) -> dict:
    prepared = common.prepare(item)
    prepared["sendRecvSDPInMidCallInvite"] = prepared.pop("sendRecvSdpInMidCallInvite", None)
    prepared["optionsPingIntervalWhenStatusNotOK"] = prepared.pop(
        "optionsPingIntervalWhenStatusNotOk", None
    )
    prepared["optionsPingIntervalWhenStatusOK"] = prepared.pop(
        "optionsPingIntervalWhenStatusOk", None
    )
    if isinstance(prepared.get("externalPresentationInfo"), dict):
        prepared["externalPresentationInfo"] = common.denormalize_external_presentation_info(
            prepared["externalPresentationInfo"]
        )
    return {"sipProfile": prepared}
