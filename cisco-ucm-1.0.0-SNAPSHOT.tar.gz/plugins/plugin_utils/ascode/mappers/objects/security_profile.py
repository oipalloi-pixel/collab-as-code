# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "PhoneSecurityProfile"
DATA_MODEL_KEY = "security_profiles"
COLLECT_METHOD = "list"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    profile: dict = item["phoneSecurityProfile"]
    profile["enableOauthAuthentication"] = profile.pop("EnableOAuthAuthentication", None)
    return common.normalize(profile)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    item["EnableOAuthAuthentication"] = item.pop("enableOauthAuthentication", None)
    return {"phoneSecurityProfile": item}
