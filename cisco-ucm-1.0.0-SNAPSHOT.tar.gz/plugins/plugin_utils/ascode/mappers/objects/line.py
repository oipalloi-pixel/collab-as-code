# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "Line"
DATA_MODEL_KEY = "lines"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    line = item["line"]
    if line.get("associatedDevices"):
        line = {**line, "associatedDevices": line["associatedDevices"]["device"]}
    return common.normalize(line)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if item.get("associatedDevices"):
        item = {**item, "associatedDevices": {"device": item["associatedDevices"]}}
    return {"line": item}
