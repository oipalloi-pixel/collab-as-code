# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Shared normalisation and denormalisation helpers used by all object mappers.

Provides the primitive utilities (XFK handling, boolean conversion) and the
two composed pipeline functions (normalize, prepare) that are the building
blocks of every per-object to_data_model / to_axl implementation.
"""

from typing import Any

from .. import trees

_PRIORITY_KEYS = ("name", "pattern", "description")

__all__ = [
    "is_xfk",
    "normalize_xfk",
    "normalize_boolean",
    "normalize_value_1",
    "denormalize_boolean",
    "denormalize_text_attr",
    "denormalize_external_presentation_info",
    "denormalize_confidential_access",
    "normalize",
    "prepare",
]


def is_xfk(obj: Any) -> bool:
    """Return True if obj is an AXL External Foreign Key dict.

    XFK objects are dicts with exactly two keys: 'uuid' and '_value_1'.
    """
    return isinstance(obj, dict) and len(obj) == 2 and "uuid" in obj and "_value_1" in obj


def normalize_xfk(obj: Any) -> Any:
    """Replace all XFK dicts with their _value_1 value, recursively."""

    def transform(value: Any) -> Any:
        if is_xfk(value):
            return value.get("_value_1")
        return value

    return trees.transform(obj, value_mapper=transform)


def normalize_value_1(data: Any) -> Any:
    """Rename '_value_1' keys to 'value' for zeep simple-content types.

    Safe to call after normalize_xfk: any '_value_1' key remaining at that
    point belongs to a text-content-with-attributes type (e.g. loadInformation,
    sigDigits), not an XFK reference.
    """
    return trees.transform(data, key_mapper=lambda k: "value" if k == "_value_1" else k)


def normalize_boolean(data: Any) -> Any:
    """Convert boolean strings to Python booleans, recursively.

    Handles all axlapi:boolean forms: 'true'/'false' and the short 't'/'f'.
    """

    def transform(value: Any) -> Any:
        if isinstance(value, str):
            if value in ("true", "t"):
                return True
            elif value in ("false", "f"):
                return False
        return value

    return trees.transform(data, value_mapper=transform)


def denormalize_text_attr(d: dict) -> dict:
    """Rename 'value' back to '_value_1' for a zeep simple-content type dict.

    The inverse of normalize_value_1, applied per-field in prepare pipelines
    where the target AXL field is a simple-content extension (e.g.
    loadInformation, sigDigits). Operates on the top level of d only.
    """
    if "value" not in d:
        return d
    return {"_value_1": d["value"], **{k: v for k, v in d.items() if k != "value"}}


def denormalize_external_presentation_info(d: dict) -> dict:
    """Collapse the externalPresentationInfo xsd:choice to a single branch.

    UCM's GET response returns both branches (isAnonymous and presentationInfo)
    simultaneously. When writing back, exactly one must be sent. Selects
    isAnonymous when it is truthy, otherwise presentationInfo.
    """
    if d.get("isAnonymous") == "true":
        return {"isAnonymous": "true"}
    return {"presentationInfo": d.get("presentationInfo", {})}


def denormalize_confidential_access(item: dict) -> dict:
    """Strip confidentialAccess when mode is unset.

    confidentialAccess is optional (minOccurs=0) and XCALMode does not accept
    None. When mode is unset, UCM returns None; drop the whole block so the
    API uses its default rather than rejecting the call.
    """
    ca = item.get("confidentialAccess")
    if isinstance(ca, dict) and ca.get("confidentialAccessMode") is None:
        del item["confidentialAccess"]
    return item


def denormalize_boolean(data: Any) -> Any:
    """Convert Python booleans to 'true'/'false' strings, recursively."""

    def transform(value: Any) -> Any:
        if isinstance(value, bool):
            return "true" if value else "false"
        return value

    return trees.transform(data, value_mapper=transform)


def prioritize_keys(data: Any, priority_keys: tuple[str, ...] = _PRIORITY_KEYS) -> Any:
    """Recursively move selected keys to the front of dictionaries.

    Keeps relative order for all non-priority keys while ensuring well-known
    identity fields (e.g. name, pattern) are emitted first when present.
    """
    if isinstance(data, list):
        return [prioritize_keys(item, priority_keys) for item in data]

    if isinstance(data, dict):
        prioritized_data = {
            key: prioritize_keys(data[key], priority_keys)
            for key in priority_keys
            if key in data
        }
        prioritized_key_set = set(priority_keys)
        prioritized_data.update(
            {
                key: prioritize_keys(value, priority_keys)
                for key, value in data.items()
                if key not in prioritized_key_set
            }
        )
        return prioritized_data

    return data


def normalize(data: Any) -> Any:
    """Apply the full AXL-to-data-model normalisation pipeline.

    Applies snake_case conversion, XFK flattening, uuid/id removal, key
    prioritisation, and boolean normalisation in the correct order. Call this
    on an already-unwrapped resource dict (i.e. after stripping the outer AXL
    envelope key).
    """
    data = trees.snake_case(data)
    data = normalize_xfk(data)
    data = trees.transform(data, dictionary_filter=lambda k, _: k != "uuid")
    data = trees.transform(data, dictionary_filter=lambda k, _: k != "id")
    data = trees.transform(data, dictionary_filter=lambda k, _: k != "dial_plan_wizard_gen_id")
    data = trees.transform(data, dictionary_filter=lambda k, _: k != "dial_plan_wizard_genld")
    data = normalize_value_1(data)
    data = normalize_boolean(data)
    data = prioritize_keys(data)
    return data


def prepare(item: dict) -> dict:
    """Apply the full data-model-to-AXL preparation pipeline.

    Reverses boolean normalisation (bool -> 'true'/'false') and converts
    snake_case keys to camelCase. Call this on a flat data-model dict before
    wrapping it in the AXL envelope key.
    """
    item = denormalize_boolean(item)
    item = trees.camel_case(item)
    item = denormalize_confidential_access(item)
    return item
