# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "ProcessNode"
DATA_MODEL_KEY = "process_nodes"
COLLECT_METHOD = "get"
DELETABLE = False


def to_data_model(item: dict) -> dict:
    return common.normalize(item["processNode"])


def to_axl(item: dict) -> dict:
    return {"processNode": common.prepare(item)}
