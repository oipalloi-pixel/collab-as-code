# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "Region"
DATA_MODEL_KEY = "regions"
COLLECT_METHOD = "get"
DELETABLE = True


def _related_regions(region: dict) -> list[dict]:
    outer: dict = region.get("relatedRegions")
    if outer is None:
        return []

    related = outer.get("relatedRegion")
    if not related:
        return []

    if len(related) == 1 and related[0]["regionName"]["_value_1"] == region["name"]:
        return []

    return related


def to_data_model(item: dict) -> dict:
    region = item["region"]
    related = _related_regions(region)
    if not related:
        region = {k: v for k, v in region.items() if k != "relatedRegions"}

    else:
        region = {**region, "relatedRegions": related}

    return common.normalize(region)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if item.get("relatedRegions"):
        item = {**item, "relatedRegions": {"relatedRegion": item["relatedRegions"]}}
    elif "relatedRegions" in item:
        item = {k: v for k, v in item.items() if k != "relatedRegions"}
    return {"region": item}
