# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "Css"
DATA_MODEL_KEY = "calling_search_spaces"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    css = item["css"]
    if css.get("members"):
        css = {**css, "members": css["members"]["member"]}
    return common.normalize(css)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if "members" in item:
        item = {**item, "members": {"member": item["members"]}}
    return {"css": item}
