# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "MediaResourceList"
DATA_MODEL_KEY = "media_resource_lists"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    mrl = item["mediaResourceList"]
    if mrl.get("members"):
        mrl = {**mrl, "members": mrl["members"]["member"]}
    return common.normalize(mrl)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if "members" in item:
        item = {**item, "members": {"member": item["members"]}}
    return {"mediaResourceList": item}
