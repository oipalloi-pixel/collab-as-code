# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from . import _common as common

AXL_TYPE = "TimeSchedule"
DATA_MODEL_KEY = "time_schedules"
COLLECT_METHOD = "get"
DELETABLE = True


def to_data_model(item: dict) -> dict:
    ts = item["timeSchedule"]
    if ts.get("members"):
        ts = {**ts, "members": ts["members"]["member"]}
    return common.normalize(ts)


def to_axl(item: dict) -> dict:
    item = common.prepare(item)
    if "members" in item:
        item = {**item, "members": {"member": item["members"]}}
    return {"timeSchedule": item}
