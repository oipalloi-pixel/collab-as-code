# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Mapper for converting data model to AXL model format.

This module provides functionality to convert from infrastructure-as-code
data model format back to CUCM AXL SOAP API format for API calls.

The AXL model format is characterized by:
- camelCase naming conventions
- String boolean values ("true"/"false")
- Nested wrapper structures
- Wrapped collections with singular key names
"""

from copy import deepcopy
from typing import Any

from .objects import registry

__all__ = [
    "from_data_model",
    "OBJECT_PRECEDENCE",
]


"""Ordered list of CUCM object types for determining processing precedence.

Objects should be processed in this order to respect dependencies,
with foundational objects (like CallManagerGroup, Location) processed
before dependent objects (like Phone, SipTrunk).
"""
OBJECT_PRECEDENCE = [
    "Location",
    "Region",
    "TimePeriod",
    "TimeSchedule",
    "PhoneNtp",
    "DateTimeGroup",
    "RoutePartition",
    "RoutePattern",
    "Css",
    "MediaResourceGroup",
    "MediaResourceList",
    "DevicePool",
    "SipProfile",
    "SipTrunkSecurityProfile",
    "SipTrunk",
    "RouteGroup",
    "CallManagerGroup",
    "DateTimeGroup",
    "Line",
    "ProcessNode",
    "ProcessNodeService",
    "ServiceParameter",
    "Phone",
    "Region",
    "RouteList",
    "RoutePlan",
    "SipProfile",
    "User",
]


_DISPATCHERS: dict[str, tuple[str, Any]] = {
    mod.DATA_MODEL_KEY: (mod.AXL_TYPE, mod.to_axl) for mod in registry.OBJECTS.values()
}


def from_data_model(model_data: Any) -> Any:
    """Convert from data model format to AXL model format.

    Reverses the transformations done by data_model.from_axl_model to prepare
    data for CUCM AXL API calls.

    Transformations applied:
    - Converts snake_case back to camelCase
    - Wraps structures in AXL envelope keys
    - Converts boolean values back to "true"/"false" strings
    - Wraps collections with singular key names (e.g., members -> {"member": [...]})

    Note: UUID and ID fields are NOT restored as they were removed during
    from_axl_model transformation and should be managed by the API.

    Args:
        model_data: The data model data, either:
                   - Dictionary with 'ucm' root key (typical from YAML files)
                   - Direct dictionary (will be processed as-is)

    Returns:
        Dictionary with AXL-formatted data structures keyed by resource type
        (e.g., {"CallManagerGroup": [...], "Css": [...], ...})

    Example:
        >>> data_model = {
        ...     "ucm": {
        ...         "call_manager_groups": [{
        ...             "name": "Default",
        ...             "tftp_default": False,
        ...         }]
        ...     }
        ... }
        >>> result = from_data_model(data_model)
        >>> result["CallManagerGroup"][0]["callManagerGroup"]["name"]
        'Default'
        >>> result["CallManagerGroup"][0]["callManagerGroup"]["tftpDefault"]
        'false'
    """
    if isinstance(model_data, dict) and "ucm" in model_data:
        model = deepcopy(model_data["ucm"])
    else:
        model = deepcopy(model_data)

    result = {}
    for data_key, (axl_type, mapper) in _DISPATCHERS.items():
        if data_key in model:
            result[axl_type] = [mapper(item) for item in model[data_key]]
    return result
