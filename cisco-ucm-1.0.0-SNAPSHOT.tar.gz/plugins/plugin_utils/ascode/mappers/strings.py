# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from re import split as re_split

__all__ = [
    "camel_case",
    "kebab_case",
    "pascal_case",
    "snake_case",
]


def tokenize(name: str) -> list[str]:
    """
    Break variable names into their component words. Numbers are grouped with the previous word

    Supports snake_case, kebab-case, camelCase, and PascalCase.

    Args:
        name (str): The variable name to tokenize.

    Returns:
        list[str]: List of lowercase words that make up the variable name.

    Examples:
        >>> tokenize_variable_name("snake_case_variable")
        ['snake', 'case', 'variable']

        >>> tokenize_variable_name("kebab-case-variable")
        ['kebab', 'case', 'variable']

        >>> tokenize_variable_name("camelCaseVariable")
        ['camel', 'case', 'variable']

        >>> tokenize_variable_name("PascalCaseVariable12")
        ['pascal', 'case', 'variable12']

        >>> tokenize_variable_name("mixed_Case-Variable")
        ['mixed', 'case', 'variable']
    """
    if not name or not isinstance(name, str):
        return []

    # Handle snake_case and kebab-case first (simple splitting)
    if "_" in name or "-" in name:
        return list(map(str.lower, re_split(r"[_-]", name)))

    words = []
    word = ""
    for index, this_char in enumerate(name):
        prev_char = name[index - 1] if index > 0 else None
        next_char = name[index + 1] if index + 1 < len(name) else ""
        is_new_word = (
            prev_char is None
            or (not prev_char.isupper() and this_char.isupper())
            or (this_char.isupper() and next_char.islower())
        )
        if is_new_word:
            if word:
                words.append(word.lower())
            word = this_char
        else:
            word += this_char
    if word:
        words.append(word.lower())
    return words


def camel_case(s: str) -> str:
    """
    Convert a variable name to camelCase.

    Supports conversion from snake_case, kebab-case, PascalCase, or mixed formats.

    Args:
        s (str): The string to convert.

    Returns:
        str: The string converted to camelCase.

    Examples:
        >>> camel_case("snake_case_variable")
        'snakeCaseVariable'

        >>> camel_case("PascalCaseVariable")
        'pascalCaseVariable'

        >>> camel_case("kebab-case-variable")
        'kebabCaseVariable'
    """
    words = tokenize(s)
    if not words:
        return s

    return words[0] + "".join(word.capitalize() for word in words[1:])


def kebab_case(s: str) -> str:
    """
    Convert a variable name to kebab-case.

    Supports conversion from camelCase, PascalCase, kebab-case, or mixed formats.

    Args:
        s (str): The string to convert.

    Returns:
        str: The string converted to kebab-case.

    Examples:
        >>> kebab_case("camelCaseVariable")
        'camel-case-variable'

        >>> kebab_case("PascalCaseVariable")
        'pascal-case-variable'

        >>> kebab_case("kebab-case-variable")
        'kebab-case-variable'
    """
    words = tokenize(s)
    return "-".join(words)


def pascal_case(s: str) -> str:
    """
    Convert a variable name to PascalCase.

    Supports conversion from snake_case, kebab-case, camelCase, or mixed formats.

    Args:
        s (str): The string to convert.

    Returns:
        str: The string converted to PascalCase.

    Examples:
        >>> pascal_case("snake_case_variable")
        'SnakeCaseVariable'

        >>> pascal_case("PascalCaseVariable")
        'PascalCaseVariable'

        >>> pascal_case("kebab-case-variable")
        'KebabCaseVariable'
    """
    words = tokenize(s)
    if not words:
        return s

    return "".join(word.capitalize() for word in words)


def snake_case(s: str) -> str:
    """
    Convert a variable name to snake_case.

    Supports conversion from camelCase, PascalCase, kebab-case, or mixed formats.

    Args:
        s (str): The string to convert.

    Returns:
        str: The string converted to snake_case.

    Examples:
        >>> snake_case("camelCaseVariable")
        'camel_case_variable'

        >>> snake_case("PascalCaseVariable")
        'pascal_case_variable'

        >>> snake_case("kebab-case-variable")
        'kebab_case_variable'
    """
    words = tokenize(s)
    return "_".join(words)
