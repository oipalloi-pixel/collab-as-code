# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from typing import Any, Callable

from . import strings

__all__ = ["transform", "snake_case", "camel_case"]


def transform(
    obj: Any,
    key_mapper: Callable[[str], str] = lambda k: k,
    value_mapper: Callable[[Any], Any] = lambda v: v,
    dictionary_filter: Callable[[str, Any], bool] = lambda k, v: True,
) -> Any:
    """Recursively transform nested data structures (dicts, lists, and primitives).

    Traverses the entire object tree and applies transformations to keys and values,
    and filters dictionary entries. All three operations can be used together or
    independently.

    Args:
        obj: The object to transform (dict, list, or primitive value).
        key_mapper: Function to transform dictionary keys. Applied to all keys
            in nested dictionaries. Defaults to identity function.
        value_mapper: Function to transform values at all levels. Applied before
            recursion to allow inspection and transformation of container types.
            Defaults to identity function.
        dictionary_filter: Function to filter dictionary items. Return False to
            exclude a key-value pair. Defaults to function that includes all items.

    Returns:
        The transformed object with the same structure as the input.

    Examples:
        >>> # Transform keys to uppercase
        >>> transform({"name": "test"}, key_mapper=str.upper)
        {"NAME": "test"}

        >>> # Transform string values to uppercase
        >>> transform({"name": "test"}, value_mapper=lambda v: v.upper() if isinstance(v, str) else v)
        {"name": "TEST"}

        >>> # Filter out keys named "uuid"
        >>> transform({"name": "test", "uuid": "123"}, dictionary_filter=lambda k, v: k != "uuid")
        {"name": "test"}
    """  # noqa : E501
    # Recursively process lists
    if isinstance(obj, list):
        return [
            transform(
                value_mapper(item),
                key_mapper,
                value_mapper,
                dictionary_filter,
            )
            for item in obj
        ]

    # Recursively process dictionaries
    if isinstance(obj, dict):
        return {
            key_mapper(key): transform(
                value_mapper(value),
                key_mapper,
                value_mapper,
                dictionary_filter,
            )
            for key, value in obj.items()
            if dictionary_filter(key, value)
        }

    # Apply value_mapper to leaf values (primitives)
    return value_mapper(obj)


def snake_case(obj: Any) -> Any:
    """Convert all dictionary keys to snake_case recursively.

    Recursively traverses the object tree (dicts and lists) and converts all
    dictionary keys from camelCase, PascalCase, or kebab-case to snake_case.

    Args:
        obj: The object tree to transform (dict, list, or primitive).

    Returns:
        The transformed object with all keys in snake_case.

    Examples:
        >>> snake_case({"firstName": "John", "lastName": "Doe"})
        {"first_name": "John", "last_name": "Doe"}

        >>> snake_case({"userInfo": {"fullName": "John Doe"}})
        {"user_info": {"full_name": "John Doe"}}
    """
    return transform(obj, key_mapper=strings.snake_case)


def camel_case(obj: Any) -> Any:
    """Convert all dictionary keys to camelCase recursively.

    Recursively traverses the object tree (dicts and lists) and converts all
    dictionary keys from snake_case, PascalCase, or kebab-case to camelCase.

    Args:
        obj: The object tree to transform (dict, list, or primitive).

    Returns:
        The transformed object with all keys in camelCase.

    Examples:
        >>> camel_case({"first_name": "John", "last_name": "Doe"})
        {"firstName": "John", "lastName": "Doe"}

        >>> camel_case({"user_info": {"full_name": "John Doe"}})
        {"userInfo": {"fullName": "John Doe"}}
    """
    return transform(obj, key_mapper=strings.camel_case)
