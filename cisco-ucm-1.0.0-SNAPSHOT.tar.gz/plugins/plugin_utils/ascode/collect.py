# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Module for collecting configuration data from a Cisco UCM server via AXL."""

from logging import getLogger
from typing import Any, Callable

try:
    from ..sdk.template import AxlTemplate
    from ..sdk.template.axl.api import AxlApi
except ImportError:
    pass
from .mappers import strings

__all__ = ["collect"]

logger = getLogger(__name__)


def entity_name(entity: dict[str, Any]) -> str:
    item = next(iter(entity.values()))
    if isinstance(item, dict):
        return item.get("name") or item.get("pattern") or None
    return None


def collect(
    axl: "AxlTemplate",
    object_defs: list[tuple[str, str]],
    print_status: Callable[[str], None] = lambda msg: None,
    progress_handler: Callable[[float], None] = lambda progress: None,
) -> list[dict]:
    """Collect AXL objects from a UCM server.

    Iterates over the requested object types and fetches their data from the
    UCM AXL API, using either the *list* or *get* method strategy depending on
    the value provided in *object_defs*.

    Args:
        axl: An :class:`AxlTemplate` instance connected to the target UCM server.
        object_defs: Sequence of ``(object_name, method)`` tuples where
            *object_name* is the AXL object type (e.g. ``"Phone"``) and *method*
            is either ``"get"`` (fetch each object individually by UUID) or
            ``"list"`` (fetch all objects in a single list call).
        print_status: Optional callback that receives human-readable status
            messages. Defaults to a no-op.
        progress_handler: Optional callback that receives a float in ``[0, 1]``
            indicating collection progress. Defaults to a no-op.

    Returns:
        Dictionary mapping each *object_name* to its list of collected entity
        dicts.
    """
    result = {}
    axl_api = AxlApi.from_wsdl(axl.client.wsdl)

    for index, (object_name, method) in enumerate(object_defs):
        print_status(f"Collecting {object_name}")
        object_api = axl_api.object(object_name)
        list_method = object_api.method("list")
        get_method = object_api.method("get")
        entities: list[dict[str, Any]] = []

        if method == "get":
            uuids = [e["uuid"] for e in axl.iterate_entity(list_method.operation, tags=["uuid"])]
            for entity_index, uuid in enumerate(uuids):
                entity = axl.call(get_method.operation, uuid=uuid)
                entities.append(entity)
                print_status(
                    f"Collected {object_name} [{entity_index + 1}] ({entity_name(entity)})"
                )
                completion_ratio = (index + (entity_index / len(uuids))) / len(object_defs)
                progress_handler(completion_ratio)

        elif method == "list":
            wrapper = strings.camel_case(object_name)
            entities = [{wrapper: e} for e in axl.iterate_entity(list_method.operation)]
            completion_ratio = (index + 1) / len(object_defs)
            progress_handler(completion_ratio)

        result[object_name] = entities

    progress_handler(1)
    return result
