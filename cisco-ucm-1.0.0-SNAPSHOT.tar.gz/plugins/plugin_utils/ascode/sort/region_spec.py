# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Region TopoSpec functions."""

from collections.abc import Iterable

from ..operation import Operation
from .spec_common import LinkPolicy, split_cycle_links_for_create
from .spec_contract import TopoSpec


def region_key(op: Operation) -> str:
    reg = op.data.get("region", op.data)
    return reg.get("name", "")


def region_dependencies(op: Operation) -> Iterable[str]:
    reg = op.data.get("region", op.data)
    links = (reg.get("relatedRegions") or {}).get("relatedRegion") or []
    return {entry["regionName"] for entry in links if "regionName" in entry}


def region_split_cycle(op: Operation, cycle_names: set[str]) -> tuple[Operation, list[Operation]]:
    """Strip intra-cycle region links from a create, returning a deferred update."""
    return split_cycle_links_for_create(
        op,
        cycle_names,
        wrapper_key="region",
        link_policies=(
            LinkPolicy(
                outer_key="relatedRegions",
                inner_key="relatedRegion",
                name_field="regionName",
            ),
        ),
    )


REGION_TOPO_SPEC = TopoSpec(
    object_type="Region",
    key=region_key,
    dependencies=region_dependencies,
    on_cycle="raise",
    sort_actions=("create",),
    split_cycle=region_split_cycle,
)
