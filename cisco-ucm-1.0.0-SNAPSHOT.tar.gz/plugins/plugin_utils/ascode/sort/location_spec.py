# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Location TopoSpec functions."""

from collections.abc import Iterable

from ..operation import Operation
from .spec_common import LinkPolicy, split_cycle_links_for_create
from .spec_contract import TopoSpec


def location_key(op: Operation) -> str:
    # Creates are wrapped: {"location": {"name": ...}}
    # Updates are unwrapped by compare_objects: {"name": ..., "betweenLocations": ...}
    loc = op.data.get("location", op.data)
    return loc.get("name", "")


def location_dependencies(op: Operation) -> Iterable[str]:
    loc = op.data.get("location", op.data)
    link_groups = [
        loc.get("betweenLocations", {}).get("betweenLocation") or [],
        loc.get("relatedLocations", {}).get("relatedLocation") or [],
    ]
    return {
        entry["locationName"] for group in link_groups for entry in group if "locationName" in entry
    }


def location_split_cycle(op: Operation, cycle_names: set[str]) -> tuple[Operation, list[Operation]]:
    """Strip intra-cycle location links from a create, returning a deferred update."""
    return split_cycle_links_for_create(
        op,
        cycle_names,
        wrapper_key="location",
        link_policies=(
            # AXL addLocation requires betweenLocations to be present.
            # Hub_None always exists in UCM and is a safe placeholder;
            # the deferred update replaces it with the intended entries.
            LinkPolicy(
                outer_key="betweenLocations",
                inner_key="betweenLocation",
                name_field="locationName",
                placeholder_name="Hub_None",
            ),
            LinkPolicy(
                outer_key="relatedLocations",
                inner_key="relatedLocation",
                name_field="locationName",
            ),
        ),
    )


LOCATION_TOPO_SPEC = TopoSpec(
    object_type="Location",
    key=location_key,
    dependencies=location_dependencies,
    on_cycle="raise",
    sort_actions=("create",),
    split_cycle=location_split_cycle,
)
