# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Common helpers for TopoSpec split-cycle implementations."""

from typing import Any, NamedTuple

from ..operation import Operation


class LinkPolicy(NamedTuple):
    """How to process one relationship list when splitting cyclic creates."""

    outer_key: str
    inner_key: str
    name_field: str
    placeholder_name: str | None = None


def split_cycle_links_for_create(
    op: Operation,
    cycle_names: set[str],
    *,
    wrapper_key: str,
    link_policies: tuple[LinkPolicy, ...],
) -> tuple[Operation, list[Operation]]:
    """Split one create op into a stripped create plus deferred update when cyclic links exist."""
    if op.action != "create":
        return op, []

    wrapped = wrapper_key in op.data
    inner = op.data[wrapper_key] if wrapped else op.data
    stripped_inner = dict(inner)
    deferred: dict[str, Any] = {}

    for policy in link_policies:
        links = (inner.get(policy.outer_key) or {}).get(policy.inner_key) or []
        if not links:
            continue

        cyclic_links = [e for e in links if e.get(policy.name_field) in cycle_names]
        if not cyclic_links:
            continue

        # Send the full list in the deferred UPDATE so replace semantics preserve intent.
        deferred[policy.outer_key] = {policy.inner_key: links}
        non_cyclic = [e for e in links if e.get(policy.name_field) not in cycle_names]
        if non_cyclic:
            stripped_inner[policy.outer_key] = {policy.inner_key: non_cyclic}
        elif policy.placeholder_name is not None:
            stripped_inner[policy.outer_key] = {
                policy.inner_key: [{policy.name_field: policy.placeholder_name}]
            }
        else:
            stripped_inner.pop(policy.outer_key, None)

    if not deferred:
        return op, []

    name = inner.get("name", "")
    stripped_data = {wrapper_key: stripped_inner} if wrapped else stripped_inner
    stripped_op = Operation(action="create", type=op.type, data=stripped_data)
    followup_op = Operation(action="update", type=op.type, data={"name": name, **deferred})
    return stripped_op, [followup_op]
