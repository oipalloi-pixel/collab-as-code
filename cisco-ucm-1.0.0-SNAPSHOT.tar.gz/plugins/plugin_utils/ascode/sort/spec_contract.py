# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Contract types and validation for topological sorting specs."""

from collections.abc import Iterable
from typing import Callable, Literal, NamedTuple

from ..operation import Operation

_ALLOWED_ON_CYCLE = {"raise", "best_effort"}
_ALLOWED_ACTIONS = {"create", "update", "delete"}


class TopoSpec(NamedTuple):
    """Key and dependency extractors for topological sorting of a single AXL object type."""

    object_type: str
    key: Callable[[Operation], str]
    dependencies: Callable[[Operation], Iterable[str]]
    on_cycle: Literal["raise", "best_effort"] = "raise"
    sort_actions: tuple[str, ...] = ("create", "update")
    split_cycle: Callable[[Operation, set[str]], tuple[Operation, list[Operation]]] | None = None

    def validate(self) -> None:
        """Validate this TopoSpec against the expected contract."""
        obj_type = self.object_type
        if not obj_type:
            raise ValueError("Invalid TopoSpec: object_type must be a non-empty string")
        if not callable(self.key):
            raise ValueError(f"Invalid TopoSpec for {obj_type}: key must be callable")
        if not callable(self.dependencies):
            raise ValueError(f"Invalid TopoSpec for {obj_type}: dependencies must be callable")
        if self.on_cycle not in _ALLOWED_ON_CYCLE:
            allowed = ", ".join(sorted(_ALLOWED_ON_CYCLE))
            raise ValueError(
                f"Invalid TopoSpec for {obj_type}: on_cycle must be one of [{allowed}]"
            )
        if not self.sort_actions:
            raise ValueError(f"Invalid TopoSpec for {obj_type}: sort_actions must be non-empty")
        invalid_actions = [action for action in self.sort_actions if action not in _ALLOWED_ACTIONS]
        if invalid_actions:
            allowed = ", ".join(sorted(_ALLOWED_ACTIONS))
            raise ValueError(
                f"Invalid TopoSpec for {obj_type}: sort_actions contains invalid values "
                f"{invalid_actions}; allowed values are [{allowed}]"
            )
        if self.split_cycle is not None and not callable(self.split_cycle):
            raise ValueError(
                f"Invalid TopoSpec for {obj_type}: split_cycle must be callable or None"
            )


def validate_topo_sort_specs(specs: Iterable[TopoSpec]) -> None:
    """Validate the runtime contract for every TopoSpec entry."""
    seen_types: set[str] = set()
    for spec in specs:
        spec.validate()
        if spec.object_type in seen_types:
            raise ValueError(f"Duplicate TopoSpec object_type: {spec.object_type}")
        seen_types.add(spec.object_type)
