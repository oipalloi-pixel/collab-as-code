# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Type-specific dependency specs for ordering AXL operations."""

from .location_spec import LOCATION_TOPO_SPEC
from .region_spec import REGION_TOPO_SPEC
from .spec_contract import TopoSpec, validate_topo_sort_specs

TOPO_SPECS: tuple[TopoSpec, ...] = (
    LOCATION_TOPO_SPEC,
    REGION_TOPO_SPEC,
)


# Map by object type for direct lookup where needed.
TOPO_SORT_SPECS: dict[str, TopoSpec] = {spec.object_type: spec for spec in TOPO_SPECS}


validate_topo_sort_specs(TOPO_SPECS)
