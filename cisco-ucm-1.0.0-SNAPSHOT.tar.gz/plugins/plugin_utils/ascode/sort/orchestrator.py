# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Utilities for ordering UCM configuration operations."""

from ..mappers import axl_model
from ..operation import Operation
from . import core, specs

__all__ = ["sort_changes", "split_cyclic_creates", "topological_sort", "TopoSpec"]
topological_sort = core.topological_sort
TopoSpec = specs.TopoSpec


def _sort_key_for_action(
    operation: Operation,
    precedence_index: dict[str, int],
    default_index: int,
) -> tuple[int, int, int]:
    """Return base ordering key by action and object precedence."""
    index = precedence_index.get(operation.type, default_index)

    if operation.action == "delete":
        # Deletes: process last, in reverse object precedence
        return (1, -index, 0)
    if operation.action == "create":
        # Adds: process by object precedence, adds before updates within each type
        return (0, index, 0)
    if operation.action == "update":
        # Updates: process by object precedence, updates after adds within each type
        return (0, index, 1)
    # Unknown actions: process last
    return (2, index, 0)


def _topologically_sort_registered_type_windows(sorted_ops: list[Operation]) -> list[Operation]:
    """Apply per-type topological sorting for registered self-referential specs."""
    for spec in specs.TOPO_SPECS:
        indices = [
            i
            for i, op in enumerate(sorted_ops)
            if op.type == spec.object_type and op.action in spec.sort_actions
        ]
        if not indices:
            continue

        start, end = indices[0], indices[-1] + 1
        sorted_ops = (
            sorted_ops[:start]
            + topological_sort(
                sorted_ops[start:end],
                key=spec.key,
                dependencies=spec.dependencies,
                on_cycle=spec.on_cycle,
            )
            + sorted_ops[end:]
        )

    return sorted_ops


def split_cyclic_creates(operations: list[Operation]) -> list[Operation]:
    """Split create operations that are in a mutual dependency cycle.

    For each type registered in :data:`specs.TOPO_SPECS` with a ``split_cycle``
    function, detects dependency cycles among the creates for that type and
    rewrites each cyclic create in two steps:

    1. A **bare create** with intra-cycle links removed so it can be sent to
       UCM without referencing peers that do not yet exist.
    2. A **deferred update** appended at the end of the returned list that
       restores the full intended link list once all cyclic peers exist.

    :func:`sort_changes` will place the deferred updates after all creates.
    Non-cyclic operations are returned unchanged.
    """
    result = list(operations)
    followups: list[Operation] = []

    for spec in specs.TOPO_SPECS:
        if spec.split_cycle is None:
            continue
        creates = [
            op
            for op in result
            if op.type == spec.object_type and op.action == "create"
        ]
        if len(creates) < 2:
            continue
        cycle_names = core.find_cycles(
            creates,
            key=spec.key,
            dependencies=spec.dependencies,
        )
        if not cycle_names:
            continue
        for index, op in enumerate(result):
            if (
                op.type != spec.object_type
                or op.action != "create"
                or spec.key(op) not in cycle_names
            ):
                continue
            stripped, deferred = spec.split_cycle(op, cycle_names)
            result[index] = stripped
            followups.extend(deferred)

    result.extend(followups)
    return result


def sort_changes(operations: list[Operation]) -> list[Operation]:
    """Sort changes by dependency order and action type.

    Ordering strategy:
    1. For each object type in precedence order (leaf nodes first):
       - Process all adds for that type
       - Then process all updates for that type
    2. Deletes: Process in reverse precedence order (dependent objects first)

    This ensures referenced objects exist before objects that reference them,
    and dependents are removed before their dependencies.
    """
    object_precedence = axl_model.OBJECT_PRECEDENCE
    precedence_index = {obj_type: i for i, obj_type in enumerate(object_precedence)}
    default_index = len(object_precedence)

    sorted_ops = sorted(
        operations,
        key=lambda op: _sort_key_for_action(op, precedence_index, default_index),
    )
    return _topologically_sort_registered_type_windows(sorted_ops)
