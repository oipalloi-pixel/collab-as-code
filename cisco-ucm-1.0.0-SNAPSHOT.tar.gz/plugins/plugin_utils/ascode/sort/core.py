# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""Core algorithms for dependency ordering."""

import heapq
from typing import Callable, Iterable, Literal, TypeVar

_T = TypeVar("_T")


def _items_by_unique_key(items: list[_T], key: Callable[[_T], str]) -> dict[str, _T]:
    """Build a key->item map and fail fast on duplicate keys."""
    items_by_name: dict[str, _T] = {}
    for item in items:
        item_key = key(item)
        if item_key in items_by_name:
            raise ValueError(f"Duplicate key detected in dependency sort: {item_key!r}")
        items_by_name[item_key] = item
    return items_by_name


def topological_sort(
    items: list[_T],
    key: Callable[[_T], str],
    dependencies: Callable[[_T], Iterable[str]],
    on_cycle: Literal["raise", "best_effort"] = "raise",
) -> list[_T]:
    """Sort *items* so that each item appears after all items it depends on.

    Dependencies that are not present in *items* are ignored (treated as
    already satisfied). When multiple items are equally ready, their original
    relative order is preserved (stable).

    Args:
        items: The list of items to sort.
        key: Callable that returns a unique string identifier for each item.
        dependencies: Callable that returns the identifiers of items this item
            depends on (i.e. items that must appear *before* it).
        on_cycle: What to do when a dependency cycle is detected.
            ``"raise"`` (default) raises :exc:`ValueError`.
            ``"best_effort"`` uses a greedy heuristic to pick an order and
            returns without raising.

    Returns:
        A new list ordered so that every item's in-list dependencies precede it.

    Raises:
        ValueError: If a dependency cycle is detected and *on_cycle* is ``"raise"``.
    """
    items_by_name = _items_by_unique_key(items, key)
    original_index: dict[str, int] = {key(item): i for i, item in enumerate(items)}
    index_to_name: dict[int, str] = {i: n for n, i in original_index.items()}

    # dependents[n] = names of items that depend on n (must come *after* n)
    dependents: dict[str, set[str]] = {n: set() for n in items_by_name}
    # remaining_prereqs[n] = number of in-list prerequisites n still needs before it can be emitted
    remaining_prereqs: dict[str, int] = dict.fromkeys(items_by_name, 0)

    for item in items:
        n = key(item)
        for prereq in dependencies(item):
            if prereq in items_by_name and prereq != n:
                dependents[prereq].add(n)
                remaining_prereqs[n] += 1

    # Kahn's algorithm: start from items with no prerequisites; use a min-heap keyed by
    # original index so that items with no ordering constraint stay in their original order.
    heap = [original_index[n] for n in items_by_name if remaining_prereqs[n] == 0]
    heapq.heapify(heap)

    result: list[_T] = []
    while heap:
        idx = heapq.heappop(heap)
        n = index_to_name[idx]
        result.append(items_by_name[n])
        for dependent in dependents[n]:
            remaining_prereqs[dependent] -= 1
            if remaining_prereqs[dependent] == 0:
                heapq.heappush(heap, original_index[dependent])

    if len(result) != len(items):
        cycle = [n for n, count in remaining_prereqs.items() if count > 0]
        if on_cycle == "raise":
            raise ValueError(f"Cycle detected in topological sort among: {cycle}")
        # best_effort: greedy cycle-breaking Kahn's pass on the stuck items.
        # Emit the item that is most useful to go first using this priority:
        #   1. Most within-cycle dependents (unblocks the most other stuck items).
        #   2. Fewest within-cycle prerequisites remaining (least "needy").
        #   3. Latest original position - an item defined later in the source is
        #      more likely to be a forward-reference target that should go first.
        stuck_set = set(cycle)
        within_dep_count = {n: len(dependents[n] & stuck_set) for n in cycle}
        within_prereqs = {n: remaining_prereqs[n] for n in cycle}
        remaining = sorted(cycle, key=lambda n: original_index[n])
        while remaining:
            next_n = min(
                remaining,
                key=lambda n: (-within_dep_count[n], within_prereqs[n], -original_index[n]),
            )
            result.append(items_by_name[next_n])
            remaining.remove(next_n)
            for dependent in dependents[next_n] & stuck_set:
                within_prereqs[dependent] -= 1

    return result


def find_cycles(
    items: list[_T],
    key: Callable[[_T], str],
    dependencies: Callable[[_T], Iterable[str]],
) -> set[str]:
    """Return the set of item keys that are members of at least one dependency cycle."""
    items_by_name = _items_by_unique_key(items, key)
    remaining_prereqs: dict[str, int] = dict.fromkeys(items_by_name, 0)
    dependents: dict[str, list[str]] = {n: [] for n in items_by_name}

    for item in items:
        n = key(item)
        for prereq in dependencies(item):
            if prereq in items_by_name and prereq != n:
                dependents[prereq].append(n)
                remaining_prereqs[n] += 1

    queue = [n for n in items_by_name if remaining_prereqs[n] == 0]
    while queue:
        n = queue.pop()
        for dependent in dependents[n]:
            remaining_prereqs[dependent] -= 1
            if remaining_prereqs[dependent] == 0:
                queue.append(dependent)

    return {n for n, count in remaining_prereqs.items() if count > 0}
