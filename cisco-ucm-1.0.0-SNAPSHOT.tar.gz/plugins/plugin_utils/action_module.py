# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, division, print_function

__metaclass__ = type

from ansible.errors import AnsibleActionFail
from ansible.module_utils.common.parameters import remove_values
from ansible.plugins.action import ActionBase


class ActionModule(ActionBase):
    """
    By default, Ansible modules are executed on the managed node through a shell of some
    description. This approach does not work when a module must run locally. One solution is to use
    the `delegate_to` variable, but this requires additional cognitive load for playbook developers.
    Added to which one loses access to the task variables in a module. We can use actions instead -
    the actions appear to consumers as modules, but do not have the overhead. But Actions lack basic
    parameter validation and standardized results. This base class provides that standardization.
    """

    TRANSFERS_FILES = False
    _requires_connection = False

    def initialize(self, argument_spec, tmp=None, task_vars=None):
        self.result = super(ActionModule, self).run(tmp, task_vars)
        self.check_mode = self._play_context.check_mode
        self.validation_result, self.params = self.validate_argument_spec(argument_spec)
        self.result.update(
            {
                "rc": 0,
                "invocation": {
                    "module_args": remove_values(self.params, self.validation_result._no_log_values)
                },
            }
        )

    def render_variables(self, task_vars: dict) -> dict:
        """
        Renders variables such as "{{ foo }}" to their actual value. See
        https://stackoverflow.com/a/76525002 for implementation
        """
        return {key: self._templar.template(value) for key, value in task_vars.items()}

    def _error_context(self) -> dict:
        """Return non-sensitive context fields that improve action-plugin failures."""
        context = {"action_plugin": getattr(self._task, "action", self.__class__.__name__)}
        additional = self._additional_error_context()
        if isinstance(additional, dict):
            context.update(additional)
        return {key: value for key, value in context.items() if value is not None}

    def _additional_error_context(self) -> dict:
        """Subclasses can override this to add plugin-specific failure context."""
        return {}

    def fail_json(self, msg, **kwargs):
        payload = dict(kwargs)
        payload.setdefault("error", str(msg))

        for key, value in self._error_context().items():
            payload.setdefault(key, value)

        self.result.update(**payload)
        raise AnsibleActionFail(msg, payload)

    def exit_json(self, **kwargs):
        self.result.update(**kwargs)
        return self.result
