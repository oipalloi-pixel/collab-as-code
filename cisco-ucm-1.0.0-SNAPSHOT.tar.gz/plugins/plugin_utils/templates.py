#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, annotations, division, print_function

__metaclass__ = type

try:
    from ansible_collections.cisco.ucm.plugins.plugin_utils.sdk import PATHS
    from ansible_collections.cisco.ucm.plugins.plugin_utils.sdk.template import (
        AxlTemplate,
        RisportTemplate,
    )
except ImportError:
    SDK_IS_INSTALLED = False
else:
    SDK_IS_INSTALLED = True


def axl_template(module_params: dict) -> "AxlTemplate":
    if not SDK_IS_INSTALLED:
        raise ImportError("cisco_collab_ucm_sdk is not installed.")

    return AxlTemplate(
        host=module_params.get("hostname"),
        username=module_params.get("username"),
        password=module_params.get("password"),
        verify=module_params.get("verify"),
        wsdl_path=PATHS.WSDL.AXL.for_version(module_params.get("version")),
    )


def risport_template(module_params: dict) -> "RisportTemplate":
    if not SDK_IS_INSTALLED:
        raise ImportError("cisco_collab_ucm_sdk is not installed.")

    return RisportTemplate(
        host=module_params.get("hostname"),
        username=module_params.get("username"),
        password=module_params.get("password"),
        verify=module_params.get("verify"),
    )
