# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""
WSDL wrapper module.

Provides a simplified interface for accessing WSDL documents through the Wsdl class,
which wraps Zeep's WSDL Document and provides convenient methods for iterating over
complex types and operations defined in the WSDL.
"""

from __future__ import annotations

from logging import getLogger
from pathlib import Path
from typing import Generator

from zeep import Client, Settings
from zeep.wsdl import Document
from zeep.wsdl.bindings.soap import SoapOperation
from zeep.xsd.types import ComplexType

logger = getLogger(__name__)


class Wsdl:
    """Wrapper for Zeep's WSDL Document providing convenient access to types and operations.

    This class provides a unified interface for loading and querying WSDL documents,
    supporting multiple input formats (file paths, URLs, Zeep Documents, or other Wsdl instances).
    It exposes generators for iterating over the WSDL's complex types and SOAP operations.

    Args:
        wsdl: The WSDL source (file path, URL, Document, or Wsdl instance).
        strict_ws_addressing: Whether to enable strict WS-Addressing validation.

    Example:
        >>> wsdl = Wsdl("path/to/service.wsdl")
        >>> for complex_type in wsdl.complex_types():
        ...     print(complex_type.qname.localname)
        >>> for operation in wsdl.operations():
        ...     print(operation.name)
    """

    def __init__(
        self,
        wsdl: str | Path | "Wsdl" | Document,
        strict_ws_addressing: bool = False,
    ):
        if isinstance(wsdl, Document):
            self.wsdl = wsdl

        elif isinstance(wsdl, Wsdl):
            self.wsdl = wsdl.wsdl

        elif isinstance(wsdl, (str, Path)):
            zeep_client = Client(
                wsdl=str(wsdl),
                settings=Settings(strict=strict_ws_addressing),
            )
            if not zeep_client.wsdl:
                raise RuntimeError("WSDL not initialized.")
            self.wsdl = zeep_client.wsdl

        else:
            raise RuntimeError("Unexpected parameter type for WSDL initialization.")

    def complex_types(self) -> Generator[ComplexType]:
        """
        Retrieves all XSD types from the WSDL client.

        Yields:
            ComplexType: Each ComplexType instance from the WSDL.
        """
        if not self.wsdl:
            raise RuntimeError("WSDL not initialized.")

        for xsd_type in self.wsdl.types.types:
            if isinstance(xsd_type, ComplexType):
                yield xsd_type

    def operations(self) -> Generator[SoapOperation]:
        """
        Retrieves all operations from the WSDL client.

        Yields:
            SoapOperation: Each SOAP operation from the WSDL.
        """
        if not self.wsdl:
            raise RuntimeError("WSDL not initialized.")

        for service in self.wsdl.services.values():
            for port in service.ports.values():
                for operation in port.binding._operations.values():
                    yield operation
