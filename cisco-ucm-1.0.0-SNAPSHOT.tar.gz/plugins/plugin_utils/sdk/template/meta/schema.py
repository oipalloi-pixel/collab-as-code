# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""
WSDL Schema representation module.

This module provides a structured representation of WSDL schemas, parsing Zeep's
WSDL documents into simplified dataclass structures that can be easily queried
and navigated. It extracts type definitions, operations, and their relationships
from WSDL files.

The main classes (Field, Type, Operation, Schema) provide an abstraction layer
over Zeep's complex WSDL structure, making it easier to introspect and work with
SOAP web service definitions programmatically.
"""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as datafield
from enum import Enum
from logging import getLogger
from pathlib import Path
from typing import Any, Dict, Union

from zeep.wsdl import Document
from zeep.xsd.types import ComplexType
from zeep.xsd.types.collection import UnionType
from zeep.xsd.types.simple import AnySimpleType as SimpleType

from .wsdl import Wsdl

logger = getLogger(__name__)


class NodeType(str, Enum):
    """Enumeration of XML node types in WSDL schema definitions."""

    ATTRIBUTE = "attribute"
    ELEMENT = "element"


@dataclass
class Field:
    """Represents a field (element or attribute) in a WSDL complex type.

    Attributes:
        name: The field name as it appears in the WSDL.
        node_type: Whether this is an XML attribute or element.
        type_name: The type name of this field (e.g., 'str', 'int', or a complex type name).
        optional: Whether this field is optional (min_occurs=0).
        list: Whether this field can contain multiple values (max_occurs > 1 or unbounded).
    """

    name: str
    node_type: NodeType
    type_name: str
    is_optional: bool = False
    is_list: bool = False


@dataclass
class Type:
    """Represents a WSDL complex type definition with its fields and nested types.

    A Type corresponds to a ComplexType in the WSDL schema and contains information
    about its structure including fields (elements and attributes) and any nested
    types that are defined inline within it.

    Attributes:
        name: The type name as defined in the WSDL.
        types: List of nested type definitions (for inline complex types).
        fields: List of Field objects representing the type's structure.
    """

    name: str
    types: list["Type"] = None
    fields: list[Field] = datafield(default_factory=list)

    def field(self, field_name: str) -> Field | None:
        for field in self.fields:
            if field.name == field_name:
                return field
        return None

    def nested_type(self, type_name: str) -> "Type" | None:
        if self.types is None:
            return None

        for type in self.types:
            if type.name == type_name:
                return type
        return None


@dataclass
class Operation:
    """Represents a SOAP operation (method) defined in the WSDL.

    An Operation describes a callable service method with its input and output
    message types. These correspond to SOAP operations in the WSDL binding.

    Attributes:
        input_type_name: Name of the type used for the operation's input message.
        output_type_name: Name of the type used for the operation's output message.
        name: The operation name as defined in the WSDL.
    """

    input_type_name: str
    output_type_name: str
    name: str


@dataclass
class Schema:
    """Complete schema representation of a WSDL document.

    A Schema provides a simplified, queryable representation of a WSDL's structure,
    including all type definitions and available operations. It serves as the main
    entry point for programmatically inspecting and working with WSDL schemas.

    Attributes:
        types: List of all Type definitions from the WSDL.
        operations: List of all Operation definitions from the WSDL.

    Example:
        >>> schema = Schema.from_wsdl("path/to/service.wsdl")
        >>> operation = schema.operation("GetUser")
        >>> input_type = schema.type(operation.input_type_name)
        >>> for field in input_type.fields:
        ...     print(f"{field.name}: {field.type_name}")
    """

    types: list[Type] = datafield(default_factory=list)
    operations: list[Operation] = datafield(default_factory=list)

    @classmethod
    def from_wsdl(cls, wsdl: str | Path | Wsdl | Document) -> "Schema":
        """Creates a Schema instance from a WSDL.

        Args:
            wsdl (str | Path | Wsdl | Document): The WSDL source.

        Returns:
            Schema: A Schema instance representing the WSDL.
        """
        return _SchemaBuilder(Wsdl(wsdl)).build()

    def operation(self, operation_name: str) -> Operation | None:
        """
        Finds an operation by its name.

        Args:
            operation_name (str): Name of the operation to find.

        Returns:
            Operation | None: The operation if found, otherwise None.
        """
        for operation in self.operations:
            if operation.name == operation_name:
                return operation
        return None

    def type(self, type_name: str) -> Type | None:
        """
        Finds a type by its name.
        Args:
            type_name (str): Name of the type to find.
        Returns:
            Type | None: The type if found, otherwise None.
        """
        for type in self.types:
            if type.name == type_name:
                return type
        return None


class _SchemaBuilder:
    # Basic mapping from XSD types to Python built-in types
    XSD_TO_PYTHON_TYPE_MAP = {
        "{http://www.w3.org/2001/XMLSchema}string": str,
        "{http://www.w3.org/2001/XMLSchema}int": int,
        "{http://www.w3.org/2001/XMLSchema}integer": int,
        "{http://www.w3.org/2001/XMLSchema}long": int,
        "{http://www.w3.org/2001/XMLSchema}float": float,
        "{http://www.w3.org/2001/XMLSchema}double": float,
        "{http://www.w3.org/2001/XMLSchema}boolean": bool,
        "{http://www.w3.org/2001/XMLSchema}date": "date",
        "{http://www.w3.org/2001/XMLSchema}dateTime": "datetime",
        "{http://www.w3.org/2001/XMLSchema}decimal": "Decimal",
        "{http://www.w3.org/2001/XMLSchema}anyType": Any,
        "{http://www.w3.org/2001/XMLSchema}base64Binary": bytes,
        "{http://www.w3.org/2001/XMLSchema}positiveInteger": int,
        "{http://www.w3.org/2001/XMLSchema}nonNegativeInteger": int,
        "{http://www.w3.org/2001/XMLSchema}unsignedLong": int,
    }

    def __init__(self, wsdl: Wsdl):
        """
        Initializes the Builder with a WSDL object.
        This will be used to generate Pydantic-XML models from the WSDL.
        """
        self.wsdl = wsdl
        self.model_dict: Dict[str, Type] = {}
        self.operations_dict: Dict[str, Operation] = {}

    def _python_type(self, xsd_type: Any) -> Any:
        """
        Maps an XSD type object from Zeep to a Python type.
        Handles basic types and complex types (using forward references).
        """
        if isinstance(xsd_type, UnionType):
            types = {self._python_type(t) for t in xsd_type.item_types}
            if len(types) == 1:
                return next(iter(types))

            return Union[types]  # noqa: UP007

        if hasattr(xsd_type, "qname") and str(xsd_type.qname) in self.XSD_TO_PYTHON_TYPE_MAP:
            return self.XSD_TO_PYTHON_TYPE_MAP[str(xsd_type.qname)]

        # If it's a SimpleType, try to map its base type
        if isinstance(xsd_type, SimpleType):
            if hasattr(xsd_type, "enumeration"):
                logger.debug(f"Enumeration type '{xsd_type.qname}' found; treating as string.")
                return str

            if str in xsd_type.accepted_types:
                logger.debug(f"SimpleType '{xsd_type.qname}' is a string type. Using 'str'.")
                return str

            if xsd_type.base and str(xsd_type.base.qname) in self.XSD_TO_PYTHON_TYPE_MAP:
                return self.XSD_TO_PYTHON_TYPE_MAP[str(xsd_type.base.qname)]

        # If it's a ComplexType, resolve it as a model class
        if isinstance(xsd_type, ComplexType):
            if xsd_type.is_global:
                type_name = xsd_type.qname.localname
                if type_name not in self.model_dict:
                    raise ValueError(
                        f"ComplexType '{type_name}' is not defined in the model. "
                        "Ensure that the WSDL is correctly parsed and the type exists."
                    )
                return self.model_dict[type_name]

            if (
                hasattr(xsd_type, "_extension_types")
                and xsd_type._extension_types
                and len(xsd_type._extension_types) > 1
            ):
                # Handle extension types by returning the first one
                extension_type = xsd_type._extension_types[0]._xsd_type
                if extension_type.name in self.model_dict:
                    return self.model_dict[extension_type.name]

            return Any

        logger.debug(f"Could not map XSD type '{xsd_type}'. Using 'Any'.")
        return Any

    def _type_string(self, xsd_type: Any) -> str:
        type = self._python_type(xsd_type)
        if type is None:
            raise ValueError(
                f"Could not determine Python type for XSD type '{xsd_type}'. "
                "Ensure that the WSDL is correctly parsed and the type exists."
            )

        elif isinstance(type, Type):
            return type.name

        return type.__name__

    def _stubs(self) -> None:
        for xsd_type in self.wsdl.complex_types():
            class_name = xsd_type.qname.localname
            self.model_dict[class_name] = Type(name=class_name)

    def _class(self, ct: ComplexType, is_nested: bool = False) -> Type:
        """
        Maps a Zeep ComplexType to a model class. This includes attributes and elements, and
        handles nested complex types.
        """
        class_name = ct.qname.localname
        class_ = self.model_dict[class_name] if not is_nested else Type(name=class_name)

        # Map attributes
        for _, node in ct.attributes:
            class_.fields.append(
                Field(
                    name=node.qname.localname,
                    node_type=NodeType.ATTRIBUTE,
                    type_name=self._type_string(node.type),
                    is_optional=not (hasattr(node, "required") and node.required),
                )
            )

        # Map elements
        for _, node in ct.elements:
            if isinstance(node.type, ComplexType) and not node.type.is_global:
                # Non-global complex types need to be dynamically built recursively
                nested_type = self._class(node.type, is_nested=True)
                if class_.types is None:
                    class_.types = []
                class_.types.append(nested_type)
                python_type = nested_type.name

            else:
                python_type = self._type_string(node.type)

            if hasattr(node, "qname") and node.qname is not None:
                class_.fields.append(
                    Field(
                        name=node.qname.localname,
                        node_type=NodeType.ELEMENT,
                        type_name=python_type,
                        is_optional=hasattr(node, "min_occurs") and node.min_occurs == 0,
                        is_list=hasattr(node, "max_occurs")
                        and (
                            node.max_occurs == "unbounded"
                            or (isinstance(node.max_occurs, int) and node.max_occurs > 1)
                        ),
                    )
                )

            else:
                logger.debug(f"Element '{node}' has no QName. Skipping.")

        return class_

    def _classes(self) -> None:
        for xsd_type in self.wsdl.complex_types():
            logger.debug(f"Processing XSD type: {xsd_type.qname.localname}")
            self._class(xsd_type)

    def _operations(self) -> None:
        operations = {}
        for operation in self.wsdl.operations():
            name = operation.name

            operations[name] = Operation(
                input_type_name=self._type_string(operation.input.body.type),
                output_type_name=self._type_string(operation.output.body.type),
                name=name,
            )

        self.operations_dict = operations

    def build(self) -> Schema:
        """
        Builds the models from the WSDL. This will create a dictionary of model classes keyed by
        their names.
        """
        self._stubs()
        self._classes()
        self._operations()

        return Schema(
            types=list(self.model_dict.values()),
            operations=list(self.operations_dict.values()),
        )
