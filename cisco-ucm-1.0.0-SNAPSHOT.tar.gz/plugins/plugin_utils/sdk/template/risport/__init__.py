# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from logging import getLogger
from typing import Any, Callable, Dict, Final, List

from zeep.proxy import ServiceProxy

from ... import PATHS
from ..zeep import ZeepTemplate
from ..zeep import service as zeep_service

logger = getLogger(__name__)

# Device status reason codes mapping
STATUS_REASONS: Final[Dict[str, str]] = {
    "0": "Normal",
    "1": "Unknown",
    "2": "NoEntryInDatabase",
    "3": "DatabaseConfigurationError",
    "4": "DeviceNameUnresolved",
    "5": "MaxDeviceRegExceeded",
    "6": "ConnectivityError",
    "7": "InitializationError",
    "8": "DeviceInitiatedReset",
    "9": "CallManagerReset",
    "10": "DeviceUnregistered",
    "11": "SIP MalformedRegisterMsgOrInvalidCertName",
    "12": "SCCPDeviceThrottling",
    "13": "KeepAliveTimeout",
    "14": "SIP ConfigurationMismatch",
    "15": "CallManagerRestart",
    "16": "DuplicateRegistration",
    "17": "CallManagerApplyConfig",
    "18": "DeviceNoResponse",
    "19": "EMLoginLogout",
    "20": "EMCCLoginLogout",
    "21": "EnergywisePowerSavePlus",
    "22": "CallManagerForcedRestart",
    "23": "SourceIPAddrChanged",
    "24": "SourcePortChanged",
    "25": "RegistrationSequenceError",
    "26": "InvalidCapabilities",
    "27": "CapabilityResponseTimeout",
    "28": "FallbackInitiated-securityMismatch",
    "29": "DeviceSwitch-AutoRegDbError",
    "30": "DeviceWipe",
    "31": "DeviceForcedReset",
    "32": "DeviceTypeMismatch",
    "33": "LowBattery",
    "34": "ManualPowerOff",
    "35": "AuthorizationError",
    "36": "SIPOauthChallenges",
}

# Default values for RisPort operations
DEFAULT_MAX_DEVICES = 1000
DEFAULT_MODEL_ALL = 255  # Model 255 means "all models"
DEFAULT_RISPORT_PORT = 8443
DEFAULT_RISPORT_PATH = "/realtimeservice2/services/RISService70"
RISPORT_BINDING_NAMESPACE = "{http://schemas.cisco.com/ast/soap}RisBinding"


def get_status_reason_description(status_code: str | int) -> str:
    """
    Get the human-readable description for a status reason code.

    Args:
        status_code (str | int): The numeric status code.

    Returns:
        str: The description of the status code, or "Unknown" if not found.

    Example:
        >>> RisportTemplate.get_status_reason_description("0")
        "Normal"
        >>> RisportTemplate.get_status_reason_description("999")
        "Unknown"
    """
    return STATUS_REASONS.get(str(status_code), "Unknown")


class RisportTemplate(ZeepTemplate):
    """
    A template class for Cisco Unified Communications Manager (CUCM) RisPort operations.

    RisPort (Real-time Information Service Port) provides real-time device registration
    status and statistics from CUCM. This class extends ZeepTemplate to provide
    risport-specific functionality for querying device information.

    Example:
        >>> risport = RisportTemplate(
        ...     host="cucm.example.com",
        ...     username="admin",
        ...     password="password"
        ... )
        >>> devices = risport.select_cm_device("SEP001122334455")
    """

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        verify: bool = True,
        response_mapper: Callable[[Dict[str, Any]], Dict[str, Any]] = lambda data: data,
    ) -> None:
        """
        Initialize the RisportTemplate with connection parameters.

        Args:
            host (str): The hostname or IP address of the CUCM server.
            username (str): Username for authentication.
            password (str): Password for authentication.
            response_mapper (Callable[[Dict[str, Any]], Dict[str, Any]]): A function
                to transform the response data.
        """
        service: ServiceProxy = zeep_service(
            wsdl_path=str(PATHS.WSDL.RISPORT),
            username=username,
            password=password,
            verify=verify,
            binding_name=RISPORT_BINDING_NAMESPACE,
            address=f"https://{host}:{DEFAULT_RISPORT_PORT}{DEFAULT_RISPORT_PATH}",
        )

        super().__init__(service=service, response_mapper=response_mapper)

    def select_cm_device(
        self,
        select_items: str,
        state_info: str = "",
        max_returned_devices: int = DEFAULT_MAX_DEVICES,
        device_class: str = "phone",
        model: int = DEFAULT_MODEL_ALL,
        status: str = "Any",
        select_by: str = "Name",
        protocol: str = "Any",
        download_status: str = "Any",
    ) -> List[Dict[str, Any]]:
        """
        Returns a list of devices based on the provided selection criteria. The response is parsed
        into a list of dictionaries which relate to the CmNode.

        The response dictionary structure is as follows:
        >>> [
            {
                "ReturnCode": "0",
                "Name": "NodeName",
                "NoChange": False,
                "CmDevices": {
                    "item": [
                        {
                            "Name": "DeviceName",
                            "DirNumber": "DirectoryNumber",
                            "DeviceClass": "DeviceClass",
                            "Model": 123,
                            "Product": 456,
                            "BoxProduct": 789,
                            "Httpd": {"Enabled": True, "Port": 8080},
                            "RegistrationAttempts": 3,
                            "IsCtiControllable": True,
                            "LoginUserId": "user123",
                            "Status": "Registered",
                            "StatusReason": 0,
                            "PerfMonObject": 1,
                            "DChannel": 2,
                            "Description": "Device Description",
                            "H323Trunk": {
                                "ConfigName": "TrunkConfig",
                                "TechPrefix": "1234",
                                "Zone": "Zone1",
                                "RemoteCmServer1": "remote1.example.com",
                                "RemoteCmServer2": "remote2.example.com",
                                "RemoteCmServer3": "remote3.example.com",
                                "AltGkList": "GK1,GK2",
                                "ActiveGk": "ActiveGK",
                                "CallSignalAddr": "SignalAddr",
                                "RasAddr": "RasAddr"
                            }
                            "TimeStamp": 1622547800,
                            "Protocol": "SIP",
                            "NumOfLines": 2,
                            "LinesStatus": {"item": [
                                "DirectoryNumber": "1234",
                                "Status": "Registered"
                            ]},
                            "ActiveLoadID": "load123",
                            "InactiveLoadID": "",
                            "DownloadStatus": {"StatusCode": 0, "Message": ""},
                            "DownloadFailureReason": "",
                            "DownloadServer": "",
                            "IPAddress": {
                                "item": [
                                    {
                                        "IP": "192.168.0.123",
                                        "IPAddrType": "ipv4",
                                        "Attribute": "Unknown"
                                    }
                                ]
                            }
                        }
                    ]
                }
            }
        ]

        This is based on the WSDL definition:

        >>> <complexType name="CmNode">
          <sequence>
            <element name="ReturnCode" nillable="true" type="tns:RisReturnCode"/>
            <element name="Name" nillable="true" type="xsd:string"/>
            <element name="NoChange" type="xsd:boolean"/>
            <element name="CmDevices" nillable="true">
              <xsd:complexType>
                <xsd:sequence minOccurs="0">
                  <element maxOccurs="unbounded" minOccurs="0" name="item">
                    <complexType name="CmDevice">
                      <sequence>
                        <element name="Name" nillable="true" type="xsd:string"/>
                        <element name="DirNumber" nillable="true" type="xsd:string"/>
                        <element name="DeviceClass" nillable="true" type="tns:DeviceClass"/>
                        <element name="Model" nillable="true" type="xsd:unsignedInt"/>
                        <element name="Product" nillable="true" type="xsd:unsignedInt"/>
                        <element name="BoxProduct" nillable="true" type="xsd:unsignedInt"/>
                        <element name="Httpd" nillable="true" type="tns:CmDevHttpd"/>
                        <element name="RegistrationAttempts" nillable="true" type="xsd:unsignedInt"/>
                        <element name="IsCtiControllable" type="xsd:boolean"/>
                        <element name="LoginUserId" nillable="true" type="xsd:string"/>
                        <element name="Status" nillable="true" type="tns:CmDevRegStat"/>
                        <element name="StatusReason" nillable="true" type="xsd:unsignedInt"/>
                        <element name="PerfMonObject" nillable="true" type="xsd:unsignedInt"/>
                        <element name="DChannel" nillable="true" type="xsd:unsignedInt"/>
                        <element name="Description" nillable="true" type="xsd:string"/>
                        <element name="H323Trunk" nillable="true">
                          <complexType>
                            <sequence>
                              <element name="ConfigName" nillable="true" type="xsd:string"/>
                              <element name="TechPrefix" nillable="true" type="xsd:string"/>
                              <element name="Zone" nillable="true" type="xsd:string"/>
                              <element name="RemoteCmServer1" nillable="true" type="xsd:string"/>
                              <element name="RemoteCmServer2" nillable="true" type="xsd:string"/>
                              <element name="RemoteCmServer3" nillable="true" type="xsd:string"/>
                              <element name="AltGkList" nillable="true" type="xsd:string"/>
                              <element name="ActiveGk" nillable="true" type="xsd:string"/>
                              <element name="CallSignalAddr" nillable="true" type="xsd:string"/>
                              <element name="RasAddr" nillable="true" type="xsd:string"/>
                            </sequence>
                          </complexType>
                        </element>
                        <element name="TimeStamp" nillable="true" type="xsd:unsignedInt"/>
                        <element name="Protocol" nillable="true" type="tns:ProtocolType"/>
                        <element name="NumOfLines" nillable="true" type="xsd:unsignedInt"/>
                        <element name="LinesStatus" nillable="true">
                          <complexType>
                            <sequence>
                              <element maxOccurs="unbounded" minOccurs="0" name="item">
                                <complexType>
                                  <sequence>
                                    <element name="DirectoryNumber" nillable="true" type="xsd:string"/>
                                    <element name="Status" nillable="true" type="tns:CmSingleLineStatus"/>
                                  </sequence>
                                </complexType>
                              </element>
                            </sequence>
                          </complexType>
                        </element>
                        <element name="ActiveLoadID" nillable="true" type="xsd:string"/>
                        <element name="InactiveLoadID" nillable="true" type="xsd:string"/>
                        <element name="DownloadStatus" nillable="true" type="tns:DeviceDownloadStatus"/>
                        <element name="DownloadFailureReason" nillable="true" type="xsd:string"/>
                        <element name="DownloadServer" nillable="true" type="xsd:string"/>
                        <element name="IPAddress">
                          <complexType>
                            <sequence>
                              <element maxOccurs="unbounded" minOccurs="0" name="item">
                                <complexType>
                                  <sequence>
                                    <element name="IP" type="xsd:string"/>
                                    <element name="IPAddrType" type="tns:IPAddrType"/>
                                    <element name="Attribute" nillable="true" type="tns:AttributeType"/>
                                  </sequence>
                                </complexType>
                              </element>
                            </sequence>
                          </complexType>
                        </element>
                      </sequence>
                    </complexType>
                  </element>
                </xsd:sequence>
              </xsd:complexType>
            </element>
          </sequence>
        </complexType>


        Args:
            select_items (str): Device name pattern or specific device name to search for.
            state_info (str, optional): State information for incremental updates. Defaults to "".
            max_returned_devices (int, optional): Maximum number of devices to return.
                Defaults to DEFAULT_MAX_DEVICES (1000).
            device_class (str, optional): Type of device ("phone", "gateway", etc.). Defaults to "phone".
            model (int, optional): Device model filter. Defaults to DEFAULT_MODEL_ALL (255 = all models).
            status (str, optional): Registration status filter ("Any", "Registered", etc.). Defaults to "Any".
            select_by (str, optional): Search criteria ("Name", "IPAddress", etc.). Defaults to "Name".
            protocol (str, optional): Protocol filter ("Any", "SIP", "SCCP"). Defaults to "Any".
            download_status (str, optional): Download status filter. Defaults to "Any".

        Returns:
            List[Dict[str, Any]]: List of device information dictionaries from each CM node.
            Each dictionary contains device details including name, status, IP addresses, etc.

        Example:
            >>> devices = risport.select_cm_device("SEP001122334455")
            >>> for node in devices:
            ...     for device in node.get("CmDevices", {}).get("item", []):
            ...         print(f"Device: {device['Name']}, Status: {device['Status']}")

        Note:
            Use get_status_reason_description() to convert numeric StatusReason codes to readable text.
        """  # noqa: E501

        result = self.selectCmDevice(
            StateInfo=state_info,
            CmSelectionCriteria={
                "MaxReturnedDevices": max_returned_devices,
                "DeviceClass": device_class,
                "Model": model,
                "Status": status,
                "SelectBy": select_by,
                "SelectItems": [{"item": {"Item": select_items}}],
                "Protocol": protocol,
                "DownloadStatus": download_status,
            },
        )

        return result["SelectCmDeviceResult"]["CmNodes"]["item"]
