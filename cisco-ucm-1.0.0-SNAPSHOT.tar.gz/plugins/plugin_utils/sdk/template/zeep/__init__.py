# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from logging import getLogger
from typing import Any, Callable, Dict, List

from lxml import etree
from requests import Response, Session
from requests.auth import HTTPBasicAuth
from zeep import Client, Settings
from zeep.helpers import serialize_object
from zeep.proxy import ServiceProxy
from zeep.transports import Transport
from zeep.xsd.valueobjects import CompoundValue, _unpickle_compound_value

logger = getLogger(__name__)


# Default timeout
DEFAULT_TIMEOUT_SECONDS = 10


def _session(
    username: str | None = None,
    password: str | None = None,
    verify: bool = False,
) -> Session:
    session = Session()
    session.verify = verify
    if username and password:
        session.auth = HTTPBasicAuth(username, password)
    return session


def _transport(
    username: str | None = None,
    password: str | None = None,
    verify: bool = False,
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
) -> Transport:
    return Transport(
        session=_session(username=username, password=password, verify=verify),
        timeout=timeout_seconds,
    )


def client(
    wsdl_path: str,
    username: str | None = None,
    password: str | None = None,
    verify: bool = False,
    strict_ws_addressing: bool = False,
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
) -> Client:
    settings = Settings(strict=strict_ws_addressing)
    return Client(
        wsdl=wsdl_path,
        settings=settings,
        transport=_transport(
            username=username, password=password, verify=verify, timeout_seconds=timeout_seconds
        ),
    )


def service(
    wsdl_path: str,
    username: str,
    password: str,
    verify: bool,
    strict_ws_addressing: bool = False,
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
    binding_name: str | None = None,
    address: str | None = None,
) -> ServiceProxy:
    if binding_name and address:
        return client(
            wsdl_path=wsdl_path,
            username=username,
            password=password,
            verify=verify,
            strict_ws_addressing=strict_ws_addressing,
            timeout_seconds=timeout_seconds,
        ).create_service(binding_name, address)

    raise ValueError(
        "Both 'binding_name' and 'address' must be provided to create a service proxy. "
        f"Got binding_name={binding_name!r}, address={address!r}"
    )


def elements_as_dict(elements: List[etree.ElementBase]) -> Dict[str, str]:
    """
    Convert a list of XML elements to a dictionary representation.

    Args:
        elements (List[etree.ElementBase]): The list of XML elements to convert.

    Returns:
        Dict[str, str]: A dictionary representation of the XML elements.
    """
    result = {element.tag: element.text for element in elements}
    logger.debug(f"elements_as_dict({elements}) -> {result}")
    return result


def merge_raw_elements(obj: Any) -> Any:
    """
    Recursively process Zeep objects to extract and merge _raw_elements into CompoundValue objects.

    This handles cases where Zeep is unable to match SOAP response elements to the WSDL
    and leaves them as raw XML elements in the _raw_elements attribute.

    Creates a new copy of the data structure, leaving the original untouched.

    Args:
        obj: The Zeep object to process (CompoundValue, list, or other).

    Returns:
        A new object with raw elements merged in. Returns the original object
        if it's not a CompoundValue or list.
    """
    if isinstance(obj, list):
        return [merge_raw_elements(item) for item in obj]

    if isinstance(obj, CompoundValue):
        # Create a new dictionary with recursively preprocessed values, excluding _raw_elements
        new_values = {}
        for key, value in obj.__values__.items():
            if key != "_raw_elements":
                new_values[key] = merge_raw_elements(value)

        # Check for _raw_elements as a real attribute (not in __values__)
        raw_elements = (
            getattr(obj, "_raw_elements", None)
            if "_raw_elements" not in obj.__values__
            else obj.__values__.get("_raw_elements")
        )

        # Extract and merge _raw_elements if present
        if raw_elements:
            elements_dict = elements_as_dict(raw_elements)
            new_values.update(elements_dict)

        # Create a new CompoundValue with the merged values (no _raw_elements)
        return _unpickle_compound_value(obj.__class__.__name__, new_values)

    return obj


class ZeepTemplate:
    """
    Base template class for SOAP web service operations using Zeep.

    This class provides a common interface for interacting with SOAP services,
    with automatic response transformation and casing mode support.

    Args:
        service: The Zeep ServiceProxy instance.
        response_mapper: A callable to transform the response data.
    """

    def __init__(
        self,
        service: ServiceProxy,
        response_mapper: Callable[[Dict[str, Any]], Dict[str, Any]] = lambda data: data,
    ) -> None:
        """
        Initialize the template with service configuration.

        Args:
            service: The Zeep ServiceProxy instance for SOAP operations.
            response_mapper: A callable to transform the response data.
        """
        self._service = service
        self.response_mapper = response_mapper

    def _call_zeep(self, operation_name: str, **kwargs) -> Any:
        """
        Execute a SOAP operation on the service.

        Args:
            operation_name: Name of the operation to call.
            **kwargs: Arguments to pass to the operation.

        Returns:
            The raw response from the SOAP service.

        Raises:
            ValueError: If the operation doesn't exist on the service.
        """
        operation = self.operation(operation_name)
        if not operation:
            raise ValueError(f"Operation '{operation_name}' is not defined in the service.")

        logger.debug(f"{type(self).__name__}._call_zeep({operation_name}, {kwargs})")
        return operation(**kwargs)

    def call(self, operation_name: str, **kwargs) -> Dict[str, Any]:
        """
        Call a SOAP operation and return the response as a dictionary.

        Args:
            operation_name: Name of the operation to call.
            **kwargs: Arguments to pass to the operation.

        Returns:
            The response converted to a dictionary.
        """
        response = self._call_zeep(operation_name, **kwargs)
        if response is None:
            logger.debug(f"{type(self).__name__}.call({operation_name}) response: None")
            return {}

        data = merge_raw_elements(response)
        data = serialize_object(data)
        logger.debug(f"{type(self).__name__}.call({operation_name})/serialize_object(...): {data}")
        return self.response_mapper(data)

    @property
    def client(self) -> Client:
        """
        Returns the underlying Zeep Client instance.

        Returns:
            The Zeep Client instance.
        """
        return self._service._client

    def __getattr__(self, operation: str) -> Callable[..., Dict[str, Any]]:
        """
        Allow access to service operations as attributes.

        This enables calling service operations directly on the template instance:
        template.someOperation(arg1="value") instead of
        template._as_dict("someOperation", arg1="value")

        Args:
            operation: Name of the operation to access.

        Returns:
            A callable that will execute the operation and return a dictionary.
        """

        def call_proxy(*args, **kwargs) -> Dict[str, Any]:
            return self.call(operation, *args, **kwargs)

        return call_proxy

    def has_operation(self, operation_name: str) -> bool:
        """
        Returns whether or not the given operation_name is supported by this WSDL

        Args:
            operation_name (str): The name of the operation to check.

        Returns:
            bool
        """
        return self.operation(operation_name) is not None

    def operation(self, operation_name: str) -> Callable:
        return getattr(self._service, operation_name, None)

    def post_xml(self, xml_envelope: str | bytes, headers: Dict[str, str] | None) -> Response:
        """
        Call a SOAP operation with a raw XML envelope and return the raw response.

        Args:
            xml_envelope: The raw XML envelope to send.
            headers: Optional HTTP headers to include in the request. This will typically include
                     the SOAPAction header.
        Returns:
            The raw Zeep response from the SOAP service.
        """
        address = self._service._binding_options.get("address")
        transport: Transport = self.client.transport
        return transport.post(
            address=address,
            message=xml_envelope,
            headers=headers,
        )
