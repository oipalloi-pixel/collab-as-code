# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""
AXL-specific schema helper functions.

Provides utility functions for working with Cisco AXL WSDL schemas, including
automatic generation of searchCriteria and returnedTags parameters for list
operations. These helpers introspect the schema structure to construct appropriate
request parameters for AXL operations.
"""

from logging import getLogger
from typing import Any, Dict

from ..meta.schema import Schema

logger = getLogger(__name__)


def to_returned_tags(*tags: str) -> Dict[str, Any]:
    """Constructs a returnedTags dictionary from the provided tag names.

    Args:
        *tags (str): Tag names to include in returnedTags.
    Returns:
        Dict[str, Any]: Arguments dictionary with returned tags set.
    """
    return {
        "returnedTags": dict.fromkeys(tags, ""),
    }


def search_criteria(schema: Schema, operation_name: str) -> Dict[str, Any]:
    """Finds the search criteria for a list operation, selects its first
    field and sets it to '%' in order to match all records.

    Args:
        operation_name (str): Name of the AXL operation to call.

    Returns:
        Dict[str, Any]: Arguments dictionary with search criteria set to match all records.
    """
    operation = schema.operation(operation_name)
    if not operation:
        logger.debug(f"Operation '{operation_name}' not found in schema")
        return {}

    input_type = schema.type(operation.input_type_name)
    if not input_type:
        logger.debug(
            f"Input type '{operation.input_type_name}' not found for operation '{operation_name}'"
        )
        return {}

    search_criteria_type = input_type.nested_type("searchCriteria")
    if not search_criteria_type:
        logger.debug(f"No searchCriteria type found for operation '{operation_name}'")
        return {}

    if not search_criteria_type.fields:
        logger.warning(f"searchCriteria type has no fields for operation '{operation_name}'")
        return {}

    return {"searchCriteria": {search_criteria_type.fields[0].name: "%"}}


def all_returned_tags(schema: Schema, operation_name: str) -> Dict[str, Any]:
    """Finds the returned tags for a list operation and constructs a dictionary
    with all fields set to empty strings.

    Args:
        operation_name (str): Name of the AXL operation to call.
    Returns:
        Dict[str, Any]: Arguments dictionary with returned tags set.
    """
    operation = schema.operation(operation_name)
    if not operation:
        logger.debug(f"Operation '{operation_name}' not found in schema")
        return {}

    output_type = schema.type(operation.output_type_name)
    if not output_type:
        logger.debug(
            f"Output type '{operation.output_type_name}' not found for operation '{operation_name}'"
        )
        return {}

    return_type = output_type.nested_type("return")
    if not return_type:
        logger.debug(f"No return type found for operation '{operation_name}'")
        return {}

    if not return_type.fields:
        logger.warning(f"Return type has no fields for operation '{operation_name}'")
        return {}

    type_name = return_type.fields[0].type_name
    actual_type = schema.type(type_name)
    if not actual_type:
        logger.warning(f"Actual type '{type_name}' not found for operation '{operation_name}'")
        return {}

    tags = (field.name for field in actual_type.fields)
    return to_returned_tags(*tags)
