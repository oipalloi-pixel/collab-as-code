# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""
AXL API representation module.

This module provides a structured representation of Cisco AXL API operations,
parsing WSDL documents into an object-oriented API model. It organizes SOAP
operations by object type and CRUD verb, making it easier to discover and work
with AXL operations programmatically.

The main classes (Verb, Method, ObjectApi, AxlApi) provide an abstraction layer
for AXL operations, grouping them by the objects they operate on (e.g., Phone,
User, Line) and the action they perform (list, get, add, update, remove).
"""

from __future__ import annotations

from dataclasses import InitVar, dataclass
from pathlib import Path
from typing import Dict, Tuple

from zeep.wsdl import Document

from ..meta.schema import Schema, Type
from ..meta.wsdl import Wsdl


class Verb(str):
    """CRUD operation verbs used in AXL API operations.

    This class defines the standard set of operations available in the AXL API:
    - LIST: Query multiple records
    - GET: Retrieve a single record
    - ADD: Create a new record
    - UPDATE: Modify an existing record
    - REMOVE: Delete a record

    The class also provides mapping from alternative naming conventions (CRUD, HTTP verbs)
    to the standard AXL verbs.
    """

    LIST = "list"
    GET = "get"
    ADD = "add"
    UPDATE = "update"
    REMOVE = "remove"

    STANDARD = [LIST, GET, ADD, UPDATE, REMOVE]

    @classmethod
    def from_value(cls, value: str | "Verb") -> "Verb":
        """Convert a string value to a Verb, supporting multiple naming conventions.

        Accepts standard AXL verbs (list, get, add, update, remove),
        CRUD terms (create→add, read→get, delete→remove),
        and HTTP methods (post→add, put→update, delete→remove).

        Args:
            value: The verb string or Verb instance to convert.

        Returns:
            The corresponding Verb instance.

        Example:
            >>> Verb.from_value("create")
            'add'
            >>> Verb.from_value("delete")
            'remove'
            >>> Verb.from_value("post")
            'add'
        """
        if isinstance(value, Verb):
            return value

        if value.lower() in cls.STANDARD:
            return cls(value.lower())

        crud_map = {
            "create": cls.ADD,
            "read": cls.GET,
            "update": cls.UPDATE,
            "delete": cls.REMOVE,
        }
        if value.lower() in crud_map:
            return crud_map[value.lower()]

        http_map = {
            "get": cls.GET,
            "post": cls.ADD,
            "put": cls.UPDATE,
            "delete": cls.REMOVE,
        }
        if value.lower() in http_map:
            return http_map[value.lower()]

        return cls(value)


@dataclass
class Method:
    """Represents a single AXL API method/operation.

    Attributes:
        verb: The CRUD verb for this operation (list, get, add, update, remove).
        operation: The SOAP operation name (e.g., 'addPhone', 'getUser').
        payload_type: The Type definition for the input/request message.
        return_type: The Type definition for the output/response message.
    """

    verb: str
    operation: str
    payload_type: Type
    return_type: Type


@dataclass
class ObjectApi:
    """Represents all API methods available for a specific AXL object.

    An ObjectApi groups all CRUD operations for a single object type
    (e.g., Phone, User, Line) in the AXL API.

    Attributes:
        name: The object name (e.g., 'Phone', 'User', 'Line').
        methods: List of all available Method operations for this object.

    Example:
        >>> phone_api = axl_api.object('Phone')
        >>> add_method = phone_api.method('add')
        >>> print(add_method.operation)  # 'addPhone'
    """

    name: str
    methods: list[Method]

    def method(self, verb: str) -> Method | None:
        """Find a method by its verb.

        Args:
            verb: The verb to search for (supports standard verbs, CRUD terms, HTTP methods).

        Returns:
            The Method if found, otherwise None.
        """
        for method in self.methods:
            if method.verb == Verb.from_value(verb):
                return method
        return None


@dataclass
class AxlApi:
    """Complete API representation of an AXL WSDL document.

    Provides a structured, queryable representation of all objects, operations,
    and types defined in an AXL WSDL. Operations are organized by the object
    they operate on, making API discovery and usage more intuitive.

    Attributes:
        objects: List of all ObjectApi definitions (grouped operations).
        types: List of all Type definitions from the WSDL schema.

    Example:
        >>> api = AxlApi.from_wsdl("path/to/axl.wsdl")
        >>> phone_api = api.object("Phone")
        >>> add_phone = phone_api.method("add")
        >>> print(add_phone.operation)  # 'addPhone'
        >>> print([field.name for field in add_phone.payload_type.fields])
    """

    objects: list[ObjectApi]
    types: list[Type]

    # Lazily loaded and not serialized
    _object_map: InitVar[Dict[str, ObjectApi] | None] = None
    _type_map: InitVar[Dict[str, Type] | None] = None

    @classmethod
    def from_wsdl(cls, wsdl: str | Path | Wsdl | Document) -> "AxlApi":
        """Create an AxlApi instance from a WSDL document.

        Args:
            wsdl: The WSDL source (file path, URL, Wsdl instance, or Document).

        Returns:
            An AxlApi instance representing the WSDL.
        """
        return _AxlApiBuilder(Wsdl(wsdl)).build()

    @property
    def object_map(self) -> Dict[str, ObjectApi]:
        """Lazily-loaded dictionary mapping object names to ObjectApi instances."""
        if self._object_map is None:
            self._object_map = {obj.name: obj for obj in self.objects}
        return self._object_map

    @property
    def type_map(self) -> Dict[str, Type]:
        """Lazily-loaded dictionary mapping type names to Type instances."""
        if self._type_map is None:
            self._type_map = {cls.name: cls for cls in self.types}
        return self._type_map

    def object_names(self) -> list[str]:
        """Get a list of all available object names in the API.

        Returns:
            List of object names (e.g., ['Phone', 'User', 'Line', ...]).
        """
        return list(self.object_map.keys())

    def object(self, object_name: str) -> ObjectApi | None:
        """Find an ObjectApi by name.

        Args:
            object_name: The name of the object to find (e.g., 'Phone', 'User').

        Returns:
            The ObjectApi if found, otherwise None.
        """
        return self.object_map.get(object_name)

    def type(self, type_name: str) -> Type | None:
        """Find a Type by name.

        Args:
            type_name: The name of the type to find.

        Returns:
            The Type if found, otherwise None.
        """
        return self.type_map.get(type_name)


class _AxlApiBuilder:
    """Internal builder class for constructing AxlApi instances from WSDL documents.

    This class handles the parsing logic to extract operations from the WSDL,
    group them by object type, and organize them by verb.
    """

    def __init__(self, wsdl: Wsdl):
        self.wsdl = wsdl

    @staticmethod
    def _get_object_and_verb(operation_name: str) -> Tuple[str, str]:
        """Translates an operation name into its corresponding object name and verb. e.g.
        `addPhone` -> (`"Phone"`, `"add"`)

        Args:
            operation_name (str): The name of the operation.

        Returns:
            Tuple[str, str]: A tuple containing the object name and verb.
        """
        for verb in Verb.STANDARD:
            if operation_name.startswith(verb):
                return operation_name[len(verb) :], verb

        # This is a special case for all leftover operations that do not
        # follow the {verb}{Object} naming convention such as `doAuthenticateUser`
        return "Actions", operation_name

    def build(self) -> AxlApi:
        """Build the AxlApi from the WSDL.

        Parses the WSDL schema, extracts all operations, groups them by object,
        and constructs the complete AxlApi structure.

        Returns:
            The constructed AxlApi instance.
        """
        schema: Schema = Schema.from_wsdl(wsdl=self.wsdl)
        type_map: Dict[str, Type] = {cls.name: cls for cls in schema.types}
        object_apis: Dict[str, ObjectApi] = {}

        for operation in schema.operations:
            object_name, verb = self._get_object_and_verb(operation.name)

            if object_name not in object_apis:
                object_apis[object_name] = ObjectApi(name=object_name, methods=[])

            object_apis[object_name].methods.append(
                Method(
                    verb=verb,
                    operation=operation.name,
                    payload_type=type_map.get(operation.input_type_name),
                    return_type=type_map.get(operation.output_type_name),
                )
            )

            object_apis[object_name].methods.sort(key=lambda x: x.verb)

        axl_api: AxlApi = AxlApi(
            objects=list(object_apis.values()),
            types=list(type_map.values()),
        )

        return axl_api
