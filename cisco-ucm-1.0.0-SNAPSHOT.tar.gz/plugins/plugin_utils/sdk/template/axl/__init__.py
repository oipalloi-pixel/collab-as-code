# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from logging import getLogger
from pathlib import Path
from re import sub as re_sub
from typing import Any, Callable, Dict, Generator, List

from lxml import etree
from zeep.exceptions import Fault
from zeep.proxy import ServiceProxy

from ... import PATHS
from ..meta.schema import Schema
from ..zeep import ZeepTemplate, elements_as_dict
from ..zeep import service as zeep_service
from . import schema

logger = getLogger(__name__)

DEFAULT_PAGE_LENGTH = 200


def _map_axl_fault(fault: Fault) -> Fault:
    """
    Maps incoming AXL faults to a more user-friendly format.

    Args:
        fault (Fault): Zeep Fault

    Returns:
        Fault: More friendly Fault
    """
    if not isinstance(fault.detail, (str, bytes)):
        # If a normal SOAP fault is returned then zeep parses the result and detail is an element.
        return fault

    # Otherwise the whole xml payload is placed in fault.detail as bytes
    def scrape_detail(fault: Fault) -> str | None:
        root: etree.ElementBase = etree.fromstring(fault.detail)
        try:
            content_header: str = next(
                iter(root.xpath("/html/body/div[@id='content']/div[@id='content-header']/text()")),
                "",
            )
            return content_header.strip()

        except Exception:
            return fault.detail

    return Fault(
        message=f"{fault.message}: {scrape_detail(fault)}",
        code=fault.code,
        actor=fault.actor,
        detail=fault.detail,
        subcodes=fault.subcodes,
    )


def sql_object(object_name: str) -> str:
    """
    Validates a SQL object name and returns it only if it is safe. This is used to prevent SQL
    injection attacks where the SQL statement itself is constructed dynamically. The function tests
    for invalid characters and replaces any invalid characters (non-alphanumeric or `_`) and raises
    a ValueError if the name is invalid.

    Args:
        object_name (str): The name of the SQL object to validate.
    Returns:
        str: The validated SQL object name.
    Raises:
        ValueError: If the object name contains invalid characters.
    Sample usage:
        >>> "select * from {}".format(sql_object("valid_name"))
        "select * from valid_name"

        >>> "select * from {}".format(sql_object("#invalid name"))
        Traceback (most recent call last):
        ...
        ValueError: Invalid SQL object name '#invalid name'
    """
    value = re_sub(r"[^a-zA-Z0-9_]", "_", object_name)
    if value != object_name:
        raise ValueError(f"Invalid SQL object name '{object_name}'")
    return value


def sql_object_is_valid(object_name: str) -> bool:
    """
    Checks if the SQL object name is valid. A valid SQL object name contains only alphanumeric
    characters and underscores.

    Args:
        object_name (str): The name of the SQL object to validate.

    Returns:
        bool: True if the object name is valid, False otherwise.
    """
    try:
        sql_object(object_name)
        return True
    except ValueError:
        return False


def _escape_string(s: str) -> str:
    return s.replace("'", "''")


def _format_param(param: Any) -> str:
    """
    Format the parameter for SQL substitution.
    Converts None to 'null', and other types to their string representation.

    Args:
        param: The parameter to format.

    Returns:
        str: The formatted parameter as a string suitable for SQL.

    Raises:
        ValueError: If the parameter type is not supported.
    """
    if param is None:
        return "null"

    elif isinstance(param, bool):
        return "'t'" if param else "'f'"

    elif isinstance(param, str):
        return f"'{_escape_string(param)}'"

    elif isinstance(param, (int, float)):
        return str(param)

    else:
        raise ValueError(f"Invalid parameter type: {type(param).__name__}")


def sql_prepare(sql: str, *args: Any, **kwargs: Any) -> str:
    """
    Prepare the SQL statement by replacing placeholders with actual values. The function supports
    both positional and named parameters. Positional parameters can be specified using `{}` or `?`,
    while named parameters must be specified using `{parameter_name}`. Parameters that are `None`
    will be replaced with `null`. The function also escapes single quotes in string parameters to
    prevent SQL injection.

    Args:
        sql (str): The SQL statement with placeholders.
        *args: Positional parameters to be substituted in the SQL statement.
        **kwargs: Named parameters to be substituted in the SQL statement.

    Returns:
        str: The SQL statement with placeholders replaced by actual values.

    Raises:
        ValueError: If an invalid parameter type is provided.

    Sample usage:
        >>> sql_prepare("SELECT * FROM users WHERE id = ?", 123)
        "SELECT * FROM users WHERE id = 123"

        >>> sql_prepare("SELECT * FROM users WHERE name = {name}", name="John")
        "SELECT * FROM users WHERE name = 'John'"

        >>> sql_prepare("SELECT * FROM users WHERE age = ? AND active = ?", 30, True)
        "SELECT * FROM users WHERE age = 30 AND active = 't'"

        >>> sql_prepare("SELECT * FROM users WHERE name = {name}", name="John O'Brien")
        "SELECT * FROM users WHERE name = 'John O''Brien'"
    """
    logger.debug(f"sql_prepare(sql={sql}, args={args}, kwargs={kwargs})")
    formatted_args = [_format_param(arg) for arg in args]
    logger.debug(f"Formatted positional args: {formatted_args}")
    formatted_kwargs = {k: _format_param(v) for k, v in kwargs.items() if v is not None}
    logger.debug(f"Formatted keyword args: {formatted_kwargs}")
    formatted_sql = re_sub(r"\?", "{}", sql)
    logger.debug(f"Formatted SQL: {formatted_sql}")
    result = formatted_sql.format(*formatted_args, **formatted_kwargs)
    logger.debug(f"Prepared SQL: {result}")
    return result


def sql_requires_limiting(sql: str) -> bool:
    """
    Determines if the SQL statement requires limiting the number of results. This is typically true
    for statements that do not already include a LIMIT or SKIP clause.

    Args:
        sql (str): The SQL statement to check.

    Returns:
        bool: True if the SQL statement requires limiting, False otherwise.
    """
    lower_sql = sql.lower().strip()
    return (
        lower_sql.startswith("select") and " limit " not in lower_sql and " skip " not in lower_sql
    )


def sql_slice(sql: str, length: int, index: int) -> str:
    """
    Add SKIP and LIMIT clauses to a SQL statement for pagination.

    Args:
        sql (str): The base SQL statement.
        length (int): The number of rows to limit.
        index (int): The page index (0-based).

    Returns:
        str: The SQL statement with SKIP and LIMIT clauses added.

    Raises:
        ValueError: If length <= 0 or index < 0.

    Example:
        >>> sql_slice("SELECT * FROM users", 10, 2)
        "SELECT * FROM users skip 20 limit 10"
    """
    if length <= 0:
        raise ValueError("Length must be greater than 0")
    if index < 0:
        raise ValueError("Index must be greater than or equal to 0")

    skip = index * length
    return f"{sql} skip {skip} limit {length}"


class AxlTemplate(ZeepTemplate):
    """
    A template class for Cisco Unified Communications Manager (CUCM) AXL operations.

    AXL (Administrative XML) provides programmatic access to CUCM configuration
    and administrative functions. This class extends ZeepTemplate to provide
    AXL-specific functionality including SQL query execution with automatic pagination.

    The class supports direct SQL queries against the CUCM database and automatic
    handling of large result sets through pagination.

    Example:
        >>> axl = AxlTemplate(
        ...     host="cucm.example.com",
        ...     username="admin",
        ...     password="password"
        ... )
        >>> devices = axl.sql("SELECT name FROM device WHERE name LIKE 'SEP%'")
    """

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        verify: bool = True,
        wsdl_path: Path = PATHS.WSDL.AXL.V15_0,
        response_mapper: Callable[[Dict[str, Any]], Dict[str, Any]] = lambda data: data,
        page_length: int = DEFAULT_PAGE_LENGTH,
    ):
        """
        Initialize the AxlTemplate with connection and configuration parameters.

        Args:
            host (str): The hostname or IP address of the CUCM server.
            username (str): Username for AXL authentication.
            password (str): Password for AXL authentication.
            wsdl_path (Path, optional): Path to the AXL WSDL file. Defaults to v15.0.
            response_mapper (Callable[[Dict[str, Any]], Dict[str, Any]]): A function
                to transform the response data.
            page_length (int, optional): Number of rows per page for SQL pagination.
                Defaults to DEFAULT_PAGE_LENGTH (200).
        """
        service: ServiceProxy = zeep_service(
            wsdl_path=str(wsdl_path),
            username=username,
            password=password,
            verify=verify,
            binding_name="{http://www.cisco.com/AXLAPIService/}AXLAPIBinding",
            address=f"https://{host}:8443/axl/",
        )

        self.page_length = page_length
        self.__schema: Schema | None = None
        super().__init__(service=service, response_mapper=response_mapper)

    def _call_zeep(self, operation_name, **kwargs):
        """
        Execute an AXL operation and extract the return value.

        Overrides the parent method to automatically extract the 'return' attribute
        from AXL responses, which is the standard AXL response format.

        Args:
            operation_name (str): Name of the AXL operation to call.
            **kwargs: Arguments to pass to the operation.

        Returns:
            The 'return' attribute from the AXL response, or the full response if no 'return'
            attribute exists.
        """
        try:
            result = super()._call_zeep(operation_name, **kwargs)
            return getattr(result, "return")

        except Fault as fault:
            raise _map_axl_fault(fault)

    @property
    def _schema(self) -> Schema:
        if self.__schema is None:
            self.__schema = Schema.from_wsdl(wsdl=self.client.wsdl)

        return self.__schema

    def iterate_page(self, operation_name: str, **kwargs) -> Generator[Dict[str, Any], None, None]:
        """
        Iterates over an AXL operation using `first` and `skip` until all results are exhausted,
        yielding each page of results.

        Args:
            operation_name (str): Name of the AXL operation to call.
            **kwargs: Additional arguments to pass to the operation. Supports the following
                special parameters:

            searchCriteria (dict, optional): Search criteria for filtering results.
                If not provided, automatically generates criteria to match all records
                based on the operation's schema definition.

            returnedTags (dict, optional): Dictionary specifying which fields to return.
                If not provided and `tags` is also not specified, automatically includes
                all available fields from the operation's schema.

            tags (list[str], optional): Simplified alternative to returnedTags.
                Provide a list of field names to return. This will be converted to the
                returnedTags format automatically. Cannot be used together with returnedTags.

        Yields:
            Each page of results from the AXL operation as a dictionary.
        """
        if "searchCriteria" not in kwargs:
            search_crit = schema.search_criteria(
                schema=self._schema,
                operation_name=operation_name,
            )
            if search_crit:
                kwargs.update(search_crit)

        if "returnedTags" not in kwargs:
            if "tags" in kwargs:
                tags = kwargs.pop("tags")
                kwargs.update(schema.to_returned_tags(*tags))

            else:
                returned_tags = schema.all_returned_tags(
                    schema=self._schema,
                    operation_name=operation_name,
                )
                if returned_tags:
                    kwargs.update(returned_tags)

        index = 0
        while True:
            kw = dict(kwargs)
            kw["first"] = self.page_length
            kw["skip"] = self.page_length * index
            response = self.call(operation_name, **kw)
            yield response

            items = next(iter(response.values()), [])
            if len(items) < self.page_length:
                return

            index += 1

    def iterate_entity(
        self,
        operation_name: str,
        **kwargs,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterates over an AXL operation yielding individual items instead of pages.

        This is a convenience wrapper around `iterate_page()` that automatically unpacks
        the results from each page, yielding individual items one at a time. It supports
        all the same parameters as `iterate_page()`, including automatic schema introspection
        for searchCriteria and returnedTags.

        Args:
            operation_name (str): Name of the AXL operation to call.
            **kwargs: Additional arguments to pass to the operation. Supports the same
                special parameters as `iterate_page()`:

                - searchCriteria (dict, optional): Search criteria for filtering results.
                - returnedTags (dict, optional): Dictionary specifying which fields to return.
                - tags (list[str], optional): Simplified list of field names to return.

                See `iterate_page()` for detailed parameter documentation.

        Yields:
            Individual items from the AXL operation results.

        Example:
            >>> for device in axl.iterate_entity("listPhone", tags=["name", "description"]):
            ...     print(device["name"])
        """
        for response in self.iterate_page(operation_name, **kwargs):
            items = next(iter(response.values()), [])
            for item in items:
                yield item

    def sql_select(
        self,
        sql: str,
        *args: Any,
        **kwargs: Any,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Execute a SQL query against the AXL service. If `args` or `kwargs` are provided, they will
        be substituted into the SQL query according to the `sql_prepare` function. Unless `skip` or
        `limit` are already present in the supplied `sql` statement, paging with `skip` and `limit`
        will be applied automatically within a loop until termination.

        The result is returned as a dictionary generator. If no parameters are provided, the SQL
        query is executed as is.

        Args:
            sql (str): The SQL query to execute.
            *args: Positional arguments to substitute into the SQL query.
            **kwargs: Keyword arguments to substitute into the SQL query.

        Returns:
            Generator[Dict[str, Any], None, None]: The results of the SQL query as a dictionary.

        Raises:
            ValueError: If the SQL query is invalid or if the parameters are of an unsupported type

        Sample usage:
            >>> for row in axl_template.sql_select("SELECT * FROM users WHERE id = ?", 123):
            ...     print(row["pkid"])

        Console output::

            DEBUG - executeSQLQuery(select * from credential skip 0 limit 200)
            83761b07-0887-49ff-acdc-68cd3932ef92
            43941071-3b4d-4359-bde7-5f21afd99f48
            1c7bec40-1def-4036-8160-e888921e2b3a
        """
        if not sql.strip().lower().startswith("select"):
            raise ValueError("sql_select requires a select statement")

        if args or kwargs:
            sql = sql_prepare(sql, *args, **kwargs)

        if not sql_requires_limiting(sql):
            logger.debug(f"executeSQLQuery({sql})")
            data = self.executeSQLQuery(sql=sql)
            rows: List[List[etree.ElementBase]] = data.get("row", [])
            yield from [elements_as_dict(row_elements) for row_elements in rows]
            return

        # Use pagination for queries that need limiting
        index = 0
        while True:
            statement = sql_slice(sql, length=self.page_length, index=index)
            logger.debug(f"executeSQLQuery({statement})")
            data = self.executeSQLQuery(sql=statement)
            rows: List[List[etree.ElementBase]] = data.get("row", [])
            if not rows:
                return

            yield from [elements_as_dict(row_elements) for row_elements in rows]

            if len(rows) < self.page_length:
                return

            index += 1

    def sql(
        self,
        sql: str,
        *args: Any,
        **kwargs: Any,
    ) -> List[Dict[str, Any]] | Any:
        """
        Execute a SQL statement against the AXL service using either `sql_select` (and
        `executeSQLQuery` but returning the entire result as a list) or `executeSQLUpdate` for
        non-select statements and returning the result.

        Args:
            sql (str): The SQL statement to execute. *args: Positional arguments to substitute into
            the SQL statement. **kwargs: Keyword arguments to substitute into the SQL statement.

        Returns:
            List[Dict[str, Any]]: The result of the SQL statement as a list of dictionaries.

        Raises:
            ValueError: If the SQL statement is invalid or if the parameters are of an unsupported
            type

        Sample usage:
            >>> result = axl_template.sql("SELECT * FROM users WHERE id = ?", 123)
            print(result)

        Console output::

            [
                {"id": 123, "name": "John Doe", ...}, {"id": 456, "name": "Jane Doe", ...}, ...
            ]
        """
        if sql.strip().lower().startswith("select"):
            return list(self.sql_select(sql, *args, **kwargs))

        if args or kwargs:
            sql = sql_prepare(sql, *args, **kwargs)

        data = self.executeSQLUpdate(sql=sql)
        return data

    def sql_scalar(
        self,
        sql: str,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Execute a SQL query and return a single scalar value.

        Args:
            sql (str): The SQL query to execute.
            *args: Positional arguments to substitute into the SQL query.
            **kwargs: Keyword arguments to substitute into the SQL query.

        Returns:
            Any: The scalar value from the first column of the first row.

        Raises:
            ValueError: If the query returns no rows, multiple rows, or multiple columns.

        Sample usage:
            >>> count = axl_template.sql_scalar("SELECT COUNT(*) FROM users")
            >>> print(count)
            42
        """
        result = self.sql(sql, *args, **kwargs)
        if not result:
            raise ValueError("SQL query returned no rows")

        if len(result) > 1:
            raise ValueError("SQL query returned more than one row")

        row = result[0]

        if len(row) == 0:
            raise ValueError("SQL query returned an empty row")

        if len(row) > 1:
            raise ValueError("SQL query returned more than one column")

        return next(iter(row.values()))
