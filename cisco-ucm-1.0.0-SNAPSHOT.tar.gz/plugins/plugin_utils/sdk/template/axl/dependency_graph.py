# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

"""
AXL Dependency Graph

Analyzes Cisco UCM AXL WSDL/XSD schemas to build object dependency graphs for all addXxxx
operations. Identifies foreign key relationships (XFkType fields) between objects to determine safe
provisioning and deletion ordering.

Overview:
    The dependency graph parses AXL schema files to identify relationships between objects. This
    helps:
    - Determine which objects need to be created before others
    - Calculate safe provisioning order for bulk operations
    - Calculate safe deletion order (reverse of provisioning)
    - Identify foundation objects (no dependencies)
    - Understand object relationships and dependencies

Basic Usage:
    >>> from pathlib import Path
    >>> from cisco.collab.ucm.sdk.template.axl.dependency_graph import DependencyGraph
    >>>
    >>> # Load the dependency graph
    >>> graph = DependencyGraph.from_wsdl(PATHS.WSDL.AXL.V15_0)
    >>>
    >>> # Get a specific object's dependencies
    >>> phone = graph.get_node('Phone')
    >>> print(f"Phone has {len(phone.dependencies)} dependencies")
    >>> for detail in phone.dependency_details[:3]:
    ...     print(f"  {detail.field} -> {detail.target}")
    >>>
    >>> # Get provisioning order (safe creation order)
    >>> order = graph.provisioning_order
    >>> print(f"Create {order[0]} first, {order[-1]} last")
    >>>
    >>> # Get deletion order (reverse of provisioning)
    >>> deletion = graph.deletion_order
    >>> print(f"Delete {deletion[0]} first, {deletion[-1]} last")

Schema Versions:
    Works with any AXL schema version. Tested with AXL 11.0 through 15.0.
"""

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from dataclasses import field as dataclass_field
from functools import cached_property
from pathlib import Path


@dataclass
class DependencyDetail:
    """Represents a single dependency relationship between objects.

    A DependencyDetail captures a field-level dependency where one AXL object
    references another object through a foreign key field (XFkType).

    Attributes:
        field: The field name that creates the dependency (e.g., 'callingSearchSpaceName')
        target: The target object that is depended upon (e.g., 'Css')

    Example:
        >>> detail = DependencyDetail(field='callingSearchSpaceName', target='Css')
        >>> print(f"{detail.field} references {detail.target}")
        callingSearchSpaceName references Css
        >>> detail.to_dict()
        {'field': 'callingSearchSpaceName', 'object': 'Css'}
    """

    field: str
    target: str

    def to_dict(self) -> dict[str, str]:
        """Convert dependency detail to dictionary format.

        Returns:
            Dictionary with 'field' and 'object' keys

        Example:
            >>> detail = DependencyDetail(field='callingSearchSpaceName', target='Css')
            >>> detail.to_dict()
            {'field': 'callingSearchSpaceName', 'object': 'Css'}

        Note:
            The target is serialized as 'object' (not 'target') for backwards compatibility.
        """
        return {"field": self.field, "object": self.target}


@dataclass
class ObjectNode:
    """Represents an AXL object node in the dependency graph.

    Each node represents an AXL object (like Phone, Line, Css) and tracks its
    relationships with other objects through dependencies and dependents.

    Attributes:
        name: Object name (e.g., 'Phone', 'Line', 'Css')
        dependencies: Set of object names this object depends on (must be created first)
        dependents: Set of object names that depend on this object (must be created after)
        fields: List of field names defined on this object
        dependency_details: List of DependencyDetail instances with field-level information

    Example:
        >>> # Get a node from the graph
        >>> phone = graph.get_node('Phone')
        >>> print(f"Phone depends on: {phone.dependencies}")
        Phone depends on: {'Css', 'DevicePool', 'Location', ...}
        >>>
        >>> # Check if it's a foundation object
        >>> print(f"Is foundation: {phone.is_foundation}")
        Is foundation: False
        >>>
        >>> # Get detailed dependency info
        >>> for detail in phone.dependency_details[:3]:
        ...     print(f"  {detail.field} -> {detail.target}")
        callingSearchSpaceName -> Css
        devicePoolName -> DevicePool
        locationName -> Location
        >>>
        >>> # See what depends on this object
        >>> css = graph.get_node('Css')
        >>> print(f"Objects that depend on Css: {len(css.dependents)}")
        Objects that depend on Css: 20
    """

    name: str
    dependencies: set[str] = dataclass_field(default_factory=set)
    dependents: set[str] = dataclass_field(default_factory=set)
    fields: list[str] = dataclass_field(default_factory=list)
    dependency_details: list[DependencyDetail] = dataclass_field(default_factory=list)

    @property
    def is_foundation(self) -> bool:
        """True if this object has no dependencies (foundation object).

        Foundation objects can be created without any prerequisites and are
        typically created first in a provisioning workflow.

        Returns:
            True if the object has no dependencies, False otherwise

        Example:
            >>> css = graph.get_node('Css')
            >>> print(f"Css is foundation: {css.is_foundation}")
            Css is foundation: True
            >>>
            >>> phone = graph.get_node('Phone')
            >>> print(f"Phone is foundation: {phone.is_foundation}")
            Phone is foundation: False
            >>>
            >>> # Find all foundation objects
            >>> foundation = [name for name, node in graph.nodes.items()
            ...               if node.is_foundation]
            >>> print(f"Found {len(foundation)} foundation objects")
            Found 93 foundation objects
        """
        return len(self.dependencies) == 0

    def to_dict(self) -> dict:
        """Convert node to dictionary format for serialization.

        Returns:
            Dictionary with all node attributes, with sets converted to sorted lists

        Example:
            >>> phone = graph.get_node('Phone')
            >>> data = phone.to_dict()
            >>> print(data['name'])
            Phone
            >>> print(data['is_foundation'])
            False
            >>> print(len(data['dependencies']))
            27
        """
        return {
            "name": self.name,
            "dependencies": sorted(self.dependencies),
            "dependents": sorted(self.dependents),
            "fields": self.fields,
            "dependency_details": [detail.to_dict() for detail in self.dependency_details],
            "is_foundation": self.is_foundation,
        }


@dataclass
class DependencyGraph:
    """Complete dependency graph for all AXL objects in a schema.

    The DependencyGraph is the main class for working with AXL object dependencies.
    It provides methods to query dependencies, get provisioning/deletion order,
    and analyze object relationships.

    Attributes:
        nodes: Dictionary mapping object names to ObjectNode instances

    Usage:
        Create a graph using the from_wsdl() class method:

        >>> from pathlib import Path
        >>> graph = DependencyGraph.from_wsdl(PATHS.WSDL.AXL.V1X_0)

    Querying the Graph:
        >>> # Get a specific object
        >>> phone = graph.get_node('Phone')
        >>> print(f"Phone has {len(phone.dependencies)} dependencies")
        >>>
        >>> # Iterate over all nodes
        >>> for name, node in graph.nodes.items():
        ...     if node.is_foundation:
        ...         print(f"{name} is a foundation object")

    Provisioning Order:
        >>> # Get safe creation order
        >>> order = graph.provisioning_order  # Cached property
        >>> print(f"Create objects in this order: {order[:5]}")
        Create objects in this order: ['AarGroup', 'Announcement', 'Css', ...]
        >>>
        >>> # Validate you can create an object
        >>> phone = graph.get_node('Phone')
        >>> created = {'Css', 'DevicePool', 'Location'}
        >>> missing = phone.dependencies - created
        >>> if missing:
        ...     print(f"Cannot create Phone yet. Missing: {missing}")

    Deletion Order:
        >>> # Get safe deletion order (reverse of provisioning)
        >>> deletion_order = graph.deletion_order  # Cached property
        >>> print(f"Delete objects in this order: {deletion_order[:5]}")
        Delete objects in this order: ['RemoteDestination', 'VohServer', ...]

    Serialization:
        >>> # Export to dictionary
        >>> data = graph.to_dict()
        >>> import json
        >>> with open('dependencies.json', 'w') as f:
        ...     json.dump(data, f, indent=2)

    Finding Foundation Objects:
        >>> # Objects with no dependencies
        >>> foundation = [name for name, node in graph.nodes.items()
        ...               if node.is_foundation]
        >>> print(f"Foundation objects: {foundation[:5]}")
        Foundation objects: ['AarGroup', 'Announcement', 'Css', ...]

    Finding Most Referenced Objects:
        >>> # Find objects many others depend on
        >>> most_referenced = sorted(
        ...     graph.nodes.items(),
        ...     key=lambda x: len(x[1].dependents),
        ...     reverse=True
        ... )[:5]
        >>> for name, node in most_referenced:
        ...     print(f"{name}: {len(node.dependents)} dependents")
        Css: 20 dependents
        DevicePool: 16 dependents
        Location: 14 dependents
    """

    nodes: dict[str, ObjectNode] = dataclass_field(default_factory=dict)

    def get_node(self, name: str) -> ObjectNode | None:
        """Get an ObjectNode by name.

        Args:
            name: The object name (e.g., 'Phone', 'Line', 'Css')

        Returns:
            ObjectNode instance if found, None otherwise

        Example:
            >>> phone = graph.get_node('Phone')
            >>> if phone:
            ...     print(f"Phone has {len(phone.dependencies)} dependencies")
            >>>
            >>> # Handle missing objects
            >>> node = graph.get_node('NonExistent')
            >>> if node is None:
            ...     print("Object not found")
        """
        return self.nodes.get(name)

    def add_node(self, node: ObjectNode) -> None:
        """Add an ObjectNode to the graph.

        Args:
            node: The ObjectNode instance to add

        Note:
            This is primarily used internally by the builder. Most users should
            use DependencyGraph.from_wsdl() to create graphs rather than building
            them manually.

        Example:
            >>> node = ObjectNode(name='CustomObject')
            >>> graph.add_node(node)
            >>> graph.get_node('CustomObject')
            ObjectNode(name='CustomObject', ...)
        """
        self.nodes[node.name] = node

    def to_dict(self) -> dict:
        """Convert the graph to a dictionary for serialization.

        Returns:
            Dictionary with 'nodes' key containing all object nodes as dicts

        Example:
            >>> data = graph.to_dict()
            >>> print(data.keys())
            dict_keys(['nodes'])
            >>>
            >>> # Access a specific node
            >>> phone_data = data['nodes']['Phone']
            >>> print(phone_data['dependencies'])
            ['Css', 'DevicePool', 'Location', ...]
            >>>
            >>> # Export to JSON
            >>> import json
            >>> with open('dependencies.json', 'w') as f:
            ...     json.dump(data, f, indent=2)
        """
        return {"nodes": {name: node.to_dict() for name, node in self.nodes.items()}}

    @classmethod
    def from_wsdl(cls, wsdl_path: Path) -> "DependencyGraph":
        """Build a dependency graph from an AXL WSDL file.

        This is the primary and recommended method for creating a DependencyGraph.
        It analyzes the WSDL/XSD schema to extract all object dependencies.

        Args:
            wsdl_path: Path to the AXLAPI.wsdl file

        Returns:
            DependencyGraph with all nodes populated and ready for queries

        Raises:
            FileNotFoundError: If the WSDL file doesn't exist
            ValueError: If the WSDL file is invalid or cannot be parsed

        Example:
            >>> from pathlib import Path
            >>> from cisco.collab.ucm.sdk.template.axl.dependency_graph import DependencyGraph
            >>>
            >>> # Load from a specific version
            >>> graph = DependencyGraph.from_wsdl(PATHS.WSDL.AXL.V15_0)
            >>>
            >>> # Get provisioning order immediately
            >>> order = graph.provisioning_order
            >>> print(f"First object to create: {order[0]}")
            First object to create: AarGroup
        """
        builder = _DependencyGraphBuilder(wsdl_path)
        return builder.build()

    @cached_property
    def provisioning_order(self) -> list[str]:
        """Get the safe provisioning/creation order for all objects.

        Returns a topologically sorted list where objects appear after all their
        dependencies. This ensures you can safely create objects in this order
        without violating foreign key constraints.

        Foundation objects (no dependencies) appear first, complex objects with
        many dependencies appear last. Self-references are handled automatically.

        Returns:
            Ordered list of object names. Create in this order for safe provisioning.

        Example:
            >>> # Get the order once (computed and cached)
            >>> order = graph.provisioning_order
            >>> print(f"Total objects: {len(order)}")
            Total objects: 180
            >>>
            >>> # Foundation objects come first
            >>> print(f"First 5: {order[:5]}")
            First 5: ['AarGroup', 'Announcement', 'Css', 'Location', ...]
            >>>
            >>> # Complex objects come last
            >>> print(f"Last 5: {order[-5:]}")
            Last 5: [..., 'RemoteDestinationProfile', 'Phone', 'User']
            >>>
            >>> # Use for bulk provisioning
            >>> objects_to_create = ['Phone', 'Line', 'Css', 'DevicePool']
            >>> filtered_order = [obj for obj in order if obj in objects_to_create]
            >>> print(f"Create in this order: {filtered_order}")
            Create in this order: ['Css', 'DevicePool', 'Line', 'Phone']
            >>>
            >>> # Validate before creating
            >>> phone_index = order.index('Phone')
            >>> deps = graph.get_node('Phone').dependencies
            >>> for dep in deps:
            ...     dep_index = order.index(dep) if dep in order else -1
            ...     if dep_index > phone_index:
            ...         print(f"Error: {dep} should come before Phone!")

        Performance:
            The result is cached after first computation. Subsequent accesses are O(1).

        Note:
            Some objects may have circular self-references (e.g., Phone.primaryPhoneName).
            These are handled by filtering out self-dependencies during the sort.
        """
        # Build dependency graph
        dep_graph = {}
        for obj_name, node in self.nodes.items():
            dep_graph[obj_name] = node.dependencies.copy()

        # Topological sort
        provisioned = set()
        order = []
        remaining = set(self.nodes.keys())
        max_iterations = len(remaining) + 1
        iteration = 0

        while remaining and iteration < max_iterations:
            iteration += 1

            # Find objects whose dependencies are all satisfied
            ready = []
            for obj in remaining:
                obj_deps = dep_graph.get(obj, set())
                # Filter out self-references
                obj_deps = {d for d in obj_deps if d != obj}
                # Check if all dependencies are either provisioned or don't exist in our object list
                if all(dep in provisioned or dep not in self.nodes for dep in obj_deps):
                    ready.append(obj)

            if not ready:
                # Circular dependency detected - add remaining sorted by dependency count
                ready = sorted(remaining, key=lambda x: len(dep_graph.get(x, set())))[:1]

            # Sort ready objects alphabetically for consistent ordering
            ready.sort()

            # Add to order and mark as provisioned
            order.extend(ready)
            provisioned.update(ready)
            remaining -= set(ready)

        return order

    @cached_property
    def deletion_order(self) -> list[str]:
        """Get the safe deletion order for all objects.

        Returns the reverse of provisioning order. Objects that other objects depend on
        must be deleted last to maintain referential integrity. Delete in this order
        to safely remove objects without violating foreign key constraints.

        Returns:
            Ordered list of object names. Delete in this order for safe removal.

        Example:
            >>> # Get the order once (computed and cached)
            >>> order = graph.deletion_order
            >>>
            >>> # Objects with dependencies come first (deleted first)
            >>> print(f"First to delete: {order[:5]}")
            First to delete: ['RemoteDestination', 'VohServer', 'SipRoutePattern', ...]
            >>>
            >>> # Foundation objects come last (deleted last)
            >>> print(f"Last to delete: {order[-5:]}")
            Last to delete: [..., 'Css', 'Location', 'DevicePool']
            >>>
            >>> # Use for bulk deletion
            >>> objects_to_delete = ['Phone', 'Line', 'Css', 'DevicePool']
            >>> filtered_order = [obj for obj in order if obj in objects_to_delete]
            >>> print(f"Delete in this order: {filtered_order}")
            Delete in this order: ['Phone', 'Line', 'DevicePool', 'Css']
            >>>
            >>> # Verify order is safe
            >>> phone = graph.get_node('Phone')
            >>> phone_index = order.index('Phone')
            >>> for dep in phone.dependencies:
            ...     dep_index = order.index(dep) if dep in order else -1
            ...     if dep_index < phone_index and dep_index != -1:
            ...         print(f"Safe: {dep} deleted after Phone")

        Relationship to Provisioning:
            >>> # Deletion is exact reverse of provisioning
            >>> prov_order = graph.provisioning_order
            >>> del_order = graph.deletion_order
            >>> assert del_order == list(reversed(prov_order))

        Performance:
            The result is cached after first computation. Subsequent accesses are O(1).

        Use Cases:
            - Bulk deletion operations
            - Cleaning up test data
            - Removing entire configurations
            - Decommissioning systems
        """
        return list(reversed(self.provisioning_order))


class _DependencyGraphBuilder:
    """
    Internal builder class for constructing DependencyGraph from AXL schemas.

    Parses WSDL and XSD files to identify foreign key relationships between objects.
    This class is private - users should use DependencyGraph.from_wsdl() instead.
    """

    # XML Namespaces
    NAMESPACES = {
        "xsd": "http://www.w3.org/2001/XMLSchema",
        "axlapi": "http://www.cisco.com/AXL/API/15.0",
        "wsdl": "http://schemas.xmlsoap.org/wsdl/",
    }

    # Pre-compiled regex for field name normalization
    FIELD_NAME_REGEX = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)")

    # Known abbreviation mappings
    ABBREVIATIONS = {
        "callingSearchSpace": "Css",
        "devicePool": "DevicePool",
        "commonDeviceConfig": "CommonDeviceConfig",
        "commonPhoneConfig": "CommonPhoneConfig",
        "location": "Location",
        "mediaResourceList": "MediaResourceList",
        "aarNeighborhood": "AarNeighborhood",
        "securityProfile": "PhoneSecurityProfile",
        "sipProfile": "SipProfile",
        "geoLocation": "GeoLocation",
        "geoLocationFilter": "GeoLocationFilter",
        "phoneTemplate": "PhoneButtonTemplate",
        "softkeyTemplate": "SoftkeyTemplate",
        "defaultProfile": "DefaultDeviceProfile",
        "subscriptionCss": "Css",
        "reroutingCss": "Css",
        "callPickupGroup": "CallPickupGroup",
        "callPark": "CallPark",
        "voiceMailProfile": "VoiceMailProfile",
        "lineGroup": "LineGroup",
        "huntList": "HuntList",
        "routeList": "RouteList",
        "routeGroup": "RouteGroup",
        "translation": "TransPattern",
        "phoneNtp": "PhoneNtp",
        "mediaResourceGroup": "MediaResourceGroup",
        "region": "Region",
        "srstReference": "Srst",
        "processNode": "ProcessNode",
        "recordingProfile": "RecordingProfile",
        "mrgl": "MediaResourceList",
        "mobility": "RemoteDestinationProfile",
        "dndOption": "DndOption",
        "cgpnTransformationCss": "Css",
        "automatedAlternateRoutingCss": "Css",
        "primaryPhone": "Phone",
        "owner": "User",
        "certificateOperation": "CertificateOperation",
    }

    def __init__(self, wsdl_path: Path):
        """
        Initialize the graph builder.

        Args:
            wsdl_path: Path to the AXLAPI.wsdl file
        """
        self.wsdl_path = wsdl_path
        if not self.wsdl_path.exists():
            raise FileNotFoundError(f"WSDL file not found: {wsdl_path}")

        self.schema_path = self._find_schema_from_wsdl()
        self._root = None
        self._graph: DependencyGraph | None = None
        self._parse_schema()

    def _find_schema_from_wsdl(self) -> Path:
        """
        Parse WSDL to find the imported schema file (AXLSoap.xsd).

        Returns:
            Path to the schema file

        Raises:
            FileNotFoundError: If schema file cannot be found
        """
        tree = ET.parse(self.wsdl_path)
        root = tree.getroot()

        # Look for import elements in the WSDL (uses WSDL namespace, not XSD)
        for import_element in root.findall(".//wsdl:import", self.NAMESPACES):
            location = import_element.get("location")
            if location and location.endswith(".xsd"):
                schema_path = self.wsdl_path.parent / location
                if schema_path.exists():
                    return schema_path

        # Also check for imports in default namespace (when xmlns="http://schemas.xmlsoap.org/wsdl/")
        for import_element in root.findall(".//{http://schemas.xmlsoap.org/wsdl/}import"):
            location = import_element.get("location")
            if location and location.endswith(".xsd"):
                schema_path = self.wsdl_path.parent / location
                if schema_path.exists():
                    return schema_path

        # Fallback: try standard name AXLSoap.xsd in same directory
        schema_path = self.wsdl_path.parent / "AXLSoap.xsd"
        if schema_path.exists():
            return schema_path

        raise FileNotFoundError(
            f"Could not find schema file (AXLSoap.xsd) referenced by WSDL: {self.wsdl_path}"
        )

    def _parse_schema(self) -> None:
        """Parse the XSD schema file."""
        tree = ET.parse(self.schema_path)
        self._root = tree.getroot()

    def _find_add_operations(self) -> dict[str, dict[str, str]]:
        """
        Find all addXxxx elements in the schema.

        Returns:
            Dict mapping object names to their operation info
        """
        add_operations = {}

        for element in self._root.findall(".//xsd:element", self.NAMESPACES):
            name = element.get("name")
            if name and name.startswith("add") and not name.endswith("Response"):
                element_type = element.get("type")
                if element_type and element_type.startswith("axlapi:"):
                    # Extract object name from addXxxx
                    object_name = name[3:]  # Remove 'add' prefix
                    add_operations[object_name] = {
                        "operation": name,
                        "type": element_type.replace("axlapi:", ""),
                    }

        return add_operations

    @cached_property
    def _complex_types(self) -> dict[str, ET.Element]:
        """
        Get all complex types defined in the schema.

        Returns:
            Dict mapping complex type names to their XML elements
        """
        complex_types = {}
        for ct in self._root.findall(".//xsd:complexType", self.NAMESPACES):
            name = ct.get("name")
            if name:
                complex_types[name] = ct
        return complex_types

    def _find_complex_type(self, type_name: str) -> ET.Element | None:
        """
        Find a complex type definition in the schema.

        Args:
            type_name: Name of the complex type

        Returns:
            XML Element or None if not found
        """
        # Remove namespace prefix if present
        if ":" in type_name:
            type_name = type_name.split(":")[1]

        if type_name in self._complex_types:
            return self._complex_types[type_name]

        return None

    def _extract_fk_fields(self, complex_type: ET.Element | None) -> list[str]:
        """
        Extract all XFkType fields from a complex type.

        Args:
            complex_type: XML element of the complex type

        Returns:
            List of field names that are foreign keys
        """
        if complex_type is None:
            return []

        fk_fields = []

        # Find all elements in the complex type
        for element in complex_type.findall(".//xsd:element", self.NAMESPACES):
            element_type = element.get("type")
            element_name = element.get("name")

            # Check if it's an XFkType (foreign key reference)
            if element_type == "axlapi:XFkType" and element_name:
                fk_fields.append(element_name)

        return fk_fields

    def _normalize_field_name(self, field_name: str) -> list[str]:
        """
        Convert a field name to potential object names.

        Args:
            field_name: Field name like 'callingSearchSpaceName'

        Returns:
            List of possible object names
        """
        # Remove common suffixes
        name = field_name
        for suffix in ["Name", "Id", "Uuid"]:
            if name.endswith(suffix):
                name = name[: -len(suffix)]
                break

        potential_names = []

        # Check abbreviations first
        if name in self.ABBREVIATIONS:
            potential_names.append(self.ABBREVIATIONS[name])

        # Full name with proper capitalization
        full_name = "".join(word.capitalize() for word in self.FIELD_NAME_REGEX.findall(name))
        potential_names.append(full_name)

        # Keep original as fallback
        if name not in potential_names:
            potential_names.append(name)

        return potential_names

    def _find_base_object_type(self, req_type_name: str) -> str | None:
        """
        Find the base object type from a request type.

        For example, AddPhoneReq contains a 'phone' element of type XPhone.

        Args:
            req_type_name: Request type name like 'AddPhoneReq'

        Returns:
            Base type name like 'XPhone' or None
        """
        req_type = self._find_complex_type(req_type_name)
        if req_type is None:
            return None

        # Look for elements in the request type that reference X types
        for element in req_type.findall(".//xsd:element", self.NAMESPACES):
            element_type = element.get("type")

            # Look for types like axlapi:XPhone, axlapi:XCss, etc.
            if element_type and element_type.startswith("axlapi:X"):
                base_type = element_type.replace("axlapi:", "")
                return base_type

        return None

    def build(self) -> DependencyGraph:
        """
        Build the complete dependency graph as a DependencyGraph dataclass.

        This is the primary method for accessing dependency information. The graph
        is built once and cached for subsequent calls.

        Returns:
            DependencyGraph with all nodes and provisioning order populated.

        Example:
            >>> builder = _DependencyGraphBuilder(wsdl_path)
            >>> graph = builder.get_graph()
            >>> phone_node = graph.get_node('Phone')
            29
        """
        if self._graph is not None:
            return self._graph

        # Analyze schema to get raw dependencies
        add_operations = self._find_add_operations()
        dependency_map = {}

        for object_name, operation_info in add_operations.items():
            req_type = operation_info["type"]

            # Find the base object type (e.g., XPhone for AddPhoneReq)
            base_type = self._find_base_object_type(req_type)

            if not base_type:
                # Fallback: try to find the request type directly
                complex_type = self._find_complex_type(req_type)
            else:
                # Find the XPhone (or similar) complex type
                complex_type = self._find_complex_type(base_type)

            # Extract FK fields
            fk_fields = self._extract_fk_fields(complex_type)

            # Normalize field names to object names
            dep_list = []
            for field in fk_fields:
                normalized = self._normalize_field_name(field)
                # Use the first (most likely) possible object name
                target = normalized[0] if normalized else field
                dep_list.append(DependencyDetail(field=field, target=target))

            dependency_map[object_name] = dep_list

        # Build dependency graph (object -> set of dependencies)
        dep_graph = {}
        for obj, dep_list in dependency_map.items():
            dep_graph[obj] = {dep.target for dep in dep_list}

        # Create the graph
        graph = DependencyGraph()

        # Create all nodes first
        for object_name in dependency_map:
            node = ObjectNode(
                name=object_name,
                dependencies=dep_graph.get(object_name, set()).copy(),
                dependency_details=dependency_map[object_name],
            )
            graph.add_node(node)

        # Now populate dependents (reverse relationships)
        for object_name, node in graph.nodes.items():
            for dependency in node.dependencies:
                # Exclude self-references
                if dependency in graph.nodes and dependency != object_name:
                    graph.nodes[dependency].dependents.add(object_name)

        # Cache the graph
        self._graph = graph
        return graph
