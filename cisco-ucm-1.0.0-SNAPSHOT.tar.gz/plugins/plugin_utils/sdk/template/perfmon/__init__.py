# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from logging import getLogger
from typing import Any, Callable, Dict

from zeep.proxy import ServiceProxy

from ... import PATHS
from ..zeep import ZeepTemplate
from ..zeep import service as zeep_service

logger = getLogger(__name__)

# Default Perfmon service port and path
DEFAULT_PERFMON_PORT = 8443
DEFAULT_PERFMON_PATH = "/perfmonservice2/services/PerfmonService"

# Common Perfmon binding namespace
PERFMON_BINDING_NAMESPACE = "{http://schemas.cisco.com/ast/soap}PerfmonBinding"


class PerfmonTemplate(ZeepTemplate):
    """
    A template class for Cisco Unified Communications Manager (CUCM) Perfmon operations.

    This class provides a SOAP client interface for performance monitoring operations
    on CUCM servers using the Perfmon web service. It extends ZeepTemplate to provide
    perfmon-specific functionality.

    The Perfmon service allows monitoring of system performance counters, real-time
    statistics, and other performance metrics from CUCM.

    Example:
        >>>
        perfmon = PerfmonTemplate(
            host="cucm.example.com",
            username="admin",
            password="password"
        )
        # Use perfmon methods here
    """

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        verify: bool = True,
        response_mapper: Callable[[Dict[str, Any]], Dict[str, Any]] = lambda data: data,
    ) -> None:
        """
        Initialize the PerfmonTemplate with connection parameters.

        Args:
            host (str): The hostname or IP address of the CUCM server.
            username (str): Username for authentication.
            password (str): Password for authentication.
            response_mapper (Callable[[Dict[str, Any]], Dict[str, Any]]): A function
                to transform the response data.

        Raises:
            ValueError: If host, username, or password are empty.
        """
        if not host or not host.strip():
            raise ValueError("Host cannot be empty")
        if not username or not username.strip():
            raise ValueError("Username cannot be empty")
        if not password:
            raise ValueError("Password cannot be empty")

        try:
            service: ServiceProxy = zeep_service(
                wsdl_path=str(PATHS.WSDL.PERFMON),
                username=username,
                password=password,
                verify=verify,
                binding_name=PERFMON_BINDING_NAMESPACE,
                address=f"https://{host.strip()}:{DEFAULT_PERFMON_PORT}{DEFAULT_PERFMON_PATH}",
            )
        except Exception as e:
            logger.error(f"Failed to create Perfmon service: {e}")
            raise

        super().__init__(service=service, response_mapper=response_mapper)
