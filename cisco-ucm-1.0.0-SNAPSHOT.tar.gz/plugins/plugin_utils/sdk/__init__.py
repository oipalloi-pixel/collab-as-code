# Copyright (c) 2025-2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from pathlib import Path


def base_dir_path() -> Path:
    return Path(__file__).resolve().parent


_BASE_PATH = base_dir_path()
_SCHEMA_PATH = _BASE_PATH / "resources" / "schemas"


class PATHS:

    BASE_PATH = _BASE_PATH
    GENERATED = _BASE_PATH / "generated"

    class WSDL:
        class AXL:
            # Supported WSDL versions
            VERSION_V11_0 = "11.0"
            VERSION_V11_5 = "11.5"
            VERSION_V12_0 = "12.0"
            VERSION_V12_5 = "12.5"
            VERSION_V14_0 = "14.0"
            VERSION_V15_0 = "15.0"

            ALL_VERSIONS = [
                VERSION_V11_0,
                VERSION_V11_5,
                VERSION_V12_0,
                VERSION_V12_5,
                VERSION_V14_0,
                VERSION_V15_0,
            ]

            V11_0 = _SCHEMA_PATH / "axl/11.0/AXLAPI.wsdl"
            V11_5 = _SCHEMA_PATH / "axl/11.5/AXLAPI.wsdl"
            V12_0 = _SCHEMA_PATH / "axl/12.0/AXLAPI.wsdl"
            V12_5 = _SCHEMA_PATH / "axl/12.5/AXLAPI.wsdl"
            V14_0 = _SCHEMA_PATH / "axl/14.0/AXLAPI.wsdl"
            V15_0 = _SCHEMA_PATH / "axl/15.0/AXLAPI.wsdl"

            @staticmethod
            def for_version(version: str) -> Path:
                """Get the WSDL path for the specified version.

                Args:
                    version: Version string (e.g., "11.5", "12.0").

                Returns:
                    Path: Path to the WSDL file.

                Raises:
                    ValueError: If the version is not supported.
                """

                version_map = {
                    PATHS.WSDL.AXL.VERSION_V11_0: PATHS.WSDL.AXL.V11_0,
                    PATHS.WSDL.AXL.VERSION_V11_5: PATHS.WSDL.AXL.V11_5,
                    PATHS.WSDL.AXL.VERSION_V12_0: PATHS.WSDL.AXL.V12_0,
                    PATHS.WSDL.AXL.VERSION_V12_5: PATHS.WSDL.AXL.V12_5,
                    PATHS.WSDL.AXL.VERSION_V14_0: PATHS.WSDL.AXL.V14_0,
                    PATHS.WSDL.AXL.VERSION_V15_0: PATHS.WSDL.AXL.V15_0,
                }
                if version not in version_map:
                    raise ValueError(f"Unsupported AXL WSDL version: {version}")
                return version_map[version]

        PERFMON = _SCHEMA_PATH / "perfmon/perfmon.wsdl"
        RISPORT = _SCHEMA_PATH / "risport/risport70.wsdl"
