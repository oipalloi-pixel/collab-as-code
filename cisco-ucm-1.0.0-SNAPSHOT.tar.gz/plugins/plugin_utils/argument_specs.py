#!/usr/bin/env python

# Copyright (c) 2026 by Cisco Systems, Inc.
#
# ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
# OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL AND PROPRIETARY
# INFORMATION. REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
# PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
# CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.

from __future__ import absolute_import, division, print_function

__metaclass__ = type

try:
    from ansible_collections.cisco.ucm.plugins.plugin_utils.sdk import PATHS
except ImportError:
    SDK_IS_INSTALLED = False
else:
    SDK_IS_INSTALLED = True


def host_credentials_verify():
    return {
        "username": {"type": "str", "required": True},
        "password": {"type": "str", "required": True, "no_log": True},
        "hostname": {"type": "str", "required": True},
        "verify": {"type": "bool", "required": False, "default": True},
    }


def axl_version():
    return {
        "version": {
            "type": "str",
            "required": True,
            "choices": PATHS.WSDL.AXL.ALL_VERSIONS,
        },
    }
