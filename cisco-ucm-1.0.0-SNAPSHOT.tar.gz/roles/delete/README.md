# delete

Removes CUCM objects that are present on the cluster but absent from the intended state.

## Safety

**Read this before use.**

### 1. Object-type scoping
Only object types with `delete: true` in `roles/common/defaults/main.yml` are
candidates for deletion. Types with `delete: false` (e.g. `Location`, `ProcessNode`,
`ServiceParameter`) are never touched regardless of what is in `current` or `intended`.

### 2. Exact-set semantics
For each eligible type, any object present in `current` but absent from `intended` is deleted.
There is no annotation-based safety filter — the intended YAML is the sole source of truth.
Ensure `intended` reflects every object you want to keep.

### 3. Run-time opt-in gate
Deletions are disabled by default (`delete: false`). The role exits immediately unless the
caller explicitly passes `delete: true`. This default cannot be changed in inventory.

## Pipeline Position

```
collect  ──►  diff  ──►  configure  ──►  delete
```

`delete` runs after `configure`. Both roles are independent — either may be omitted.

## Input Requirements

- **`current`** must be collected using the **full object registry** (do not pass a subset
  collect). If `current` is missing a deletable type entirely, objects of that type on UCM will
  not be considered for deletion and drift will silently persist.
- **`intended`** is typically `{{ ucm }}` — the `ucm.*` key from `host_vars/`.
- Both inputs must be in **data model format** (snake_case keys, Python booleans).

## Dependency Order

Delete operations are automatically sorted in reverse dependency order (children before parents)
by `plan()` in `diff`. No additional sorting is needed.

## Check Mode

The underlying `cisco.ucm.configure` module supports `--check`. In check mode, planned
deletions are logged but no AXL calls are made.

## Output Variable

`delete_result` is registered when deletions are applied. It may be undefined when
`delete` is false or when no deletable objects were found. Guard with
`delete_result is defined` before referencing it.

## Connection Variables

| Variable | Default | Description |
|---|---|---|
| `hostname` | `{{ uc_hostname }}` | Hostname or IP of the CUCM AXL service |
| `username` | `{{ uc_app_username }}` | AXL API username |
| `password` | `{{ uc_app_password }}` | AXL API password |
| `version` | `{{ uc_version }}` | CUCM version string (e.g. `14.0`) |
| `verify` | `true` | Whether to verify TLS certificates |

## Example

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.collect
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"

- ansible.builtin.include_role:
    name: cisco.ucm.configure
  vars:
    operations: "{{ diff_operations }}"

- ansible.builtin.include_role:
    name: cisco.ucm.delete
  vars:
    delete: true
    current: "{{ collect_state }}"
    intended: "{{ ucm }}"
```

To preview what would be deleted without making changes, add `--check` to the `ansible-playbook`
command. The role will log each planned deletion but make no AXL calls.
