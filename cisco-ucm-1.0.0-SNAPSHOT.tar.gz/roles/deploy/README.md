# deploy

Applies UCM configuration changes: diff → configure → (optional) delete.

## Overview

`deploy` is a pure orchestration role. It accepts current and intended state, computes the
diff, and applies the resulting operations. It has no file I/O side effects.

Current state must be provided by the caller — typically by running `cisco.ucm.resolve`
immediately before, which populates `collect_state`.

## Pipeline

```
[Stage 1]  diff(current, intended) ──► diff_operations
           │
           ▼ (when create or update in actions)
[Stage 2]  configure ──► applies add/update operations
           │
           ▼ (only when 'delete' in actions)
[Stage 3]  delete ──► removes drift objects
```

## Why Current State Is Required

UCM has no upsert API. The AXL `add*` and `update*` operations have different argument
shapes, and calling `add*` on an existing object raises a SOAP fault. The diff must therefore
know the current state before generating the operations list.

## Actions

The `actions` list controls which pipeline stages run.

| `actions` value | Effect |
|---|---|
| `[create, update]` (default) | Safe mode — no deletions |
| `[create, update, delete]` | Full sync including drift removal |
| `[create]` | Provision net-new objects only |
| `[delete]` | Remove drift objects only |

Delete is opt-in. Stage 3 only runs when `'delete' in actions`.

## Examples

Typical usage — run refresh first to populate `collect_state`:

```yaml
- ansible.builtin.include_role:
        name: cisco.ucm.resolve
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    state_file_path: "{{ state_path }}/{{ inventory_hostname }}_state.yml"

- ansible.builtin.include_role:
    name: cisco.ucm.deploy
  vars:
    intended: "{{ ucm }}"
    current: "{{ collect_state }}"
```

With drift removal:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.deploy
  vars:
    intended: "{{ ucm }}"
    current: "{{ collect_state }}"
    actions: [create, update, delete]
```

Provision net-new objects only:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.deploy
  vars:
    intended: "{{ ucm }}"
    current: "{{ collect_state }}"
    actions: [create]
```

## Variable Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `intended` | yes | — | Intended CUCM state in data model format (pass `{{ ucm }}`) |
| `current` | yes | — | Current CUCM state in data model format (pass `{{ collect_state }}`) |
| `hostname` | yes | — | CUCM AXL hostname or IP |
| `username` | yes | — | AXL API username |
| `password` | yes | — | AXL API password |
| `version` | yes | — | CUCM version string (e.g. `14.0`) |
| `verify` | no | `true` | Whether to verify TLS certificates |
| `actions` | no | `[create, update]` | List of operation types to execute (`create`, `update`, `delete`) |
