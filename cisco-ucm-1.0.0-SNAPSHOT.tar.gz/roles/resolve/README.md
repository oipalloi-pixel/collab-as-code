# resolve

Ensures `collect_state` is populated using a local cache when available, or a live collect
from UCM otherwise.

## Overview

The role resolves current UCM state into `collect_state` using the best available source:

- If a cached state file exists at `state_file_path` and `force_collect` is `false` — load
  from disk. No API call is made.
- Otherwise — run a live collect via `cisco.ucm.collect` and optionally persist the result.

This design supports all common usage patterns with a single consistent interface:

| Scenario | `force_collect` | `save_state` | Behaviour |
|---|---|---|---|
| First run / brownfield | `false` (default) | `true` (default) | No cache → collect → save |
| Subsequent runs | `false` (default) | `true` (default) | Cache exists → load from disk |
| Known stale cache | `true` | `true` (default) | Ignore cache → collect → save |
| Ephemeral / CI | `false` (default) | `false` | No cache → collect → do not save |

## Output Variable

After the role runs, `collect_state` is available as a host variable containing the current
UCM configuration in data model format. Pass it to `cisco.ucm.deploy` as `current`.

## State File Format

The state file on disk wraps `collect_state` under a `ucm` key:

```yaml
ucm:
  call_manager_groups:
    - name: Default
      ...
```

This matches the format of `intended` YAML files in `host_vars/`.

## Examples

Resolve current state (typical — uses cache or collects live):

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.resolve
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    state_file_path: "{{ state_path }}/{{ inventory_hostname }}_state.yml"
```

Force a live collect (bypass cache):

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.resolve
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    state_file_path: "{{ state_path }}/{{ inventory_hostname }}_state.yml"
    force_collect: true
```

Collect without persisting (CI / ephemeral runner):

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.resolve
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    state_file_path: "{{ state_path }}/{{ inventory_hostname }}_state.yml"
    save_state: false
```

## Variable Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `hostname` | yes | — | Hostname or IP of the CUCM AXL service |
| `username` | yes | — | AXL API username |
| `password` | yes | — | AXL API password |
| `version` | yes | — | CUCM version string (e.g. `14.0`) |
| `verify` | no | `true` | Whether to verify TLS certificates |
| `state_file_path` | yes | — | Path to the state file (read from cache; written after live collect) |
| `force_collect` | no | `false` | Bypass cache and always run a live collect |
| `save_state` | no | `true` | Persist freshly collected state to `state_file_path` |
