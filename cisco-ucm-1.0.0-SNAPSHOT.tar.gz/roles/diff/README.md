# diff

Computes the diff between current and intended CUCM configuration and produces an ordered list
of AXL operations to reconcile them.

## Pipeline Position

```
collect  ──►  diff  ──►  configure
               │
               diff_operations
               diff_messages
```

## Overview

The role calls `cisco.ucm.diff`, which passes both sides to `diff()`. Both inputs must be in
**data model format** (snake_case keys, Python booleans). The `plan()` function converts them
to AXL internally before generating the operations list — callers never need to do this
conversion themselves.

## Data Format Contract

| Input / Output | Format |
|---|---|
| `current` (in) | Data model — as produced by `collect` (`collect_state`) |
| `intended` (in) | Data model — from `host_vars/` under the `ucm` key |
| `diff_operations` (out) | AXL format — pass directly to `configure` |

**Do not pass raw AXL to this role.** The module expects data model on both sides. Passing raw
AXL will produce incorrect diffs because the format assumptions (casing, boolean representation,
XFK structure) will not match.

## Output Variables

After the role runs:

- **`diff_operations`** — ordered list of dicts, each with:
  - `action`: `"create"` | `"update"` | `"delete"`
  - `type`: AXL object type name (e.g. `"RoutePartition"`)
  - `data`: full AXL-format dict for create/update; `{"name": "<name>"}` for delete
- **`diff_messages`** — list of status strings from `diff()`, useful for debugging

The operations list is pre-sorted by dependency order (parents before children for
adds/updates, children before parents for deletes). Pass it directly to `configure`
without re-sorting.

## The `actions` Parameter

Controls which operation types appear in `diff_operations`. Valid values are `create`,
`update`, and `delete`. The default is `['create', 'update']` — delete is excluded unless
explicitly requested.

| Use case | `actions` value |
|---|---|
| Normal deploy (creates + updates only) | `['create', 'update']` (default) |
| Provisioning only — skip updates to existing objects | `['create']` |
| Update existing objects only — skip creates | `['update']` |
| Include drift removal | `['create', 'update', 'delete']` |
| Delete-only run | `['delete']` (prefer `delete` role for this) |

For a dedicated delete-only run, use the `delete` role rather than setting `actions:
['delete']` here — it applies the `ucm_objects.yaml` safety scoping.

## Example

```yaml
- name: Collect current state
  ansible.builtin.include_role:
    name: cisco.ucm.collect
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"

- name: Generate diff plan
  ansible.builtin.include_role:
    name: cisco.ucm.diff
  vars:
    current: "{{ collect_state }}"
    intended: "{{ ucm }}"   # host_vars/ YAML under the 'ucm' key
```

Provisioning only (creates, no updates):

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.diff
  vars:
    current: "{{ collect_state }}"
    intended: "{{ ucm }}"
    actions:
      - create
```

Include deletes:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.diff
  vars:
    current: "{{ collect_state }}"
    intended: "{{ ucm }}"
    actions:
      - create
      - update
      - delete
```

## Variable Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `current` | yes | — | Current CUCM state in data model format |
| `intended` | yes | — | Intended CUCM state in data model format |
| `actions` | no | `['create', 'update']` | Operation types to include in output (`create`, `update`, `delete`) |
