# collect

Fetches CUCM configuration via the AXL API and converts it to data model format.

## Overview

The role runs a two-stage pipeline:

1. **Collect** — calls `cisco.ucm.collect` to fetch raw AXL objects from UCM
2. **Map** — applies the `cx.uc.ascode_from_axl_model` filter to convert the raw AXL response
   to data model format

The raw AXL response (`_collect_raw`) is a private intermediate variable and is not
intended for callers. After the role completes, `collect_state` is available as a host
variable containing the full UCM configuration in data model format.

## Data Format Boundary

| Stage | Format |
|---|---|
| Module output (`_collect_raw`) | Raw AXL — camelCase keys, string booleans, XFK dicts |
| Role output (`collect_state`) | Data model — snake_case keys, Python booleans, flattened XFK |

The caller always works in data model format. No format conversion is required outside this role.

## Output Variable

After the role runs, `collect_state` is available as a host variable:

```yaml
collect_state:
  ucm:
    call_manager_groups:
      - name: Default
        ...
    locations:
      - name: Hub_None
        ...
    # etc.
```

This is exactly the format expected by `diff` as its `diff_current` input.

## Object Registry

By default the role collects every object type registered in
`roles/common/defaults/main.yml`. The `object_names` default is derived
from the registry at play time:

```yaml
# Derived automatically from ucm_objects.yaml (abridged)
object_names:
  - { name: CallManagerGroup, method: get }
  - { name: Css,              method: get }
  - { name: DateTimeGroup,    method: get }
  - { name: Location,         method: get }
  # ...
```

The orchestrating role or play must include or depend on `cisco.ucm.common` to make the
`ucm_objects` variable available. This role declares `cisco.ucm.common` as a dependency in
`meta/main.yml`, so it loads automatically.

To collect a subset of object types, pass `object_names` explicitly:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.collect
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version:  "{{ uc_version }}"
    object_names:
      - { name: DevicePool, method: get }
      - { name: Region,     method: get }
```

## Persisting State to Disk

The role does not write files. When the caller wants to save collected state for reuse (to avoid
repeated live collects), add the following task after the role:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.collect
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version:  "{{ uc_version }}"

- name: Persist collected state to disk
  ansible.builtin.copy:
    dest: "{{ working_path }}/{{ inventory_hostname }}_state.yml"
    content: "{{ collect_state | cisco.ucm.to_yaml(indent=2) }}"
    mode: '0644'
  delegate_to: localhost
```

## Skipping Live Collect (Cached State)

When a previously saved state file already exists, load it directly and skip the live collect:

```yaml
- name: Load cached state from disk
  ansible.builtin.set_fact:
    collect_state: "{{ lookup('file', working_path + '/' + inventory_hostname + '_state.yml') | from_yaml }}"

# collect role skipped; diff consumes collect_state directly
- ansible.builtin.include_role:
    name: cisco.ucm.diff
```

Re-run the live collect if the cached state is stale or drift is suspected.

## Variable Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `hostname` | yes | — | Hostname or IP of the CUCM AXL service |
| `username` | yes | — | AXL API username |
| `password` | yes | — | AXL API password |
| `version` | yes | — | CUCM version string (e.g. `14.0`) |
| `verify` | no | `true` | Whether to verify TLS certificates |
| `object_names` | no | derived from `ucm_objects` | List of `{name, method}` dicts specifying AXL object types to collect |
