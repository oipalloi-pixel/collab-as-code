# common

Shared Ansible role for the `cx.uc` collection. Its sole responsibility is
exposing `defaults/main.yml` — the UCM object type registry — to every
other CUCM role.

## Usage

Declare `cisco.ucm.common` as a dependency in any role that needs the
registry:

```yaml
# roles/collect/meta/main.yml
dependencies:
  - role: cisco.ucm.common
```

Or include it explicitly in a playbook before the roles that consume it:

```yaml
- name: Load UCM object registry
  ansible.builtin.include_role:
    name: cisco.ucm.common
```

## Variables Provided

| Variable | File | Description |
|---|---|---|
| `ucm_objects` | `defaults/main.yml` | Ordered list of AXL object type descriptors |

Each `ucm_objects` entry has the following keys:

| Key | Type | Description |
|---|---|---|
| `name` | string | AXL type name (PascalCase, matches SDK) |
| `data_model_key` | string | snake_case plural key used under `ucm.*` in host_vars |
| `collect_method` | string | `get` or `list` — AXL retrieval strategy |
| `delete` | bool | Whether `delete` may remove objects of this type |

See `defaults/main.yml` for the canonical list and ordering rationale.
