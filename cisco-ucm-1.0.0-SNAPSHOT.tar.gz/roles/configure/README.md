# configure

Applies an ordered list of add and update operations to a CUCM cluster via the AXL API.

## Pipeline Position

```
diff  ──►  configure
           │
           configure_result
```

## Overview

This role is the UCM equivalent of the ACI `apic_config_stage`. It accepts the AXL-format
operations list produced by `diff` (`diff_operations`) and drives `add*` / `update*`
AXL calls for each entry in dependency order.

**Only `create` and `update` operations are applied.** If the input list contains `delete`
operations (e.g. because `diff` was called with `delete: true`), they are silently filtered
out and a warning is emitted. Use the `delete` role for deletions.

## Input Contract

`operations` must be in **AXL format** as produced by `diff` (`diff_operations`). Each
item is a dict with:

| Key | Values |
|---|---|
| `action` | `"create"` or `"update"` (delete entries are filtered) |
| `type` | AXL object type name (e.g. `"RoutePartition"`) |
| `data` | AXL-format object dict |

Do not pass data model format here — conversion happens inside `diff`, not in this role.

## Output Variable

`configure_result` is registered after the apply task. It contains:

- `messages` — list of status strings from `apply()`, useful for debugging
- `changed` — `true` if any operations were applied (always `false` in check mode)

## Check Mode

The underlying `cisco.ucm.configure` module supports `--check`. When Ansible runs in check mode,
no AXL calls are made and `changed` is always `false`. The role inherits this behaviour
automatically — no extra configuration is needed.

## Connection Variables

Connection parameters default to conventional inventory vars and can be overridden at include
time:

| Variable | Default | Description |
|---|---|---|
| `hostname` | `{{ uc_hostname }}` | Hostname or IP of the CUCM AXL service |
| `username` | `{{ uc_app_username }}` | AXL API username |
| `password` | `{{ uc_app_password }}` | AXL API password |
| `version` | `{{ uc_version }}` | CUCM version string (e.g. `14.0`) |
| `verify` | `true` | Whether to verify TLS certificates |

## Example

Minimal — connection defaults from inventory:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.configure
  vars:
    operations: "{{ diff_operations }}"
```

Overriding connection parameters:

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.configure
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"
    operations: "{{ diff_operations }}"
```

Full pipeline (collect → diff → configure):

```yaml
- ansible.builtin.include_role:
    name: cisco.ucm.collect
  vars:
    hostname: "{{ uc_hostname }}"
    username: "{{ uc_app_username }}"
    password: "{{ uc_app_password }}"
    version: "{{ uc_version }}"

- ansible.builtin.include_role:
    name: cisco.ucm.diff
  vars:
    current: "{{ collect_state }}"
    intended: "{{ ucm }}"

- ansible.builtin.include_role:
    name: cisco.ucm.configure
  vars:
    operations: "{{ diff_operations }}"
```
